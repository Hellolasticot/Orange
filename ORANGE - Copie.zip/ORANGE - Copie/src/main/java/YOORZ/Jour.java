/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;

/**
 *
 * @author HugoBarboule
 */
public class Jour implements Comparable<Jour>{
    private int nbJourYear;
    private int nbWeekYear;
    private Date d;
    private HashMap<String, Integer> map = new HashMap<String, Integer>();
    private int nbMonthYear;
    
    
    public Jour(int nbJourYear, int nbWeekYear, Date d) {
        this.nbJourYear = nbJourYear;
        this.nbWeekYear = nbWeekYear;
        this.d = d;
        this.init_MonthYear();
    }

    public int getNbMonthYear() {
        return nbMonthYear;
    }
    
        
    public void init_MonthYear()
    {
        Calendar c = Calendar.getInstance();
        c.setTime(this.d);
        this.nbMonthYear = c.get(Calendar.MONTH);
    }
    
    public void init_map(HashMap<String, Integer> map)
    {
        this.map = map;
    }

    public int getNbJourYear() {
        return nbJourYear;
    }

    public int getNbWeekYear() {
        return nbWeekYear;
    }

    public Date getD() {
        return d;
    }
    
    public static Comparator<Jour> ComparatorWeek = new Comparator<Jour>(){
        
        @Override
        public int compare(Jour j1, Jour j2){
            return (int) (j1.getNbWeekYear() - j2.getNbWeekYear());
        }
    };

    @Override
    public String toString() {
        return "Jour{" + "nbJourYear=" + nbJourYear + ", nbWeekYear=" + nbWeekYear + ", d=" + d + ", map=" + map + '}';
    }

    public HashMap<String, Integer> getMap() {
        return map;
    }

    public void setNbJourYear(int nbJourYear) {
        this.nbJourYear = nbJourYear;
    }
    
    
    
    @Override
    public int compareTo(Jour j)
    {
        if(this.nbJourYear == 0)
        {
            this.nbJourYear = 7;
        }
        if(j.getNbJourYear() == 0)
        {
            j.setNbJourYear(7);
        }
        return (this.nbJourYear - j.getNbJourYear());
    }
    
    
    
}
