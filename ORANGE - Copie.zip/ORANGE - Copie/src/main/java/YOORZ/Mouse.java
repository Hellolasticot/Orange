/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

/**
 *
 * @author HugoBarboule
 */
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.text.DecimalFormat;
import java.text.NumberFormat;
 
import javax.swing.*;
 
@SuppressWarnings("serial")
public class Mouse extends JFrame implements MouseMotionListener, MouseListener {
	private int x, y, x_start_point, y_start_point;
	private NumberFormat nf = new DecimalFormat("#.00");
	private final static Font LEGENDE = new Font("Sans Serif, Helvetica, Arial", Font.ROMAN_BASELINE, 10);
 
	public Mouse () {
		setBackground(Color.LIGHT_GRAY);
 
		x_start_point=-1;
		y_start_point=-1;
 
		addMouseMotionListener(this);
		addMouseListener(this);
 
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(350, 400);
	}
 
	@Override
	public void paint(Graphics g) {
		super.paint(g);
 
		Graphics2D g2d = (Graphics2D)g;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
 
		if(x_start_point!=-1){
			// ligne
			g2d.setColor(Color.RED);
			g2d.drawLine(x_start_point, y_start_point, x, y);
 
			// croix
			g2d.setColor(Color.BLACK);
			g2d.drawLine(x_start_point, y_start_point-3, x_start_point, y_start_point+3);
			g2d.drawLine(x_start_point-3, y_start_point, x_start_point+3, y_start_point);
			g2d.drawLine(x, y-3, x, y+3);
			g2d.drawLine(x-3, y, x+3, y);
 
			// legendes
			g2d.setColor(new Color(255,255,255,80));
			g2d.fillRect(x_start_point-60, y_start_point, 50, 35);
			g2d.fillRect(x+10, y, 72, 95);
 
			g2d.setColor(Color.BLACK);
			g2d.setFont(LEGENDE);
 
			g2d.drawString("x : " + (x_start_point), x_start_point-55, y_start_point+15);
			g2d.drawString("y : " + (y_start_point), x_start_point-55, y_start_point+27);
 
			g2d.drawString("x : " + (x), x+15, y+15);
			g2d.drawString("y : " + (y), x+15, y+27);
 
			g2d.drawString("h : " + (x - x_start_point), x+15, y+45);
			g2d.drawString("v : " + (y - y_start_point), x+15, y+57);
 
			g2d.drawString("° : " + nf.format(-(Math.toDegrees(Math.atan2(y-y_start_point , x-x_start_point)))), x+15, y+75);			
			g2d.drawString("d : " + nf.format((Math.sqrt(Math.pow((x - x_start_point),2)+Math.pow((y - y_start_point),2)))), x+15, y+87);
		}
	}
 
	// Listeners
	public void mouseDragged(MouseEvent e) {
		x = e.getX();
		y = e.getY();
		repaint();		
	}
 
	public void mouseMoved(MouseEvent e) {}
 
	public void mouseClicked(MouseEvent e) {}
 
	public void mouseEntered(MouseEvent e) {}
 
	public void mouseExited(MouseEvent e) {}
 
	public void mousePressed(MouseEvent e) {
		x_start_point=e.getX();
		y_start_point=e.getY();
		x = e.getX();
		y = e.getY();
		repaint();		
	}
 
	public void mouseReleased(MouseEvent e) {}
 
	// Main
	 public static void main(String[] args) {
                new Mouse().setVisible(true);
	}
}