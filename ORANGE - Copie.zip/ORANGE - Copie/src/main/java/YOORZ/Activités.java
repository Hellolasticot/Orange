  /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map; 
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
/**
 *
 * @author HugoBarboule
 */
public class Activités {
    //déclaration des attributs d'une activité
    private String nom;
    private String description;
    private int poids;
    private String vue;
    private String equipe;
    private String type;
    /*private Vue_Activité vue;
    private GSAT equipe;
    private Type type;*/
    
    //déclaration variable tableau de 48 cases, repésentant le tableau excel duréeVac
    private HashMap<Float, Integer> tableauAbsence = new HashMap<Float, Integer>();
    private HashMap<Float, Integer> tableauActivité = new HashMap<Float, Integer>();
    private HashMap<Float, Integer> tableautriéAbsence = new HashMap<Float, Integer>();
    private HashMap<Float, Integer> tableautriéActivité = new HashMap<Float, Integer>();
    //private HashMap<String, Integer> tableauTriéReel = new HashMap<String, Integer>();
    
    //Constructeur d'une ativité == Une manière de décrire une activité
    public Activités(String nom, String description, int poids, String vue, String equipe, String type)
    {
        this.nom = nom; this.description = description; this.poids = poids; this.vue = vue; this.equipe = equipe; this.type = type;
        // initialisation du tableau de duréevac excel à 0 en présence sur chaque case. 
        // Comment ça marche ? La premiere partie représente la partie horaire (0.5 = 00h30, 11.5 = 11h30 ...)
        // et la deuxième partie est 0 ou 1 avec 1 si la personne est dans l'activité et 0 sinon
        float heure = 0f;
        for(int i = 0; i<=48; i++)
        {
            this.tableauAbsence.put(heure, 1);
            this.tableauActivité.put(heure, 0);
            heure += 0.5f;
        }
        
        this.tableautriéAbsence = trierHashMap(this.tableauAbsence); 
        this.tableautriéActivité = trierHashMap(this.tableauActivité);   
    }//fin du constructeur
    
    //Méthode permettant de trier par ordre numérique, les clés de la HashMap
    public static HashMap<Float, Integer> trierHashMap(Map<Float, Integer> hmap){
        List<Map.Entry<Float, Integer>> list =
           new LinkedList<Map.Entry<Float, Integer>>( hmap.entrySet() );
        Collections.sort( list, new Comparator<Map.Entry<Float, Integer>>(){
           public int compare
           (Map.Entry<Float, Integer>o1, Map.Entry<Float, Integer> o2 )
           {
              //comparer deux clés
              return (o1.getKey()).compareTo( o2.getKey() );
           }
        });
        
        //créer une nouvelle HashMap à partir de LinkedList
        HashMap<Float, Integer> hmapTriee = new LinkedHashMap<Float, Integer>();
        for (Map.Entry<Float, Integer> entry : list)
        {
            hmapTriee.put( entry.getKey(), entry.getValue() );
        }
        return hmapTriee;
    }
    

    
    //Methode permettant d'avoir le nom de l'activité
    public String getNom() {
        return nom;
    }

    public void setNom(String nom)
    {
        this.nom = nom;
    }
    
    //Methode permettant d'avoir la description de l'activité
    public String getDescription() {
        return description;
    }

    //Methode permettant d'avoir le poids de l'activité
    public int getPoids() {
        return poids;
    }

    //Methode permettant d'avoir la vue de l'activité
    public String getVue() {
        return vue;
    }

    //Methode permettant d'avoir l'equipe de l'activité
    public String getEquipe() {
        return equipe;
    }

    //Methode permettant d'avoir le type de l'activité
    public String getType() {
        return type;
    }

    //Methode permettant d'avoir un affichage de l'activité
    @Override
    public String toString() {
        return "Activité : { " + "nom=" + nom + ", description=" + description + ", poids=" + poids + ", vue=" + vue + ", equipe=" + equipe + ", type=" + type + '}';
    }
    
    
    /*Methode permettant d'initialisé un tableau composé de deux colonnes : une premiere colonne où l'on a chaque tranche 
    horaire de 30 min de 00h à 24h 
    et de l'autre on a 1 (si présent dans l'activité) ou 0 (si absent dans l'activité)
    */
     
    
    public ArrayList<HashMap<Float, Integer>> init_HorairesParActivitéBIS(String nom2)
    {
        ArrayList<HashMap<Float, Integer>> list = new ArrayList<HashMap<Float, Integer>>();
        //Je récupere la liste entière des Activités
        ListeActivités la = new ListeActivités();
        //Je l'initialise ( = mettre les activités dedans)
        la.init_list();
        
        
        // Je crée une varaible égale au nom de l'activité en questiion
        String nom = nom2;     
        
        //Il s'agit de l'indice qui va parcourir toute la liste des Activités
        int i = 0;
        
        // Je crée une vérification dans le cas où la machine a trouvé un nom identifié 
        // dans la liste des Activités similaire au nom de cette Activité
        boolean afini = false;
        
        // Je parcours toute la liste jusqu'à trouver (ou non) un nom d'Activité similaire
        while((i<la.get_list().size()) && (afini == false))
        {
            //Je crée une chaine de caractère similaire à chaque nom d'Activité
            CharSequence cs = la.get_list().get(i).getNom();
            
            
            //Je vérifie si dans le nom de l'activité il y a une Activité connue de a liste
            boolean verif = nom.contains(cs);
            
            
            
            
            // Si c'est le cas alors je le récupere
            if((verif == true))
            {
                boolean verifSeconde;
                
                char[] tabverif = nom.toCharArray();
                int aa = 0;
                boolean aTrouve = false;
                // On verfie qu'il n'y a pas de caracteres spéciaux
                while(aa<tabverif.length && !aTrouve)
                {
                    aTrouve = (tabverif[aa] == '[') || (tabverif[aa] == ']') || (tabverif[aa] == '+') ;
                    if(!aTrouve)
                        aa++;
                }
                
                
                String[] tabtest;
                
                
                if(aTrouve)
                {
                    
                    String VraiNom = "";
                    boolean vPlus = false;
                    for(int b = 0; b<tabverif.length; b++)
                    {
                        if(!(tabverif[b] == '+' || tabverif[b] == '[' || tabverif[b] == ']'))
                        {
                            VraiNom += tabverif[b];
                        }else{
                            if(tabverif[b] == '+')
                            {
                                vPlus = true;
                                VraiNom += "plus";
                            }
                            else{
                                VraiNom += "";
                            }
                        }
                    }
                    
                    
                    char[] tabverifList = la.get_list().get(i).getNom().toCharArray();
                    
                    boolean vPlusList = false;
                    String VraiNomList = "";
                    for(int b = 0; b<tabverifList.length; b++)
                    {
                        if(!(tabverifList[b] == '+' || tabverifList[b] == '[' || tabverifList[b] == ']'))
                        {
                            VraiNomList += tabverifList[b];
                        }
                        else{
                            if(tabverifList[b] == '+')
                            {
                                vPlusList = true;
                                VraiNomList += "plus";
                            }else{
                                VraiNomList += "";
                            }
                        }
                    }
                    
                    tabtest = VraiNom.split(VraiNomList);
                    
                    
                }else{
                    
                    tabtest = nom.split(la.get_list().get(i).getNom());
                }

                /*
                Etant donné qu'il y a forcement 8 chiffres apres le nom de la réunion, il n'existe qu'une seule et unique 
                nom de réunion compatible (car les doublons sont impossibles)
                */
                
                if(tabtest[1].length() != 8)
                {
                    verifSeconde = false;
                }else{
                    verifSeconde = true;
                }
                
                
                if(verifSeconde == true)
                {
                    //Je split en fonction du nombre car la focntion split peut avoir des erreurs si dans le string il y a des caractères spéciaux
                    

                 char[] tabHoraire = tabtest[1].toCharArray();
                 int cas;
                 if(Integer.parseInt(tabHoraire[4] + ""+ tabHoraire[5]) < Integer.parseInt(tabHoraire[0] + ""+ tabHoraire[1]) )
                 {
                     cas = 1;
                     
                     
                 }else{
                     
                     cas = 0;
                 }

                 

             //Je découpe chaque chiffre de ce nombre (le nombre est alors la fourchette de l'horaire qu'a duré l'Activité)

             boolean verif2 = false;

                      verif2 = (this.getEquipe().equals(la.get_list().get(i).getEquipe()));

 
                     
             boolean verif4 = false;

             if(verif2 == true)
             {
                 verif4 = true;
             
                    
                    //horaire réelle de debut
                    float horairedeb = 0f;

                        horairedeb = Float.parseFloat((String.valueOf(tabHoraire[0] + "" +tabHoraire[1])));


                   
                    //approximation de la decimal de l'horaire du début
                    float decimalApproxdeb = (Float.parseFloat((String.valueOf(tabHoraire[2] + "" +tabHoraire[3])))/60);
                    
                    //si 10h15 ou 10h20 alors 10h, si 10h40 ou 10h50 alors 10h30
                        if(decimalApproxdeb > 0.0f && decimalApproxdeb <= 0.5f)
                        {
                            decimalApproxdeb = 0.5f;
                        }
                        if(decimalApproxdeb > 0.5f)
                        {
                            decimalApproxdeb = 1f;
                        }
                    
                    //approximation de l'horaire du début
                    float horaireDebApprox = horairedeb;
                    horaireDebApprox += decimalApproxdeb;
                    

                    
                    //horaire réelle de fin
                    float horairefin = 0f;

                        horairefin = Float.parseFloat((String.valueOf(tabHoraire[4] + "" +tabHoraire[5])));
                    
   
                    
                    //approximation de la decimal de l'horaire de fin
                    float decimalApproxfin = (Float.parseFloat((String.valueOf(tabHoraire[6] + "" +tabHoraire[7])))/60);
                    
                    //si 15h15 alors 15h30 et si 15h35 alors 16h
                    if( decimalApproxfin < 0.5f)
                    {
                        decimalApproxfin = 0f;
                    }
                    if( decimalApproxfin >= 0.5f && decimalApproxfin < 1f)
                    {
                        decimalApproxfin = 0.5f;
                    }

                    
                    
                    
                    //approximation de l'horaire de fin
                    float horairefinApprox = horairefin;
                    horairefinApprox += decimalApproxfin;

                    
                   switch(cas){
                       
                       //Cas où le deuxieme nombre est supérieur (sur une journée)
                       case 0:
                           //On remet des 0 partout dans la fourchette horaire
                           for(float ind = 0f; ind<= 24f; ind = ind+0.5f)
                           {
                                this.tableautriéActivité.replace(ind, 0);
                           }
                           //On met les 1 dans la fourchette horaire
                           for(float ind = horaireDebApprox; ind< horairefinApprox; ind = ind+0.5f)
                           {
                                this.tableautriéActivité.replace(ind, 1);
                           }
                           list.add(this.tableautriéActivité);
                           
                           
                           break;
                       
                           
                           // Cas où le deuxieme nombre est inférieur au premier ( sur deux journées )
                       case 1:
                           //On remet des 0 partout dans la fourchette horaire
                           for(float ind = 0f; ind<= 24f; ind = ind+0.5f)
                           {
                                this.tableautriéActivité.replace(ind, 0);
                           }
                           //On met les 1 dans la fourchette horaire
                           for(float ind = horaireDebApprox; ind<= 24f; ind = ind+0.5f)
                           {
                                this.tableautriéActivité.replace(ind, 1);
                           }
                           list.add(this.tableautriéActivité);
                           
                           // Je crée un deuxième tableau et je mets tout à 0
                           HashMap<Float, Integer> t = new HashMap<Float, Integer> ();
                           
                           for(float ind = 0f; ind<= 24f; ind = ind+0.5f)
                           {
                                t.put(ind, 0);
                           }
                           
                           t = trierHashMap(t);

                           //Pour ce nombre on prend le nombre de à la fin + le reste pour faire une jounée                            
                           for(float ind = 0f; ind < horairefinApprox; ind = ind+0.5f)
                           {
                                t.replace(ind, 1);
                           }
                           list.add(t);
                           
                           break;
                           
                       default:
                           System.out.println("IMPOSSIBLE !");
                           break;
                       
                   } 
                    


                    if(verif4 == true)
                    {
                        afini = true;
                    }else{
                        afini = false;
                    }


             }// fin de la verif interne
                }// fin de la verifSeconde

             
             
               /* cas où il a trouvé le nom dans la liste*/
               verif = false;
               
               
            }// fin de verif du contains

           i++;

        }//fin du while
        
        return list;
           
           
    }//Fin de la Méthode
        
        
    public ArrayList<HashMap<Float, Integer>> init_HorairesParAbsenceBIS(String nom2)
    {
        ArrayList<HashMap<Float, Integer>> list = new ArrayList<HashMap<Float, Integer>>();
        //Je récupere la liste entière des Activités
        ListeActivités la = new ListeActivités();
        //Je l'initialise ( = mettre les activités dedans)
        la.init_list();
        
        

        // Je crée une varaible égale au nom de l'activité en questiion
        String nom = nom2;     
        
        //Il s'agit de l'indice qui va parcourir toute la liste des Activités
        int i = 0;
        
        // Je crée une vérification dans le cas où la machine a trouvé un nom identifié 
        // dans la liste des Activités similaire au nom de cette Activité
        boolean afini = false;
        
        // Je parcours toute la liste jusqu'à trouver (ou non) un nom d'Activité similaire
        while((i<la.get_list_Absences().size()) && (afini == false))
        {
            //Je crée une chaine de caractère similaire à chaque nom d'Activité
            CharSequence cs = la.get_list_Absences().get(i).getNom();
            
            //Je vérifie si dans le nom de l'activité il y a une Activité connue de a liste
            boolean verif = nom.contains(cs);
            
            
            
            // Si c'est le cas alors je le récupere
            if((verif == true))
            {
                boolean verifSeconde;
                
                
                
                char[] tabverif = nom.toCharArray();
                int aa = 0;
                boolean aTrouve = false;
                // On verfie qu'il n'y a pas de caracteres spéciaux
                while(aa<tabverif.length && !aTrouve)
                {
                    aTrouve = (tabverif[aa] == '[') || (tabverif[aa] == ']') || (tabverif[aa] == '+') ;
                    if(!aTrouve)
                        aa++;
                }
                
                
                
                String[] tabtest;
                
                
                if(aTrouve)
                {
                    String VraiNom = "";
                    boolean vPlus = false;
                    char[] tabverif2 = nom.toCharArray();
                    for(int b = 0; b<tabverif2.length; b++)
                    {
                        if(!(tabverif2[b] == '+' || tabverif2[b] == '[' || tabverif2[b] == ']'))
                        {
                            VraiNom += tabverif2[b];
                            
                        }else{
                            if(tabverif2[b] == '+')
                            {
                                vPlus = true;
                                VraiNom += "plus";
                            }
                            else{
                                VraiNom += "";
                            }
                        }
                    }
                    
                    
                    
                    char[] tabverifList = la.get_list_Absences().get(i).getNom().toCharArray();
                    

                    
                    boolean vPlusList = false;
                    String VraiNomList = "";
                    for(int b = 0; b<tabverifList.length; b++)
                    {
                        if(!(tabverifList[b] == '+' || tabverifList[b] == '[' || tabverifList[b] == ']'))
                        {
                            VraiNomList += tabverifList[b];
                        }
                        else{
                            if(tabverifList[b] == '+')
                            {
                                vPlusList = true;
                                VraiNomList += "plus";
                            }else{
                                VraiNomList += "";
                            }
                        }
                    }
                    
                    tabtest = VraiNom.split(VraiNomList);
                    
                    
                }else{
                    
                    tabtest = nom.split(la.get_list_Absences().get(i).getNom());
                }


                /*
                Etant donné qu'il y a forcement 8 chiffres apres le nom de la réunion, il n'existe qu'une seule et unique 
                nom de réunion compatible (car les doublons sont impossibles)
                */
                
               
               char[] tabverifverif = tabtest[1].toCharArray();
                
                if(tabverifverif.length != 8)
                {
                    verifSeconde = false;
                }else{
                    verifSeconde = true;
                }
                

                
                if(verifSeconde == true)
                {
                 //Je split en fonction du nombre car la focntion split peut avoir des erreurs si dans le string il y a des caractères spéciaux
                 char[] tabHoraire = tabtest[1].toCharArray();
                 int cas;
                 if(Integer.parseInt(tabHoraire[4] + ""+ tabHoraire[5]) < Integer.parseInt(tabHoraire[0] + ""+ tabHoraire[1]) )
                 {
                     cas = 1;
                     
                 }else{
                     
                     cas = 0;
                 }


             //Je découpe chaque chiffre de ce nombre (le nombre est alors la fourchette de l'horaire qu'a duré l'Activité)



             boolean verif2 = false;
 
                      verif2 = (this.getEquipe().equals(la.get_list_Absences().get(i).getEquipe()));

 
                     
             boolean verif4 = false;

             if(verif2 == true)
             {
                 verif4 = true;
             
                    
                    //horaire réelle de debut
                    float horairedeb = 0f;

                        horairedeb = Float.parseFloat((String.valueOf(tabHoraire[0] + "" +tabHoraire[1])));


                   
                    //approximation de la decimal de l'horaire du début
                    float decimalApproxdeb = (Float.parseFloat((String.valueOf(tabHoraire[2] + "" +tabHoraire[3])))/60);
                    
                    //si 10h15 ou 10h20 alors 10h, si 10h40 ou 10h50 alors 10h30
                        if(decimalApproxdeb < 0.5f)
                        {
                            decimalApproxdeb = 0f;
                        }
                        if(decimalApproxdeb >= 0.5f && decimalApproxdeb < 1f)
                        {
                            decimalApproxdeb = 0.5f;
                        }
                    
                    //approximation de l'horaire du début
                    float horaireDebApprox = horairedeb;
                    horaireDebApprox += decimalApproxdeb;

                    
                    //horaire réelle de fin
                    float horairefin = 0f;

                        horairefin = Float.parseFloat((String.valueOf(tabHoraire[4] + "" +tabHoraire[5])));

                    
   
                    
                    //approximation de la decimal de l'horaire de fin
                    float decimalApproxfin = (Float.parseFloat((String.valueOf(tabHoraire[6] + "" +tabHoraire[7])))/60);
                    
                    //si 15h15 alors 15h30 et si 15h35 alors 16h
                    if( decimalApproxfin < 0.5f)
                    {
                        decimalApproxfin = 0.5f;
                    }
                    if(decimalApproxfin >= 0.5f)
                    {
                        decimalApproxfin = 1f;
                    }

                    
                    
                    
                    //approximation de l'horaire de fin
                    float horairefinApprox = horairefin;
                    horairefinApprox += decimalApproxfin;
                    
                     
                     switch(cas){
                       
                       //Cas où le deuxieme nombre est supérieur (sur une journée)
                       case 0:
                           
                           //On met les 1 partout
                           for(float ind = 0f; ind<= 24f; ind = ind+0.5f)
                           {
                                this.tableautriéAbsence.replace(ind, 1);
                           }
                           
                           //On met les 0 dans la fourchette horaire
                           for(float ind = horaireDebApprox; ind< horairefinApprox; ind = ind+0.5f)
                           {
                                this.tableautriéAbsence.replace(ind, 0);
                           }
                           list.add(this.tableautriéAbsence);
                           
                           
                           break;
                       
                           // Cas où le deuxieme nombre est inférieur au premier ( sur deux journées )
                       case 1:
                           
                           //On met les 1 partout
                           for(float ind = 0f; ind<= 24f; ind = ind+0.5f)
                           {
                                this.tableautriéAbsence.replace(ind, 1);
                           }
                           
                           //On met les 0 dans la fourchette horaire
                           for(float ind = horaireDebApprox; ind<= 24f; ind = ind+0.5f)
                           {
                                this.tableautriéAbsence.replace(ind, 0);
                           }
                           list.add(this.tableautriéAbsence);
                           
                           // Je remets tout à 0
                           HashMap<Float, Integer> t = new HashMap<Float, Integer> ();
                           
                           for(float ind = 0f; ind<= 24; ind = ind+0.5f)
                           {
                                t.put(ind, 1);
                           }
                           
                           t = trierHashMap(t);
                           
                           //Je crée le deuxieme tableau
                           //Pour ce nombre on prend le nombre de à la fin + le reste pour faire une jounée                            
                           for(float ind = 0f; ind < horairefinApprox; ind = ind+0.5f)
                           {
                                t.replace(ind, 0);
                           }
                           list.add(t);
                           
                           
                           break;
                           
                       default:
                           System.out.println("IMPOSSIBLE !");
                           break;
                       
                   } 


                    if(verif4 == true)
                    {
                        afini = true;
                    }else{
                        afini = false;
                    }


             }// fin de la verif interne
                }// Fin de verif Seconde

             
             
               /* cas où il a trouvé le nom dans la liste*/
               verif = false;
              
               
               
            }// fin de verif du contains

           i++;

        }//fin du while
        return list;
           
           
    }//Fin de la Méthode
 
        
}//Fin de la classe
   
    
 
