package YOORZ;

/**
 *
 * @author HugoBarboule
 */

/*
    Cette classe permettrait de faire une initialisation globale pour l'application 
        qui se ferait en au lancement de l'application
*/

public class Cloud {
    private ListeSuperviseurs ls = new ListeSuperviseurs();
    private ListeEDT le = new ListeEDT();
    private ListeActivités la = new ListeActivités();
    
   
    
    public void init_la()
        {
            try{
                this.la.Ecrire_FichierDeBase();
                this.la.Create_File_Absences();
                this.la.Create_File_Activités();
                
            }catch(Exception e){
                e.printStackTrace();
            }
            this.la.init_list();
            this.la.init_listDesAb();
            this.la.init_listdesAc();
        }
    
    public void init_le()
    {
        this.le.init_EDT();
    }
    
    public void init_ls()
    {
        this.ls.init_list();
    }
    
    public ListeSuperviseurs get_ls()
    {
        return this.ls;
    }
    
    public ListeEDT get_le()
    {
        return this.le;
    }
    
    public ListeActivités get_la()
    {
        return this.la;
    }
           
    
    
    

}
