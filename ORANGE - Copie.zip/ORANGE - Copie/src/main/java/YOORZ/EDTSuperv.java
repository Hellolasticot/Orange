/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author HugoBarboule
 */
public class EDTSuperv {
     private Date date;
     private Activités activite;
     private Absence absence;
     private HashMap<Float, Integer> map;
     private Superviseur s;
     private String nom;
     private int numéro;

    public EDTSuperv(Superviseur s, Date date, Activités activite) {
        this.date = date;
        this.activite = activite;
        this.s = s;
        this.map = new HashMap<Float, Integer>();
        this.nom = null;
        this.absence = null;
        this.numéro = 0;
    }

    public int getNuméro() {
        return numéro;
    }

    public void setNuméro(int numéro) {
        this.numéro = numéro;
    }

    public Absence getAbsence()
    {
        return this.absence;
    }
    
    public void set_Absence(Absence a)
    {
        this.absence = a;
    }
    
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    
    
    public Date getDate() {
        return date;
    }

    public void setActivite(Activités activite) {
        this.activite = activite;
    }

    public void setDate(Date date) {
        this.date = date;
    }
   

    public SimpleStringProperty getVNomPrenomSuperviseur()
    {
        SimpleStringProperty property = new SimpleStringProperty(this.s.getNom() + " " + this.s.getPrenom());
        return property;
    }
    
    public SimpleStringProperty getVDate()
    {
        SimpleStringProperty property = new SimpleStringProperty();
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        property.setValue(dateFormat.format(this.getDate()));
        return property;
    }
    
    public SimpleStringProperty getVNomActivité()
    {
        SimpleStringProperty property = new SimpleStringProperty(this.activite.getNom());
        return property;
    }
    
    
    public Activités getActivite() {
        return activite;
    }

    public Superviseur getS() {
        return s;
    }

    public HashMap<Float, Integer> getMap() {
        return map;
    }
   
    public void setMap(HashMap<Float, Integer> map) {
        this.map = map;
    }
        
    public String afficher_EDT()
    {
        String texte = "";
        String texte_haut = "";
        String texte_bas = "";
        String d = "";
        SimpleDateFormat formater = new SimpleDateFormat("dd/MM/yyyy");
        d = formater.format(this.date);
        texte += d + "\t" + this.activite.getNom() + "\tpoids : "+this.activite.getPoids()+"\n et le nom : "+ this.getNom() + "\n";
        if(this.map.isEmpty())
        {
            return "Y A RIEN DANS LA MAP";
        }else{
            //Affichage du tableau
        for(HashMap.Entry<Float, Integer> entry : this.map.entrySet())
        {
           texte_haut += "| " +entry.getKey() + " \t";
           texte_bas += "| "+entry.getValue()+ " \t";
        }
        texte_haut += "\n";
        texte += texte_haut + texte_bas;
        return texte;
        }
        
    }
 
     
     
     
}
