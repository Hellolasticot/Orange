/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author HugoBarboule
 */
public class ListeSuperviseurs {
    private ArrayList<Superviseur> list = new ArrayList<Superviseur>();
    private ArrayList<String> listSite = new ArrayList<String>();
       
    
    public ArrayList<Superviseur> get_list()
    {
        return this.list;
    }
    
    public ArrayList<ArrayList<Superviseur>> QuiEstDispoParDemieHeure(String jour, float heure, int nbDemieHeure, String site, int verif)
    {
        ArrayList<Superviseur> listSupervSite = new ArrayList<Superviseur>();
        ArrayList<Superviseur> listSupervSiteBIS = new ArrayList<Superviseur>();
        ArrayList<Superviseur> listSuperv = new ArrayList<Superviseur>();
        ArrayList<Superviseur> listSupervBis = new ArrayList<Superviseur>();
        ArrayList<ArrayList<Superviseur>> Lalist = new ArrayList<ArrayList<Superviseur>>();
        
        for(int i = 0; i<this.list.size(); i++)
        {
            int compteur = 0;
            for(int a = 0; a<this.list.get(i).getEdt().size(); a++)
            {
                String d;
                SimpleDateFormat formater = new SimpleDateFormat("dd/MM/yyyy");
                d = formater.format(this.list.get(i).getEdt().get(a).getDate());
                if(d.equals(jour))
                {
                    float heuretemp = heure;
                    for(int b = 0; b<nbDemieHeure; b++)
                    {
                        if(this.list.get(i).getEdt().get(a).getMap().get(heuretemp) != null && this.list.get(i).getEdt().get(a).getMap().get(heuretemp) == 1)
                        {
                            compteur ++;
                        }
                        heuretemp += 0.5f;
                    }
                    
                    boolean verif2 = site.toUpperCase().equals(this.list.get(i).getSite().toUpperCase());
                    
                    if((compteur == (int) nbDemieHeure) && !verif2)
                    {
                          listSuperv.add(this.list.get(i));
                    }
                    if(compteur > 0 && compteur < (int) nbDemieHeure && !verif2)
                    {
                        listSupervBis.add(this.list.get(i));
                    } 
                    
                    if((compteur == (int) nbDemieHeure) && verif2)
                    {
                          listSupervSite.add(this.list.get(i));
                    }
                    if(compteur > 0 && compteur < (int) nbDemieHeure && verif2)
                    {
                        listSupervSiteBIS.add(this.list.get(i));
                    }
                }
            }
        }
       
       Lalist.add(listSupervSite);
       Lalist.add(listSupervSiteBIS);
       Lalist.add(listSuperv);
       Lalist.add(listSupervBis);
        
       return Lalist;
    }
       
  
    
    
    
    
    //Création d'une méthode permettant d'initaliser la liste des activités en focntion  du csv mis en source (dossier csv)
    public void init_list()
    {
       
        //Création de variables pour créer une activité en fonction de sa défintion (constructeur)
        String nom;
        String prenom;
        String CUID;
        String Site;
        
        
        try{
            this.list.clear();
            //On récupère le CSV dans les dossiers.
            InputStream input = getClass().getResource("/données/Compétences.txt").openStream(); 
                Scanner scan = new Scanner(input, "ISO-8859-1");
            
            
            
            String ligne = "";
            //Tant qu'il y a une ligne d'écrite sur le fichier CSV
                while(scan.hasNextLine())
                {
                   
                    // Dans la variable txt il y a une ligne entière du CSV
                    String txt=scan.nextLine();

                    /*Pour récupérer les bonnes informations, on découpe chaque 
                    ligne du csv en fonction du découpage (en point virgules) du csv*/
                    String[] v= txt.split(";");

                    
                    
                  boolean aInitialiséActivité = false;
                  while(!aInitialiséActivité)
                  {
                        //Vérification s'il y a un nom (=premiere partie de la ligne )
                        if(!v[0].equals("null"))
                        {
                            nom = v[0];
                        }
                        else{
                            nom = "Nom Inconnu";
                        }
                   
                        //Vérification qu'une description de l'activité existe
                        if(!v[1].equals("null"))
                        {
                            prenom = v[1];
                        }
                        else{
                            prenom = "Prenom Inconnue";
                        }
                   
                        //Vérification qu'un poids existe
                        if(!v[2].equals("null"))
                        {
                            CUID = v[2];
                        }
                        else{
                            CUID = "Pas de CUID";
                        }
                        if(!v[3].equals("null"))
                        {
                            Site = v[3];
                            if(!this.listSite.contains(Site) || this.listSite.isEmpty())
                                this.listSite.add(Site);
                        }
                        else{
                            Site = "Pas de Site";
                        }
                        
                        Superviseur s = new Superviseur(Site, nom, prenom, CUID);
                        
                        if(v[4].equals("1"))
                        {
                            s.Set_CompétenceSDH(true);
                        }
                        
                        if(v[5].equals("1"))
                        {
                            s.Set_CompétenceFH(true);
                        }
                        
                        if(v[6].equals("1"))
                        {
                            s.Set_CompétenceWDM(true);
                        }
                        aInitialiséActivité = true;
                        
                        if(!this.list.contains(s))
                        {
                            this.list.add(s);
                        }
                        
                        
                  }

                }
                input.close();
                
                /*
                On met les Sites dans les SUuperviseurs car dans l'export de YOORZ, ils sont considérés comme tels. 
                On peut alors l'activité de la journée sur un site, et ainsi pouvoir faire des stats dessus.
                */
                for(int a = 0; a<this.listSite.size(); a++)
                        {
                            Superviseur site = new Superviseur(this.listSite.get(a), this.listSite.get(a), "", "");
                            if(!this.list.contains(site))
                            {
                                this.list.add(site);
                            }
                        }
        }
        catch(Exception e){
            System.out.println("Une erreur est survenue lors de l'initalisation de la liste des Superviseurs");
            e.printStackTrace();
        }
    }
    
    public ArrayList<String> get_listSite()
    {
        return this.listSite;
    }
    
    public String afficherListeSuperviseur()
    {
        String texte="";
        
        for(int i  = 0; i<this.get_list().size(); i++)
        {
           texte += this.get_list().get(i).getNom()+" " + this.get_list().get(i).getPrenom() + " : ";
           for(int a = 0; a<this.get_list().get(i).getEdt().size(); a++)
           {
               texte+= this.get_list().get(i).getEdt().get(a).afficher_EDT() +  "\n";
           }
           texte+="\n\n";
        }
        return texte;
    }
    
    public Superviseur Search_Superviseur(String Nom)
    {
        int i =0;
        boolean aTrouvé = false;
        while(i<this.list.size() && aTrouvé == false)
        {
            if(this.list.get(i).getNom().toUpperCase().equals(Nom.toUpperCase()))
            {
                aTrouvé = true;
                return this.list.get(i);
            }else{
                
                 i++;
            }

        }
        if(aTrouvé == false)
        {
            return null;
        }
        else{
            return this.list.get(i);
        }
    }
}
