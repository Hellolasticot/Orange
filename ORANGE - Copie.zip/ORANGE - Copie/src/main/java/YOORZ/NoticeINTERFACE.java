/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author HugoBarboule
 */
public class NoticeINTERFACE extends Application{
    
    public void start(final Stage primaryStage) {
        
        //Il s'agit des dimensions de chaque écran  ==  ecran adapté
        Dimension dimension = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        int height = (int)dimension.getHeight();
        int width  = (int)dimension.getWidth();
        
        //Subdivision de l'écran :
        int totalh = height/54;
        int totalw = width/64;

        StringBuilder str = new StringBuilder();
        String texte = "";
        try{
            
            //On récupère le CSV dans les dossiers.
            InputStream input = getClass().getResource("/données/Notice.txt").openStream(); 
                Scanner scan = new Scanner(input, "UTF-8");
            

            String ligne = "\t";
            //Tant qu'il y a une ligne d'écrite sur le fichier CSV
            while(scan.hasNextLine())
            {
                texte += "\t"+scan.nextLine() +"\n";
                str.append(ligne);
                str.append("\n");
            }
            //r.close();
            input.close();
            //flux.close();
         }  
                    
        
        catch(IOException e){
            System.out.println("Une erreur est survenue lors de la lecture du bon CSV");
            e.printStackTrace();
        }
        
        
        
        VBox dialogVbox = new VBox(20);
        dialogVbox.getChildren().add(new Text(texte));
        Scene dialogScene = new Scene(dialogVbox, 900, height-200);
        primaryStage.setTitle("La Notice");
        primaryStage.setScene(dialogScene);
        primaryStage.show();
    }

}
