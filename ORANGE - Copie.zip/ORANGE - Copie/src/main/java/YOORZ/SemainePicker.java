/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

import java.awt.Dimension;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Callback;

/**
 *
 * @author HugoBarboule
 */
public class SemainePicker extends Application{
    
    private HBox h = new HBox();
    
   private Cloud c;
   
   public void init_c(Cloud c)
    {
        this.c = c;
    }
    
      @Override
    public void start(Stage s){
       
       //Il s'agit des dimensions de chaque écran  ==  ecran adapté
        Dimension dimension = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        int height = (int)dimension.getHeight();
        int width  = (int)dimension.getWidth();
        
        //Subdivision de l'écran :
        int totalh = height/54;
        int totalw = width/64;
  
        
 
        Button bAcceptDate = new Button("Valider Date");
        bAcceptDate.setLayoutX(200);
        bAcceptDate.setLayoutY(300);
        
       
            bAcceptDate.setOnAction(new EventHandler<ActionEvent>() {
                                            
                 @Override 
                 public void handle(ActionEvent e) {
                     
                 }
            });
        
        Group g = new Group();
        //On les mets dans le Group
        g.getChildren().addAll(bAcceptDate);

        
        //Création de la Page
        Scene scene = new Scene(g, 500, 500, Color.KHAKI);
        
        
        //Paramètres de la Page
        s.setTitle("Saisir une semaine");
        s.setScene(scene);
        s.show();
        s.setResizable(false);
   }
    
}
