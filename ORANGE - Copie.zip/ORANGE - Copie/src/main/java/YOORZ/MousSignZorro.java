/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

/**
 *
 * @author HugoBarboule
 */
import java.awt.AWTException;
import java.awt.Robot;
 

public class MousSignZorro {
 
    public MousSignZorro() throws AWTException {
        Robot robot = new Robot();
        /**
         * Fixer le delai entre chaque mouvement à 500 ms
         */
        robot.setAutoDelay(50);
        /**
         * Appeler OnIdle après le déplacement de la souris
         */
        robot.setAutoWaitForIdle(false);
        /**
         * Barre du haut
         */
        for (int i = 0; i < 20; i++) {
            robot.mouseMove(300+(20*i), 400);
        }
        /**
         * Diagonale
         */
        for (int i = 0; i < 20; i++) {
            robot.mouseMove(700-(20*i), 400+(20*i));
        }
        /**
         * Barre du bas
         */
        for (int i = 0; i < 20; i++) {
            robot.mouseMove(300+(20*i), 800);
        }
 
        /**
         * Quitter l'application
         */
        System.exit(0);
    }
 
    public static void main(String[] args) throws AWTException {
        MousSignZorro mouseCatchMe = new MousSignZorro();
    }
}