/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

import java.awt.Desktop;
import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 *
 * @author HugoBarboule
 */
public class ImportationFichierINTERFACE extends Application{
    
    private Desktop desktop = Desktop.getDesktop();
    private boolean verif = false;
    
    public boolean get_verif()
    {
        return this.verif;
    }
 
    @Override
    public void start(Stage primaryStage) throws Exception {
 
        //Il s'agit des dimensions de chaque écran  ==  ecran adapté
        Dimension dimension = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        int height = (int)dimension.getHeight();
        int width  = (int)dimension.getWidth();
        
        //Subdivision de l'écran :
        int totalh = height/54;
        int totalw = width/64;
        
        
        final FileChooser fileChooser = new FileChooser();
 
        TextArea textArea = new TextArea();
        textArea.setMinHeight(70);
 
        // Importer le bouton Compétences.txt
        Button button1 = new Button("Chercher la liste \ndes Superviseurs");
        button1.setPrefSize(200, 400);
        
        // Importer le bouton JOURNEES_SUPERVISEURS.txt
        Button button2 = new Button("Chercher la liste \ndes EDT");
        button2.setPrefSize(200, 400);
        
        // Importer le bouton Listeactivités.csv
        Button button3 = new Button("Chercher la liste \ndes Activités");
        button3.setPrefSize(200, 400);
        
        
        // Importer le bouton Listeactivités.csv
        Button bra1 = new Button("Retour à l'importation \nde la liste des Superviseurs");
        bra1.setPrefSize(200, 400);

        
        // Importer le bouton Listeactivités.csv
        Button bra2 = new Button("Retour à l'importation \nde la liste des EDT");
        bra2.setPrefSize(200, 400);
        
        // Importer le bouton Listeactivités.csv
        Button bra3 = new Button("Retour à l'importation \nde la liste des Activités");
        bra3.setPrefSize(200, 400);
 
 
        
        // Importer le bouton Listeactivités.csv
        Button bok = new Button("Finis !");
        bok.setPrefSize(200, 400);

        
        Label l = new Label("___________________________________________________________________");
        
        Button raInit = new Button("Retour à l'Initialisation");
        raInit.setLayoutX(50);
        raInit.setLayoutY(height-100);
        
        //Action en cliquant sur le Bouton retour arriere
                raInit.setOnMouseClicked(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                      
                        if(event.getClickCount() >= 1)
                        {
                            primaryStage.close();
                        }

                    }
                 }); 
 
        button1.setOnAction(new EventHandler<ActionEvent>() {
 
            @Override
            public void handle(ActionEvent event) {
                textArea.clear();
                File file = fileChooser.showOpenDialog(primaryStage);
                
                if (file != null) {
                    openFile(file);
                    List<File> files = Arrays.asList(file);
                    textArea.setText("Bien importé !\n");
                    printLog(textArea, files);
                    
                    for(File f: files)
                    {
                        File f1 = new File(System.getProperty("user.home") + "/Desktop");
                        File rep = searchFile("ORANGE", f1);
                        
                        File ftemp = new File(rep, "Compétences.txt");
                        try{
                        
                        ftemp.createNewFile();
                        
                        BufferedReader br = new BufferedReader(new FileReader(f.getPath()));
                        BufferedWriter bw = new BufferedWriter(new FileWriter(ftemp.getPath()));
                        String line;
                        while((line = br.readLine()) != null)
                        {
                            bw.write(line);
                            bw.newLine();
                        }
                        bw.close();
                        
                        boolean resultat = false;
                        if(VerifFile(primaryStage, 0, ftemp))
                            {
                                File fsupp = new File(rep.getPath()+"\\Compétences.txt");
                                fsupp.delete();
                                resultat = true;
                            }
                        
                                System.out.println(ftemp.getPath());
                                if (!resultat)
                                {
                                    Alert a  = new Alert(AlertType.ERROR, "Impossible de déplacer le fichier : "+ ftemp.getName());
                                    a.show();  
                                }
                                button3.setVisible(false);
                                button2.setVisible(true);
                                button1.setVisible(false);
                                bra1.setVisible(true);
                                bra2.setVisible(false);
                                bok.setVisible(false);
                                
                        
                        
                        }catch(Exception e)
                        {
                            e.printStackTrace();
                        }
                        
                        
                    }
                }
            }
        });
        
        
        
        
 
        button2.setOnAction(new EventHandler<ActionEvent>() {
 
            @Override
            public void handle(ActionEvent event) {
                textArea.clear();
                File file = fileChooser.showOpenDialog(primaryStage);
                
                if (file != null) {
                    openFile(file);
                    List<File> files = Arrays.asList(file);
                    textArea.setText("Bien importé !\n");
                    printLog(textArea, files);
                    
                    for(File f: files)
                    {
                        File f1 = new File(System.getProperty("user.home") + "/Desktop");
                        File rep = searchFile("ORANGE", f1);
                        
                        File ftemp = new File(rep, "JOURNEES_SUPERVISEURS.txt");
                        try{
                        
                        ftemp.createNewFile();
                        
                        BufferedReader br = new BufferedReader(new FileReader(f.getPath()));
                        BufferedWriter bw = new BufferedWriter(new FileWriter(ftemp.getPath()));
                        String line;
                        while((line = br.readLine()) != null)
                        {
                            bw.write(line);
                            bw.newLine();
                        }
                        bw.close();
                        
                        boolean resultat = false;
                        if(VerifFile(primaryStage, 1, ftemp))
                            {
                                File fsupp = new File(rep.getPath()+"\\JOURNEES_SUPERVISEURS.txt");
                                fsupp.delete();
                                resultat = true;
                            }
                        
                                System.out.println(ftemp.getPath());
                                if (!resultat)
                                {
                                    Alert a  = new Alert(AlertType.ERROR, "Impossible de déplacer le fichier : "+ ftemp.getName());
                                    a.show();  
                                }
                                
                                button1.setVisible(false);
                                button2.setVisible(false);
                                button3.setVisible(true);
                                bra2.setVisible(true);
                                bra1.setVisible(false);
                        
                        
                        }catch(Exception e)
                        {
                            e.printStackTrace();
                        }
                        
                        
                        
                    }
                }
            }
        });
        
        
        
        
        button3.setOnAction(new EventHandler<ActionEvent>() {
 
            @Override
            public void handle(ActionEvent event) {
                textArea.clear();
                File file = fileChooser.showOpenDialog(primaryStage);
                
                if (file != null) {
                    openFile(file);
                    List<File> files = Arrays.asList(file);
                    textArea.setText("Bien importé !\n");
                    printLog(textArea, files);
                    
                    
                    for(File f: files)
                    {
                        File f1 = new File(System.getProperty("user.home") + "/Desktop");
                        File rep = searchFile("ORANGE", f1);
                        
                        File ftemp = new File(rep, "Listeactivités.csv");
                        try{
                        
                        ftemp.createNewFile();
                        
                        BufferedReader br = new BufferedReader(new FileReader(f.getPath()));
                        BufferedWriter bw = new BufferedWriter(new FileWriter(ftemp.getPath()));
                        String line;
                        while((line = br.readLine()) != null)
                        {
                            bw.write(line);
                            bw.newLine();
                        }
                        bw.close();
                        
                        boolean resultat = false;
                        if(VerifFile(primaryStage, 2, ftemp))
                            {
                                File fsupp = new File(rep.getPath()+"\\Listeactivités.csv");
                                fsupp.delete();
                                resultat = true;
                            }
                        
                                System.out.println(ftemp.getPath());
                                if (!resultat)
                                {
                                    Alert a  = new Alert(AlertType.ERROR, "Impossible de déplacer le fichier : "+ ftemp.getName());
                                    a.show();  
                                }
                                
                                bok.setVisible(true);
                                button2.setVisible(false);
                                button3.setVisible(false);
                                bra2.setVisible(false);
                                bra1.setVisible(false);
                                bra3.setVisible(true);
                                
                                
                        
                        
                        }catch(Exception e)
                        {
                            e.printStackTrace();
                        }
                        
                        
                        
                    }
                }
            }
        });
        
        
        bra1.setOnAction(new EventHandler<ActionEvent>() {
 
            @Override
            public void handle(ActionEvent event) {
                textArea.clear();
                textArea.setText("Changement de fichier pour la liste des Superviseurs\n");
                button1.setVisible(true);
                bra1.setVisible(false);
                button2.setVisible(false);
                button3.setVisible(false);
                
            }
        });
        
        bra2.setOnAction(new EventHandler<ActionEvent>() {
 
            @Override
            public void handle(ActionEvent event) {
                textArea.clear();
                textArea.setText("Changement de fichier pour la liste des EDT\n");
                button2.setVisible(true);
                bra1.setVisible(true);
                bra2.setVisible(false);
                button3.setVisible(false);
                button1.setVisible(false);
                
            }
        });
        
        bra3.setOnAction(new EventHandler<ActionEvent>() {
 
            @Override
            public void handle(ActionEvent event) {
                textArea.clear();
                textArea.setText("Changement de fichier pour la liste des Activités\n");
                button1.setVisible(false);
                bra1.setVisible(false);
                button2.setVisible(false);
                button3.setVisible(true);
                bra3.setVisible(false);
                bra2.setVisible(true);
                verif = true;
                
            }
        });
        
        bok.setOnAction(new EventHandler<ActionEvent>() {
 
            @Override
            public void handle(ActionEvent event) {
                primaryStage.close();
            }
        });
        
        
 
        button2.setVisible(false);
        button3.setVisible(false);
        bra1.setVisible(false);
        bra2.setVisible(false);
        bok.setVisible(false);
        bra3.setVisible(false);
        
        VBox root = new VBox();
        root.setPadding(new Insets(10));
        root.setSpacing(10);
 
        root.getChildren().addAll(textArea, button1, button2, button3, l, raInit, bra1, bra2, bra3, bok);
 
        Scene scene = new Scene(root, 600, 600);
 
        primaryStage.setTitle("Chercher les fichiers et importer-les dans l'application !");
        primaryStage.setScene(scene);
        primaryStage.show();
        primaryStage.setMinHeight(400);
        primaryStage.setMinWidth(500);
        primaryStage.setResizable(false);
    }
 
    private void printLog(TextArea textArea, List<File> files) {
        if (files == null || files.isEmpty()) {
            return;
        }
        for (File file : files) {
            textArea.appendText(file.getAbsolutePath() + "\n");
        }
    }
 
    private void openFile(File file) {
        try {
            this.desktop.open(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        Application.launch(args);
    }
    
    
    public File searchFile(String fileToFind, File searchIn) {
		File[] listOfFiles = searchIn.listFiles();
		Vector<File> listOfDirectories = new Vector<File>();
		Vector<File> listOfSimpleFiles = new Vector<File>();
		for (File file : listOfFiles) {
			if (file.isDirectory())
				listOfDirectories.add(file);
			else
				listOfSimpleFiles.add(file);		
		}
		boolean find = false;
		while (!find) {
			int i = 0;
			while (i < listOfSimpleFiles.size() && !find) {
				if (listOfSimpleFiles.get(i).getName()
						.equalsIgnoreCase(fileToFind)) {
					listOfSimpleFiles.get(i);
				} else
					i++;
			}
			int j = 0;
			while ((j < listOfDirectories.size()) && !find) {
				if(listOfDirectories.get(j).getName().equalsIgnoreCase(fileToFind))
					return listOfDirectories.get(j);
				else if(searchFile(fileToFind, listOfDirectories.get(j)) != null)
					return listOfDirectories.get(j);
				else
					j++;
			}
			return null;
		}		
		return null;
	}

    
    public boolean VerifFile(Stage s, int cas, File f)
    {
        boolean verif = false;
        switch(cas){
 
            
            // La liste des Superviseurs (Compétences.txt)
            case 0:
                
                StringBuilder str = new StringBuilder();
                try{
                    //On récupère le CSV dans les dossiers.
                    InputStream flux = new FileInputStream(f.getName());
            
                    InputStreamReader input = new InputStreamReader(flux, "Cp1252");
                    BufferedReader r = new BufferedReader(input);
            
                    String Texte = "";
                    String ligne = "";
                    int compteur = 0;
                    //Tant qu'il y a une ligne d'écrite sur le fichier CSV
                    while(((ligne = r.readLine()) != null) && compteur<1)
                    {
                        compteur ++;
                        str.append(ligne);
                        str.append("\n");
                        Texte += ligne;
                    }
                    
                    String[] tab = Texte.split(";");
                    boolean isNumeric1 = tab[4].matches("[+-]?\\d*(\\.\\d+)?");
                    boolean isNumeric2 = tab[5].matches("[+-]?\\d*(\\.\\d+)?");
                    boolean isNumeric3 = tab[6].matches("[+-]?\\d*(\\.\\d+)?");
                    boolean isNumeric4 = tab[7].matches("[+-]?\\d*(\\.\\d+)?");
                    boolean isNumeric5 = tab[8].matches("[+-]?\\d*(\\.\\d+)?");
                    
                    if(tab.length != 9 || !isNumeric1 || !isNumeric2 || !isNumeric3 || !isNumeric4 || !isNumeric5)
                    {
                        Alert al = new Alert(AlertType.ERROR, "Vous n'avez pas indiqué le bon document à importer : \n"
                                + "Nous demandons d'importer la liste des superviseurs (Compétence.txt) sur ACCESS (table)");
                        al.show();
                        f.delete();
                        s.close();
                    }else{
                        verif = true;
                    }
                    
                }catch(IOException e)
                {
                    e.printStackTrace();
                }
                
                break;
                
           // Les réunions des Superviseurs (JOURNEESUPERVISEURS.txt)
            case 1:
                
                StringBuilder str1 = new StringBuilder();
                try{
                    //On récupère le CSV dans les dossiers.
                    InputStream flux = new FileInputStream(f.getName());
            
                    InputStreamReader input = new InputStreamReader(flux, "Cp1252");
                    BufferedReader r = new BufferedReader(input);
            
                    String Texte = "";
                    String ligne = "";
                    int compteur = 0;
                    //Tant qu'il y a une ligne d'écrite sur le fichier CSV
                    while(((ligne = r.readLine()) != null) && compteur<1)
                    {
                        compteur ++;
                        str1.append(ligne);
                        str1.append("\n");
                        Texte += ligne;
                    }
                    
                    String[] tab = Texte.split(";");
                    if(tab.length != 5)
                    {
                        Alert al = new Alert(AlertType.ERROR, "Vous n'avez pas indiqué le bon document à importer : \n"
                                + "Nous demandons d'importer la liste des réunions et absences (JOURNEES_SUPERVISEURS.txt) sur ACCESS (requête)");
                        al.show();
                        f.delete();
                        s.close();
                    }else{
                        verif = true;
                    }
                    
                }catch(IOException e)
                {
                    e.printStackTrace();
                }
                
                break;
                
            // La liste des Activités (listeactivité.csv)
            case 2:
                
                StringBuilder str3 = new StringBuilder();
                try{
                    //On récupère le CSV dans les dossiers.
                    InputStream flux = new FileInputStream(f.getName());
            
                    InputStreamReader input = new InputStreamReader(flux, "Cp1252");
                    BufferedReader r = new BufferedReader(input);
            
                    String Texte = "";
                    String ligne = "";
                    int compteur = 0;
                    //Tant qu'il y a une ligne d'écrite sur le fichier CSV
                    while(((ligne = r.readLine()) != null) && compteur<1)
                    {
                        compteur ++;
                        str3.append(ligne);
                        str3.append("\n");
                        Texte += ligne;
                    }
                    
                    String[] tab = Texte.split(";");
                    boolean verif1 = (tab[0].toUpperCase().equals("Nom".toUpperCase()));
                    boolean verif2 = (tab[1].toUpperCase().equals("Description".toUpperCase()));
                    boolean verif3 = (tab[2].toUpperCase().equals("Poids".toUpperCase()));
                    boolean verif4 = (tab[3].toUpperCase().equals("Vue".toUpperCase()));
                    boolean verif5 = (tab[4].toUpperCase().equals("GSAT/GSR".toUpperCase()));
                    boolean verif6 = (tab[5].toUpperCase().equals("Type".toUpperCase()));
                    
                    
                    
                    if(tab.length != 6 || !verif1 || !verif2 || !verif3 || !verif4 || !verif5 || !verif6)
                    {
                        Alert al = new Alert(AlertType.ERROR, "Vous n'avez pas indiqué le bon document à importer : \n"
                                + "Nous demandons d'importer la liste des Activités (Listeactivités.csv) sur ACCESS (table)");
                        al.show();
                        f.delete();
                        s.close();
                    }else{
                        verif = true;
                    }
                    
                }catch(IOException e)
                {
                    e.printStackTrace();
                }
                
                break;
             
            default:
                verif = false;
                break; 
             
        }
        return verif;
    }
    
    
}
