/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;


import java.awt.Dimension;
import java.awt.MouseInfo;
import java.awt.PointerInfo;
import java.text.DateFormat;
import javafx.scene.text.Font;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.chart.AreaChart;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;
 
 
public class GraphiqueJourVrai extends Application {
    
    private Date d;
    Dimension dimension = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        int height = (int)dimension.getHeight();
        int width  = (int)dimension.getWidth();
        
        //Subdivision de l'écran :
        int totalh = height/54;
        int totalw = width/64;
        
        Font police = new Font("Arial", 17);
        
        private Cloud c = new Cloud();
        
    public void init_C(Cloud C)
    {
        this.c = C;
    }

    public GraphiqueJourVrai(Date jour) {
        this.d = jour;
    }

    public Date getJour() {
        return d;
    }
     
    
    @Override 
    public void start(Stage stage) {
        
        VBox root = new VBox();
        
        Menu menu = new Menu("Menu des Semaines");
        menu.setStyle("fx-background-color: blue;");
        
        Iterator i3 = c.get_le().get_ListeDesJoursRassemblésSemaine().entrySet().iterator();
        ArrayList<MenuItem> listButton = new ArrayList<MenuItem>();
        while(i3.hasNext())
        {
             Map.Entry mapentry = (Map.Entry) i3.next();
             MenuItem choice = new MenuItem(String.valueOf((int) mapentry.getKey()));
             listButton.add(choice);
        }
        
        SeparatorMenuItem s = new SeparatorMenuItem();
        
        for(int i = 0; i<listButton.size(); i++)
        {
            menu.getItems().add(listButton.get(i));
            menu.getItems().add(s);
        }
        
        MenuBar menuBar = new MenuBar();
        menuBar.getMenus().add(menu);

        
        Menu menu2 = new Menu("Stats par jour");
        
        MenuItem mi = new MenuItem("Quel jour ?");
       
           mi.setOnAction(new EventHandler<ActionEvent>() {
                                            
                 @Override 
                 public void handle(ActionEvent e) {
                     
                     DatePicker2INTERFACE dt = new DatePicker2INTERFACE();
                     Stage s = new Stage();
                     dt.init_c(c);
                     dt.start(s);
                     stage.close();
                 }
            });
           
           menu2.getItems().add(mi);
        menuBar.getMenus().add(menu2);
        
        
        for(int i = 0; i<listButton.size(); i++)
        {
           int num = Integer.parseInt(listButton.get(i).getText());
           
            //ACTION QUAND ON CLIQUE SUR UNE SEMAINE
           listButton.get(i).setOnAction(new EventHandler<ActionEvent>() {

               @Override 
                public void handle(ActionEvent e) {
                    
                    GraphiqueSemaine gs = new GraphiqueSemaine(num);
                    try{
                        Stage s = new Stage();
                        gs.init_C(c);
                        gs.start(s);
                        
                        stage.close();
                        
                    }catch(Exception ex){
                        ex.printStackTrace();
                    }
                }
           });
        }
        
        //menu des mois
        Menu menu3 = new Menu("Liste des Mois disponible");
        menuBar.getMenus().add(menu3);
        Iterator i5 = c.get_le().getMapJourParMoisSemaine().entrySet().iterator();
        ArrayList<MenuItem> listButton2 = new ArrayList<MenuItem>();
        while(i5.hasNext())
        {
             Map.Entry mapentry = (Map.Entry) i5.next();
             MenuItem choice = new MenuItem(String.valueOf((int) mapentry.getKey()));
             listButton2.add(choice);
        }
        
        
        for(int i = 0; i<listButton2.size(); i++)
        {
            menu3.getItems().add(listButton2.get(i));
            menu3.getItems().add(s);
        }
        
        for(int i = 0; i<listButton2.size(); i++)
        {
           int num = Integer.parseInt(listButton2.get(i).getText());
           
            //ACTION QUAND ON CLIQUE SUR UNE SEMAINE
           listButton2.get(i).setOnAction(new EventHandler<ActionEvent>() {

               @Override 
                public void handle(ActionEvent e) {
                    
                    GraphiqueMoisJour gmj= new GraphiqueMoisJour(num);
                    try{
                        Stage s = new Stage();
                        gmj.init_C(c);
                        gmj.start(s);
                        
                        stage.close();
                        
                    }catch(Exception ex){
                        ex.printStackTrace();
                    }
                }
           });
        }
        
        //Recupération des données
        ArrayList<Integer> liste = new ArrayList<Integer>();
        
        Iterator ite = c.get_le().get_MapNbJour().entrySet().iterator();
        
        boolean Atrouvé = false;
        while(ite.hasNext() && !Atrouvé)
        {
             Map.Entry mapentry = (Map.Entry) ite.next();
             Atrouvé = this.d.equals((Date) mapentry.getKey());
             if(Atrouvé)
             {
                 Iterator i2 = c.get_le().get_MapNbJour().get((Date) mapentry.getKey()).entrySet().iterator();
                 while(i2.hasNext())
                 {
                     Map.Entry mapentry2 = (Map.Entry) i2.next();
                     liste.add((int) mapentry2.getValue());
                 }
             }
        }
        // Fin de la récupération de données
        
        //affichage des données
        System.out.println(liste);
        
        
        
        if(!liste.isEmpty())
        {
            stage.setTitle("Line Chart des Disponibilités de la Journée");
            final CategoryAxis xAxis = new CategoryAxis();
            final NumberAxis yAxis = new NumberAxis();
            xAxis.setLabel("Tranches Horaires");       

            final BarChart<String,Number> lineChart = 
                    new BarChart<String,Number>(xAxis,yAxis);

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            String dt = sdf.format(d);
            lineChart.setTitle("Dispos du : "+dt);

            XYChart.Series series = new XYChart.Series();
            series.setName("Les dispo");

            series.getData().add(new XYChart.Data("07h-08h", liste.get(0)));
            series.getData().add(new XYChart.Data("08h-12h30", liste.get(1)));
            series.getData().add(new XYChart.Data("12h30-15h30", liste.get(2)));
            series.getData().add(new XYChart.Data("15h30-17h30", liste.get(3)));
            series.getData().add(new XYChart.Data("17h30-18h30", liste.get(4)));
            series.getData().add(new XYChart.Data("18h30-20h00", liste.get(5)));

           double moyenne = 0;
           for(int i = 0; i<=5; i++)
           {
               moyenne += liste.get(i);
           }
           moyenne = moyenne/6;
           
           
           Label moy = new Label("\tMoyenne des disponibilités : "+moyenne);
           moy.setFont(police);

            root.getChildren().addAll(menuBar, lineChart, moy);
            Scene scene  = new Scene(root, width, height-150);
            lineChart.getData().add(series);
            
             //now you can get the nodes.
            for (XYChart.Series<String,Number> serie: lineChart.getData()){
                for (XYChart.Data<String, Number> item: serie.getData()){
                    
                    
                    item.getNode().setOnMouseClicked((MouseEvent event) -> {
                        item.getNode().setStyle("-fx-border-color: blue;"+"-fx-border-width: 5;");
                        
                        double deb;
                        int i = 0; 
                        int tranche = 0;
                        boolean atrouvé = false;
                        while(i<serie.getData().size() && !atrouvé)
                        {
                            atrouvé = ( serie.getData().get(i).equals(item) );
                            if(atrouvé)
                            {
                               
                                tranche = i+1;
                                
                            }else{
                                i++;
                            }
                        }
                        
                        switch(tranche)
                        {
                            case 1:
                                deb = 7.0;
                                break;
                            case 2:
                                deb = 8.0;
                                break;
                            case 3:
                                deb = 12.5;
                                break;
                            case 4:
                                deb = 15.5;
                                break;
                            case 5:
                                deb = 17.5;
                                break;
                            case 6:
                                deb = 18.5;
                                break;
                            case 7:
                                deb = 20.0;
                                break;
                            default :
                                deb = 0.0;
                                break;
                                    
                        }
                        
                        DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
                        String dateAsString = df.format(this.d);
                        
                        String clé = dateAsString + " - "+deb;
                        
                        Stage stage1 = new Stage();
                        DonnéeSuperviseurSurJourINTERFACE dssji = new DonnéeSuperviseurSurJourINTERFACE(clé);
                        dssji.init_c(this.c); 
                        dssji.start(stage1);
                        
                        
                        
                        
                        
                        
                    });
                    
                    item.getNode().setOnMouseReleased((MouseEvent event) -> {
                        item.getNode().setStyle("-fx-border-width: 0;");
                        
                    });
                    
                    
                    item.getNode().setOnMouseEntered((MouseEvent event) -> {
                       
                        item.getNode().setStyle("-fx-border-color: red;"+"-fx-border-width: 3;");
                        HBox h = new HBox();
                        Paint p2 = Paint.valueOf("#D3D3D3");
                        //h.setBackground(new Background(new BackgroundFill(p2, CornerRadii.EMPTY, Insets.EMPTY)));
                        Label l = new Label();
                        String texte ="";
                        texte += "\n"+" Valeur sur l'axe Y : "+item.getYValue().intValue()+" \n\n";
                        
                        
                        Paint p = Paint.valueOf("#008000");
                        l.setTextFill(p);
                        l.setBackground(new Background(new BackgroundFill(p2, CornerRadii.EMPTY, Insets.EMPTY)));
                        
                        
                        PointerInfo pointer = MouseInfo.getPointerInfo(); 
                        java.awt.Point location = pointer.getLocation();  
                        
                        
                        h.getChildren().add(l);
                        l.setLayoutY(location.getY());
                        if(location.getX() >= (width*17)/totalw)
                        {
                             l.setLayoutX(location.getX()-100);
                             
                        }else{
                            
                            l.setLayoutX(location.getX());
                        }
                        
                        
                        root.getChildren().add(l);
                        
                    });
                    
                    
                    
                    item.getNode().setOnMouseExited((MouseEvent event) -> {
                        item.getNode().setStyle("-fx-border-width: 0;");
                         root.getChildren().clear();
                         VBox v = new VBox();
                         v.setPrefWidth(width);
                         v.getChildren().addAll(menuBar, lineChart);
                         root.getChildren().add(v);
                         
                         lineChart.setMinSize(width-20, height-200);

                    });
                }//fin boucle 1
            }//fin boucle 2
            
            
            
            

            stage.setScene(scene);
            stage.show();
            
        }else{
            Label l = new Label("Il n'y a aucune donnée à cette date");
            
            Scene scene  = new Scene(l,200, 100);

            stage.setScene(scene);
            stage.show();
            
        }
            
        
    }
 
}