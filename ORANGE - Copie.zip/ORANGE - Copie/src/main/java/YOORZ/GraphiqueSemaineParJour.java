/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

import java.awt.Dimension;
import java.awt.MouseInfo;
import java.awt.PointerInfo;
import javafx.scene.text.Font;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Map;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.ToolBar;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;
import java.util.HashMap;
 
 
public class GraphiqueSemaineParJour extends Application {
    
    private int semaine;
    //Il s'agit des dimensions de chaque écran  ==  ecran adapté
        Dimension dimension = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        int height = (int)dimension.getHeight();
        int width  = (int)dimension.getWidth();
        
        //Subdivision de l'écran :
        int totalh = height/54;
        int totalw = width/64;
        
        Font police = new Font("Arial", 20);
        
        private Cloud c = new Cloud();
        
    public void init_C(Cloud C)
    {
        this.c = C;
    }

    public GraphiqueSemaineParJour(int semaine) {
        this.semaine = semaine;
    }

    public int getJour() {
        return semaine;
    }
    
    public Cloud get_C()
    {
        return this.c;
    }
     
    
        private  ArrayList<Integer> donnéeJour = new ArrayList<Integer>();

    public ArrayList<Integer> getDonnéeJour() {
        return donnéeJour;
    }
        
    
    @Override 
    public void start(Stage stage) {
        VBox root = new VBox();
        
        Group g = new Group();
        ToolBar toolBar = new ToolBar();
        HBox v2 = new HBox(toolBar);
        Menu menu = new Menu("Menu des Semaines");
        menu.setStyle("fx-background-color: blue;");
        
        Iterator i3 = c.get_le().get_ListeDesJoursRassemblésSemaine().entrySet().iterator();
        ArrayList<MenuItem> listButton = new ArrayList<MenuItem>();
        while(i3.hasNext())
        {
             Map.Entry mapentry = (Map.Entry) i3.next();
             MenuItem choice = new MenuItem(String.valueOf((int) mapentry.getKey()));
             listButton.add(choice);
        }
        
        SeparatorMenuItem s = new SeparatorMenuItem();
        
        for(int i = 0; i<listButton.size(); i++)
        {
            menu.getItems().add(listButton.get(i));
            menu.getItems().add(s);
        }
        
        MenuBar menuBar = new MenuBar();
        menuBar.getMenus().add(menu);

        
        Menu menu2 = new Menu("Stats par jour");
        
        MenuItem mi = new MenuItem("Quel jour ?");
       
           mi.setOnAction(new EventHandler<ActionEvent>() {
                                            
                 @Override 
                 public void handle(ActionEvent e) {
                     
                     DatePicker2INTERFACE dt = new DatePicker2INTERFACE();
                     Stage s = new Stage();
                     dt.init_c(c);
                     dt.start(s);
                     stage.close();
                 }
            });
           
           menu2.getItems().add(mi);
        menuBar.getMenus().add(menu2);
        
        
        for(int i = 0; i<listButton.size(); i++)
        {
           int num = Integer.parseInt(listButton.get(i).getText());
           
            //ACTION QUAND ON CLIQUE SUR UNE SEMAINE
           listButton.get(i).setOnAction(new EventHandler<ActionEvent>() {

               @Override 
                public void handle(ActionEvent e) {
                    
                    GraphiqueSemaine gs = new GraphiqueSemaine(num);
                    try{
                        Stage s = new Stage();
                        gs.init_C(c);
                        gs.start(s);
                        
                        stage.close();
                        
                    }catch(Exception ex){
                        ex.printStackTrace();
                    }
                }
           });
        }
        
        //menu des mois
        Menu menu3 = new Menu("Liste des Mois disponible");
       menuBar.getMenus().add(menu3);
        Iterator i5 = c.get_le().getMapJourParMoisSemaine().entrySet().iterator();
        ArrayList<MenuItem> listButton2 = new ArrayList<MenuItem>();
        while(i5.hasNext())
        {
             Map.Entry mapentry = (Map.Entry) i5.next();
             MenuItem choice = new MenuItem(String.valueOf((int) mapentry.getKey()));
             listButton2.add(choice);
        }
        
        
        for(int i = 0; i<listButton2.size(); i++)
        {
            menu.getItems().add(listButton2.get(i));
            menu.getItems().add(s);
        }
        
        for(int i = 0; i<listButton2.size(); i++)
        {
           int num = Integer.parseInt(listButton2.get(i).getText());
           
            //ACTION QUAND ON CLIQUE SUR UNE SEMAINE
           listButton2.get(i).setOnAction(new EventHandler<ActionEvent>() {

               @Override 
                public void handle(ActionEvent e) {
                    
                    GraphiqueMoisJour gmj= new GraphiqueMoisJour(num);
                    try{
                        Stage s = new Stage();
                        gmj.init_C(c);
                        gmj.start(s);
                        
                        stage.close();
                        
                    }catch(Exception ex){
                        ex.printStackTrace();
                    }
                }
           });
        }
        
        //Recupération des données
        ArrayList<Integer> liste = new ArrayList<Integer>();
        
        Iterator ite = c.get_le().get_ListeDesJoursRassemblésSemaine().entrySet().iterator();
        
        boolean Atrouvé = false;
        ArrayList<Jour> listJour = new ArrayList<Jour>();
        
        while(ite.hasNext() && !Atrouvé)
        {
             Map.Entry mapentry = (Map.Entry) ite.next();
             Atrouvé = (this.semaine == (int) mapentry.getKey());
             if(Atrouvé)
             {
                 Iterator i = c.get_le().get_ListeDesJoursRassemblésSemaine().get((int) this.semaine).iterator();
                 while(i.hasNext())
                 {
                     Jour jtemp = (Jour) i.next();
                     Iterator i2 = jtemp.getMap().entrySet().iterator();
                     listJour.add(jtemp);
                     while(i2.hasNext())
                     {
                         Map.Entry mapentry2 = (Map.Entry) i2.next();
                         liste.add((int) mapentry2.getValue());
                         
                     }
                 }
             }
        }
        // Fin de la récupération de données

        
        if(!liste.isEmpty())
        {
            stage.setTitle("Bar Chart des Disponibilités de la Semaine");
            final CategoryAxis xAxis = new CategoryAxis();
            final NumberAxis yAxis = new NumberAxis();
            xAxis.setLabel("Jours de le Semaine");       

            final BarChart<String,Number> lineChart = 
                    new BarChart<String,Number>(xAxis,yAxis);

            lineChart.setTitle("Dispos de la semaine : "+this.semaine);
            
            Iterator i4 = listJour.iterator();
            
            HashMap<Integer, XYChart.Data<String, Number>> mapXY = new HashMap<Integer, XYChart.Data<String, Number>>();
            ArrayList<XYChart.Data<String, Number>> listxy = new ArrayList<XYChart.Data<String, Number>>();
            XYChart.Series series = new XYChart.Series();
            Calendar c = Calendar.getInstance();
            ArrayList<String> Jours = new ArrayList<String>();
            while(i4.hasNext())
            {
                Jour jtemp2 = (Jour) i4.next();
                
                c.setTime(jtemp2.getD());
                int nb = c.get(Calendar.DAY_OF_WEEK);
                String nom="";
                switch(nb-2)
                {
                    case 0:
                        nom = "LUNDI";
                    break;
                    case 1:
                        nom = "MARDI";
                    break;
                    case 2:
                        nom = "MERCREDI";
                    break;
                    case 3:
                        nom = "JEUDI";
                    break;
                    case 4:
                        nom = "VENDREDI";
                    break;
                    case 5:
                        nom = "SAMEDI";
                    break;
                    default:
                        nom="DIMANCHE";
                    break;
                }
                
                Jours.add(nom);
            }    
            
            ArrayList<Integer> listDonnées = new ArrayList<Integer>();
            int indice = 0;
            //On met les données :
            // 6 car il y a 6 tranches Horaires (on passe 6 fois dans les jours)
            /*
            Pour chaque tranche horaire, on met pour chaque jour sa donnée
            */
            int dl =0;
            int dma = 0;
            int dme = 0;
            int dj = 0;
            int dv = 0;
            int ds = 0;
            int dd = 0;
            for(int i = 0; i<6; i++)
            {
                if(!Jours.isEmpty())
                {
                    int iii = 0;
                    //Pour chaque jour
                    int données = 0;
                    
                    for(int ii = 0; ii<Jours.size(); ii++)
                    {
                        XYChart.Data<String, Number> xy = new XYChart.Data(Jours.get(ii), liste.get(iii+i));
                        series.getData().add(xy);
                        listxy.add(xy); 
                        mapXY.put(indice, xy);

                        données += liste.get(iii+i); 
                        switch(ii)
                        {
                            case 0:
                                dl+=liste.get(iii+i);
                            break;
                            case 1:
                                dma+=liste.get(iii+i);
                            break;
                            case 2:
                                dme+=liste.get(iii+i);
                            break;
                            case 3:
                                dj +=liste.get(iii+i);
                            break;
                            case 4:
                                dv +=liste.get(iii+i);
                            break;
                            case 5:
                                ds+=liste.get(iii+i);
                            break;
                            case 6:
                                dd+=liste.get(iii+i);
                            break;
                        }
 
                        indice ++;
                        iii+=6;
                    }
                    listDonnées.add(données);
                    
                    lineChart.getData().add(series);
                    
                    series = new XYChart.Series();
                }
            }
            
           
            donnéeJour.add(dl);donnéeJour.add(dma);donnéeJour.add(dme);donnéeJour.add(dj);donnéeJour.add(dv);donnéeJour.add(ds);donnéeJour.add(dd);

              Label lv = new Label("\t\t\t 1ere barre : 7h - 8h\t\t 2eme barre : 8h - 12h30\t\t 3eme barre : 12h30 - 15h30 \t\t 4eme barre : 15h30 - 17h30\t\t"
                    + "5eme barre : 17h30 - 18h30\t\t 6eme barre : 18h30 - 20h\n_____\n");
            
             
              for(int i = 0; i<lineChart.getData().size(); i++)
                        {
                            for(int ii = 0; ii<lineChart.getData().get(i).getData().size(); ii++)
                            {
                                int indice1 = i;
                                String jour = lineChart.getData().get(i).getData().get(ii).getXValue();
                                lineChart.getData().get(i).getData().get(ii).getNode().setOnMouseClicked((MouseEvent event) -> {
                                    
                                      String dayii2;
                                      int nbi2 = indice1;
                                      dayii2 = jour;

                                     String tranchehoraire = "";
                                        switch(nbi2)
                                        {
                                            case 0:
                                                tranchehoraire = "7.0";
                                                break;
                                            case 1:
                                                tranchehoraire = "8.0";
                                                break;
                                            case 2:
                                                tranchehoraire = "12.5";
                                                break;
                                            case 3:
                                                tranchehoraire = "15.5";
                                                break; 
                                            case 4:
                                                tranchehoraire = "17.5";
                                                break;
                                            case 5:
                                                tranchehoraire = "18.5";
                                                break;
                                            default:
                                                tranchehoraire = "";
                                               break;


                                        }

                                        String clé = this.semaine + " " +dayii2 + " - " + tranchehoraire;


                                        boolean At = false;
                                        Iterator iterator = this.c.get_le().getMapDesSuperviseurs().entrySet().iterator();
                                        while(iterator.hasNext() && !At)
                                        {
                                            Map.Entry mapentry = (Map.Entry) iterator.next();
                                            At = ((String) mapentry.getKey()).equals(clé);
                                            
                                            if(At)
                                            {
                                                Stage stage1 = new Stage();
                                                LesSuperviseursHorairePreciseSemaine ls = new LesSuperviseursHorairePreciseSemaine(clé, this.c);
                                                ls.start(stage1);
                                                

                                            }
                                        }
                                    
                                }); // fin de si on clique dessus
                               
                            }
                        }
            

            //now you can get the nodes.
            for (XYChart.Series<String,Number> serie: lineChart.getData()){
                for (XYChart.Data<String, Number> item: serie.getData()){
                    
                                      
                    item.getNode().setOnMouseReleased((MouseEvent event) -> {
                        item.getNode().setStyle("-fx-border-color: red;"+"-fx-border-width: 0;");
                                                
                    });
                    
                    
                    item.getNode().setOnMouseEntered((MouseEvent event) -> {
                       
                        item.getNode().setStyle("-fx-border-color: blue;"+"-fx-border-width: 3;");
                        HBox h = new HBox();
                        Paint p2 = Paint.valueOf("#D3D3D3");
                        //h.setBackground(new Background(new BackgroundFill(p2, CornerRadii.EMPTY, Insets.EMPTY)));
                        Label l = new Label();
                        String texte ="";
                        texte += "\n"+" Valeur sur l'axe Y : "+item.getYValue().intValue()+" \n\n";
                        
                        int moyenneH = 0;
                        for(int i = 0; i<listxy.size(); i++)
                        {
                            
                            if(listxy.get(i).getXValue().equals(item.getXValue()))
                            {
                                
                                moyenneH += listxy.get(i).getYValue().intValue();
                            }
                                
                            
                        }
                        moyenneH = moyenneH/6;
                        texte += " Moyenne sur ce jour: "+ moyenneH + " \n\n";
                        
                        l.setText(texte);
                        Font f = new Font("TimesRoman", 10);
                        l.setFont(f);
                        Paint p = Paint.valueOf("#008000");
                        l.setTextFill(p);
                        l.setBackground(new Background(new BackgroundFill(p2, CornerRadii.EMPTY, Insets.EMPTY)));
                        
                        
                        PointerInfo pointer = MouseInfo.getPointerInfo(); 
                        java.awt.Point location = pointer.getLocation();  
                        
                        
                        h.getChildren().add(l);
                        l.setLayoutY(location.getY());
                        if(location.getX() >= (width*17)/totalw)
                        {
                             l.setLayoutX(location.getX()-100);
                             
                        }else{
                            
                            l.setLayoutX(location.getX());
                        }
                        
                        
                        g.getChildren().add(l);
                        
                    });
                    
                    
                    
                    item.getNode().setOnMouseExited((MouseEvent event) -> {
                        item.getNode().setStyle("-fx-border-width: 0;");
                         g.getChildren().clear();
                         VBox v = new VBox();
                         v.setPrefWidth(width);
                         toolBar.setOrientation(Orientation.HORIZONTAL);
                         v.getChildren().addAll(menuBar, lineChart, lv, v2);
                         g.getChildren().add(v);
                         
                         lineChart.setMinSize(width-20, height-200);

                    });
                }//fin boucle 1
            }//fin boucle 2
            
            
           
            Button bNotice = new Button("En fonction\ndes Horaires");
            bNotice.setStyle("-fx-background-color: lightpink;" + "-fx-font-color: black;");
            //bNotice.setPrefSize(100, 200);
            bNotice.setOnMouseEntered(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bNotice.setStyle("-fx-background-color: lightgray;" + "-fx-alignment: CENTER;" );
                        bNotice.setTextFill(Color.WHITE);
                    }
        });
        
        bNotice.setOnMouseExited(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bNotice.setStyle("-fx-background-color: lightpink;");
                    }
        });
        
        
        //Action en cliquant sur le Bouton retour arriere
                bNotice.setOnMouseClicked(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                      
                       if(event.getClickCount() >= 1)
                       {
                            GraphiqueSemaine gs = new GraphiqueSemaine(semaine);
                            gs.init_C(get_C());
                            Stage s = new Stage();
                            gs.start(s);
                            stage.close();
                            
                            
                       }

                    }
                 }); 
        
        
            Button bPoids = new Button("Poids des \n tranches Horaires");
            bPoids.setStyle("-fx-background-color: lightpink;" + "-fx-font-color: black;");
            //bPoids.setPrefHeight(height/totalh);
            //bPoids.setPrefWidth(width/totalw);
            bPoids.setOnMouseEntered(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bPoids.setStyle("-fx-background-color: lightgray;" + "-fx-alignment: CENTER;" );
                        bPoids.setTextFill(Color.WHITE);
                    }
        });
        
        bPoids.setOnMouseExited(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bPoids.setStyle("-fx-background-color: lightpink;");
                    }
        });
        
        
        //Action en cliquant 
                bPoids.setOnMouseClicked(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                      
                       if(event.getClickCount() >= 1)
                       {
                            
                            Stage s1 = new Stage();
                            PieChartSemaine pcs = new PieChartSemaine(get_C(), listDonnées);
                            pcs.start(s1);
                            
                       }

                    }
                 }); 
                
                
                
                Button bPoids2 = new Button("Poids des \n Journées");
            bPoids2.setStyle("-fx-background-color: lightpink;" + "-fx-font-color: black;");
            //bPoids2.setPrefHeight(height/totalh);
            //bPoids2.setPrefWidth(width*2/totalw);
            bPoids2.setOnMouseEntered(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bPoids2.setStyle("-fx-background-color: lightgray;" + "-fx-alignment: CENTER;" );
                        bPoids2.setTextFill(Color.WHITE);
                    }
        });
        
        bPoids2.setOnMouseExited(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bPoids2.setStyle("-fx-background-color: lightpink;");
                    }
        });
        
        
        //Action en cliquant 
                bPoids2.setOnMouseClicked(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                      
                       if(event.getClickCount() >= 1)
                       {
                            
                            Stage s1 = new Stage();
                            PieChartSemaineJour pcs = new PieChartSemaineJour(get_C(), GraphiqueSemaineParJour.this.donnéeJour);
                            pcs.start(s1);
                            
                       }

                    }
                 }); 
        
            toolBar.getItems().add(bNotice);
            toolBar.setOrientation(Orientation.HORIZONTAL);
            v2.setLayoutX(width);
            v2.setLayoutY(height/10);
            v2.setPrefWidth(width*10);
            v2.getChildren().add(bPoids);
            v2.getChildren().add(bPoids2);
            
            lineChart.setMinSize(width-20, height-200);
            
            VBox v = new VBox();
            v.setPrefWidth(width);
            v.getChildren().addAll(menuBar, lineChart, lv, v2);
            g.getChildren().add(v);
            Scene scene  = new Scene(g, width, height-75);
            stage.setScene(scene);
            stage.show();
            
        }else{
            
            Label l = new Label("Il n'y a aucune donnée à cette date");
            
            Scene scene  = new Scene(l,200, 100);

            stage.setScene(scene);
            stage.show();
            
        }
            
        
    }
 
}