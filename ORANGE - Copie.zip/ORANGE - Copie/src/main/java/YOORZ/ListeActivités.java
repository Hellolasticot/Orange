/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.io.InputStreamReader;
import java.util.Scanner;
/**
 *
 * @author HugoBarboule
 */

//Cette classe permet d'avoir la liste des activités complete
public class ListeActivités {
    
    // Permet de garder en donnée le String pour chaque ligne du futur CSV (sert dans la méthode Concat_Texte(String) )
    String texte = new String();
    
    //on crée une liste d'activités 
    private ArrayList<Activités> listeActivités;
    private ArrayList<Absence> listeAbsences;
    
    //on crée un constructeur permettant d'instancier la liste des activités ( en mettant sa définition )
    public ListeActivités()
    {
        this.texte = "";
        this.listeActivités = new ArrayList<Activités>();
        this.listeAbsences = new ArrayList<Absence>();
    }
    
    public Activités Search_Activité(String Nom)
    {
        int i = 0;
        boolean aTrouvé = false;
        while(i<this.listeActivités.size() && (aTrouvé==false))
        {
            if(this.listeActivités.get(i).getNom().equals(Nom))
            {
                aTrouvé = true;
            }
            if(!aTrouvé)
                i++;
        }
        if(aTrouvé == false)
        {
            return null;
        }
        else{
            return this.listeActivités.get(i);
        }
    }
    
    public Absence Search_Absence(String Nom)
    {
        int i = 0;
        boolean aTrouvé = false;
        while(i<this.listeAbsences.size() && (!aTrouvé))
        {
            
            if(this.listeAbsences.get(i).getNom().toUpperCase().equals(Nom.toUpperCase()))
            {
                aTrouvé = true;

            }
            if(!aTrouvé)
                i++;
        }

        if(aTrouvé)
        {
            return this.listeAbsences.get(i);
            
            
        }else{
            return null;
        }
    }
        
    
    public ArrayList<Absence> get_list_Absences(){
        return this.listeAbsences;
    }
    
    public ArrayList<Activités> get_list()
    {
        return this.listeActivités;
    }
    
    public void lireBonFichier()
    {
         StringBuilder str = new StringBuilder();
        try{
            
            //On récupère le CSV dans les dossiers.
            InputStream input = getClass().getResource("/données/ListeActivitésReel.csv").openStream(); 
                Scanner scan = new Scanner(input, "ISO-8859-1");

 
            String ligne = "";
            //Tant qu'il y a une ligne d'écrite sur le fichier CSV
            while(scan.hasNextLine())
            {
                ligne += scan.nextLine();
                str.append(ligne);
                str.append("\n");
            }
            System.out.println(str);
            input.close();
         }  
                    
        
        catch(IOException e){
            System.out.println("Une erreur est survenue lors de la lecture du bon CSV");
            e.printStackTrace();
        }
    }
    
    
    //Ecris le nouveau csv qu'on va pouvoir traiter
    public void Ecrire_FichierDeBase() throws Exception
    {
        int i = 0;
        try{
            //On crée le fichier qui va etre écrit
            File f = new File("ListeActivitésReel.csv");
            f.createNewFile();
            FileWriter fw = new FileWriter(f);
            
            String texte = this.Lecture_FichierYOORZ();
            fw.write(texte);
            
            fw.close();
        }
        catch(IOException e){
            System.out.println("Une erreur est survenue lors de l'écriture du CSV de référence");
            e.printStackTrace();
        }
        
        //On enleve la premiere ligne
        try {
 
			File file = new File("ListeActivitésReel.csv");
			RandomAccessFile tools = new RandomAccessFile(file, "rw"); // read-write
			tools.readLine(); // goto second line
			long length = tools.length() - tools.getFilePointer(); // except first line
			byte[] nexts = new byte[(int) length];
			tools.readFully(nexts); // read the others
			tools.seek(0); // return to start
			tools.write(nexts); // insert just 1 line before
			tools.setLength(nexts.length); // truncate the last duplicated line
			tools.close(); // flush all
 
	} catch (Exception error) {
                    error.printStackTrace();
        }
        
    }
    
    // Methode Permettant de Concaténer un Texte (true) ou de le supprimer (false)
    public String Concat_Texte(String texte, boolean test)
    {
        if(test == true)
        {
            this.texte += texte;
        }
        if(test == false){
            this.texte = "";
        }
        
        return this.texte;
    }
    
    // Methode Permettant de récuperer le texte de la methode de concaténation
    public String getter_Concat_Texte()
    {
        return this.texte;
    }
    
    // Permet d'écrire ce qu'il faut selon la taille de la ligne du CSV YOORZ (la taille 
    // étant le dernier attributs dans la liste des attributs (de 1 à 6)
    public int lireAvantTaille(String test)
    {
        int taille;
        
        String[] test3 = test.split(";");
        taille = test3.length;

        boolean afini = false;
        while(!afini)
        {
            for(int i = 0; i<taille; i++)
            {
                if(test3[i].length() == 0)
                {
                    this.Concat_Texte("null", true);
                }
            
                if(i !=5 )
                {
                    this.Concat_Texte(test3[i]+";", true);
                }else{
                    this.Concat_Texte(test3[i], true);
                }
                if(i==2)
                {
                    afini = true;
                }
            }

        }
        return taille;
    }
    
    // Permet d'écrire le reste de la ligne
    public void LireApresTaille(String test) throws Exception
    {
        switch(lireAvantTaille(test))
        {
            case 6:
                this.Concat_Texte("", true);
            break;
            
            case 5:
                this.Concat_Texte("null", true);
            break;
            
            case 4:
                this.Concat_Texte("null;null", true);
            break;
            
            case 3:
                this.Concat_Texte("null;null;null", true);
            break;
            
            case 2:
                this.Concat_Texte("null;null;null;null", true);
            break;
            
            case 1:
                this.Concat_Texte("null;null;null;null;null", true);
            break;
            
            case 0:
                this.Concat_Texte("null;null;null;null;null;null", true);
            break;
            
            // A VERIFIER POURQUOI L'EXCEPTION MARCHE PAS
            /*default : 
                throw new Exception("Vous devez rentrer un nombre entre 0 et 6 (compris)"
                        + "en nombre d Attributs pour les Activités");
            */
        }
    }
    
    
    // Récupere le texte du csv récuperer par YOORZ
    public String Lecture_FichierYOORZ() throws Exception
    {
        StringBuilder str = new StringBuilder();
        try{

            //On récupère le CSV dans les dossiers.
            InputStream input = getClass().getResource("/données/Listeactivités.csv").openStream(); 
                Scanner scan = new Scanner(input, "ISO-8859-1");
            
            
 
            String ligne = "";
            //Tant qu'il y a une ligne d'écrite sur le fichier CSV
            while(scan.hasNextLine())
            {
                ligne += scan.nextLine();
                str.append(ligne);
                str.append("\n");
            }
            
            String LeTexte ="";
            String tout = str.toString();
            String[] tab = tout.split("\n");
            for(int a = 0; a<tab.length; a++)
            {
                 // On adapte le Texte à la lecture
                    this.LireApresTaille(tab[a]);
                    String txtTemp = this.getter_Concat_Texte();
                    
                    // Le texte s'agrandit (du futur CSV)
                    this.texte += txtTemp;
                    LeTexte += txtTemp + "\n";
                   
                    // On supprime la ligne
                    txtTemp = this.Concat_Texte("", false);
            }

                input.close();
                return LeTexte;
        }  
                    
        
        catch(IOException e){
            System.out.println("Une erreur est survenue lors de la lecture du CSV");
            e.printStackTrace();
            return null;
        }
    }
    
    private ArrayList<String> listDesAb = new ArrayList<String>();
    private ArrayList<String> listDesAc = new ArrayList<String>();
    
    public void init_listDesAb()
    {
        this.listDesAb.add("Supervision");
        this.listDesAb.add("Absence");
        this.listDesAb.add("Prévision de congés");
        this.listDesAb.add("Prevision de conges");
        this.listDesAb.add("Réunion");
        this.listDesAb.add("Reunion");
        this.listDesAb.add("Formation");
        this.listDesAb.add("IRP");
        this.listDesAb.add("RC");
        this.listDesAb.add("Pont TP");
        this.listDesAb.add("Autre Activité");
        this.listDesAb.add("[ANOO] Absence");
        this.listDesAb.add("[ANOO] Absence (CA, JTL)");
        this.listDesAb.add("[ANOO] Demande d'absence (CA, JTL, RC, RJTS)");
        this.listDesAb.add("[ANOO] Indisponibilité (ASA, IRP, Maternité, Maladie)");
        this.listDesAb.add("[ANOO] Formation");
    }

    public ArrayList<String> getListDesAb() {
        return listDesAb;
    }

    public ArrayList<String> getListDesAc() {
        return listDesAc;
    }
    
    
    
    public void init_listdesAc()
    {
        this.listDesAc.add("Diag+");
        this.listDesAc.add("PIL TOC+");
        this.listDesAc.add("TEL+");
        this.listDesAc.add("Mx+");
        this.listDesAc.add("A+");
        this.listDesAc.add("M+");
        this.listDesAc.add("S+");
        this.listDesAc.add("R+");
        this.listDesAc.add("CN+");
        this.listDesAc.add("B+");
        this.listDesAc.add("J+");
        this.listDesAc.add("X1+");
        this.listDesAc.add("X2+");
        this.listDesAc.add("X3+");
        this.listDesAc.add("Mx");
        this.listDesAc.add("A");
        this.listDesAc.add("M");
        this.listDesAc.add("S");
        this.listDesAc.add("Repos");
        this.listDesAc.add("CN");
        this.listDesAc.add("B");
        this.listDesAc.add("J");
        this.listDesAc.add("X1");
        this.listDesAc.add("X2");
        this.listDesAc.add("X3");
    }
    
    public boolean estDansActivités(String nom)
    {
        int i = 0;
        boolean atrouvé = false;
        while(i<this.listDesAc.size() && !atrouvé)
        {
            if(this.listDesAc.contains(nom))
            {
                atrouvé = true;
            }
            i++;
        }
        return atrouvé;
    }
    
    public boolean estDansAbences(String nom)
    {
        int i = 0;
        boolean atrouvé = false;
        while(i<this.listDesAb.size() && !atrouvé)
        {
            if(this.listDesAb.contains(nom) || this.listDesAb.contains(nom.toUpperCase()))
            {
                atrouvé = true;
            }
            i++;
        }
        return atrouvé;
    }
    
    public Absence Trouver_Abences(String nom)
    {
        int i = 0;
        Absence a = null;
        boolean trouve = false;
        while(i<this.listeAbsences.size())
        {
            System.out.println("nom : "+nom);
            System.out.println("nom liste : "+this.listeAbsences.get(i).getNom());
            if(this.listeAbsences.get(i).getNom().toUpperCase().equals(nom.toUpperCase()))
            {
                trouve = true;
                a = this.listeAbsences.get(i);
            }
            i++;
        }
        if(true)
        {
            return a;
        }else{
            return null;
        }
    }
    
    public Activités Trouver_Activités(String nom)
    {
        int i = 0;
        while(i<this.listeActivités.size())
        {
            if(this.listeActivités.get(i).getNom().equals(nom))
            {
                return this.listeActivités.get(i); 
            }
            i++;
        }
        return null;
    }
    
   
    
    
    //Création d'une méthode permettant d'initaliser la liste des activités en focntion  du csv mis en source (dossier csv)
    public void init_list()
    {
        this.init_listDesAb();
        this.init_listdesAc();
        StringBuilder str = new StringBuilder();
        
        //Création de variables pour créer une activité en fonction de sa défintion (constructeur)
        String nom;
        String description;
        int poids;
        Vue_Activité vue;
        GSAT equipe;
        Type type;
        
        ArrayList<String> ListeSuperActivités = new ArrayList<String>();
        ListeSuperActivités.add("TEL");
        ListeSuperActivités.add("TEL+");
        ListeSuperActivités.add("TEL +");
        ListeSuperActivités.add("DIAG");
        ListeSuperActivités.add("DIAG+");
        ListeSuperActivités.add("DIAG +");
        ListeSuperActivités.add("PIL TOC");
        ListeSuperActivités.add("PILTOC");
        ListeSuperActivités.add("PILTOC+");
        ListeSuperActivités.add("PIL TOC+");
        
        try{
            //On récupère le CSV dans les dossiers.
 
            
              InputStream input = getClass().getResource("/données/ListeActivitésReel.csv").openStream(); 
                Scanner scan = new Scanner(input, "ISO-8859-1");

            
            
            String ligne = "";
            //Tant qu'il y a une ligne d'écrite sur le fichier CSV
                while(scan.hasNextLine())
                {
                   ligne = scan.nextLine();
                    // Dans la variable txt il y a une ligne entière du CSV
                    String txt=ligne;

                    /*Pour récupérer les bonnes informations, on découpe chaque 
                    ligne du csv en fonction du découpage (en point virgules) du csv*/
                    String[] v= txt.split(";");

                    
                  int VerifAbsencePresence;  
                  boolean aInitialiséActivité = false;
                  while(!aInitialiséActivité)
                  {
                        //Vérification s'il y a un nom (=premiere partie de la ligne )
                        if(!v[0].equals("null"))
                        {
                            nom = v[0];
                        }
                        else{
                            nom = "Nom Inconnu";
                        }
                        
                        if(v[0].startsWith("[ANOO]") || this.listDesAb.contains(v[0]) || this.listDesAb.contains(v[0].toUpperCase())
                                || this.listDesAb.contains(v[0].toLowerCase()) || (Integer.parseInt(v[2]) < 20 && !v[2].equals("null")))
                        {
                            VerifAbsencePresence = 0;
                            
                        }else if( this.listDesAc.contains(v[0]) || this.listDesAc.contains(v[0].toUpperCase())
                                      || this.listDesAc.contains(v[0].toLowerCase()) || (Integer.parseInt(v[2]) < 90 && Integer.parseInt(v[2]) >= 20 && !v[2].equals("null")))
                        {
                            VerifAbsencePresence = 1;
                        }
                        else{
                            VerifAbsencePresence = 3;
                        }
                        

                        if(ListeSuperActivités.contains(v[0].toUpperCase()))
                        {
                            VerifAbsencePresence = 1;
                        }
                   
                        //Vérification qu'une description de l'activité existe
                        if(!v[1].equals("null"))
                        {
                            description = v[1];
                        }
                        else{
                            description = "Description Inconnue";
                        }
                   
                        //Vérification qu'un poids existe
                        if(!v[2].equals("null"))
                        {
                            poids = Integer.parseInt(v[2]);
                        }
                        else{
                            poids = 1000;
                        }
 
                        switch(VerifAbsencePresence)
                        {
                            case 1:
                                                        
                                Activités activité = new Activités(nom, description, poids, v[3], v[4], v[5]);
                                if(!listeActivités.contains(activité)){
                                    this.listeActivités.add(activité);
                                }
                                if(!listDesAc.contains(nom))
                                {
                                   this.listDesAc.add(nom); 
                                }
                                aInitialiséActivité = true;
                                break;
                            case 0:
                                                        
                                Absence absence = new Absence(nom, description, poids, v[3], v[4], v[5]);
                                if(!listeAbsences.contains(absence)){
                                    this.listeAbsences.add(absence);
                                }
                                if(!listDesAb.contains(nom))
                                {
                                   this.listDesAb.add(nom); 
                                }
                                aInitialiséActivité = true;
                                break;
                            default :
                                aInitialiséActivité = true;
                                break;
                        }

                  }

                }
                input.close();
        }
        catch(Exception e){
            System.out.println("Une erreur est survenue lors de l'initalisation de la liste des Activités");
            e.printStackTrace();
        }
    }
    
    public String Lecture_ArrayListAbsence()
    {
        String texte = "";
        String ligne = "";
        String pv = ";";
        //System.out.println("taille liste absences : " + this.listeAbsences.size());
        for(int i = 0; i<this.listeAbsences.size(); i++)
        {
            ligne += this.listeAbsences.get(i).getNom() + pv +
                    this.listeAbsences.get(i).getDescription() + pv +
                    this.listeAbsences.get(i).getPoids() + pv +
                    this.listeAbsences.get(i).getVue() + pv +
                    this.listeAbsences.get(i).getEquipe() + pv + 
                    this.listeAbsences.get(i).getType() + "\n";
            texte += ligne;
            ligne = "";
        }
        
        return texte;
    }
    
     public String Lecture_ArrayListActivité()
    {
        String texte = "";
        String ligne = "";
        String pv = ";";
        //System.out.println("taille liste activités : " + this.listeActivités.size());
        for(int i = 0; i<this.listeActivités.size(); i++)
        {
            ligne += this.listeActivités.get(i).getNom() + pv +
                    this.listeActivités.get(i).getDescription() + pv +
                    this.listeActivités.get(i).getPoids() + pv +
                    this.listeActivités.get(i).getVue() + pv +
                    this.listeActivités.get(i).getEquipe() + pv + 
                    this.listeActivités.get(i).getType() + "\n";
            texte += ligne;
            ligne = "";
        }
        
        return texte;
    }
    
    public void Create_File_Absences()
    {
        int i = 0;
        try{
            //On crée le fichier qui va etre écrit
            File f = new File("ListeDesAbsencesFinal.csv");
            f.createNewFile();
            FileWriter fw = new FileWriter(f);
            
            String texte = this.Lecture_ArrayListAbsence();
            fw.write(texte);
            
            fw.close();
        }
        catch(IOException e){
            System.out.println("Une erreur est survenue lors de l'écriture du CSV des Absences");
            e.printStackTrace();
        }
    }
    
    public void Create_File_Activités()
    {
        int i = 0;
        try{
            //On crée le fichier qui va etre écrit
            File f = new File("ListeDesActivitésFinal.csv");
            f.createNewFile();
            FileWriter fw = new FileWriter(f);
            
            String texte = this.Lecture_ArrayListActivité();
            fw.write(texte);
            
            fw.close();
        }
        catch(IOException e){
            System.out.println("Une erreur est survenue lors de l'écriture du CSV des Activités");
            e.printStackTrace();
        }
    }
    
    
    public void afficherList()
    {
        for(int i = 0; i<this.listeActivités.size(); i++)
        {
            System.out.println(this.listeActivités.get(i).toString());
        }
    }
    
    
    
    
    
    
    
    
}
