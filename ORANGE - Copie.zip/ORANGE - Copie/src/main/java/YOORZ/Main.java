/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

/**
 *
 * @author HugoBarboule
 */
public class Main {
    
    
    
    public static void main(String[] args) throws Exception
    {
        Cloud c = new Cloud();
        c.init_ls();
        System.out.println(1);
        c.init_la();
        System.out.println(2);
        c.get_le().init_c(c);
        c.init_le();
        System.out.println(3);
        c.get_le().tout_attribuer();
        System.out.println(4);
        c.get_le().init_MapListNbDispo();
        System.out.println(5);
        
        System.out.println(c.get_le().LectureList());
        
        
        //la.afficherList();
       // System.out.println("ABSENCES : " + la.Lecture_ArrayListAbsence());
        //System.out.println("ACTIVITES : " +la.Lecture_ArrayListActivité());

       
   
        

      //le.attribuer_edt(ls.get_list().get(0));
      
      
      /*int t = ls.get_list().size() -1;
      le.attribuer_edt(ls.get_list().get(t));
      System.out.println("\t" + ls.get_list().get(t).getNom().toUpperCase() + " " + ls.get_list().get(t).getPrenom().toUpperCase());
      
      for(int i =0; i<ls.get_list().get(t).getEdt().size(); i++)
      {
                System.out.println("\n" + ls.get_list().get(t).getEdt().get(i).afficher_EDT());
                System.out.println("");
      }*/
      
      /*for(int i = 0; i<ls.get_list().size(); i++)
      {
          le.attribuer_edt(ls.get_list().get(i));
      }
      
      
      
      ArrayList<ArrayList<Superviseur>> Lalist = new ArrayList<ArrayList<Superviseur>>();
      Lalist = ls.QuiEstDispoParDemieHeure("06/04/2021", 14.0f, 2, "Paris", 1);*/
      
      /*if(!Lalist.isEmpty())
      {
          for(int i = 0; i<Lalist.size(); i++)
          {
            if(!Lalist.get(i).isEmpty())
            {
                for(int a = 0; a<Lalist.get(i).size(); a++)
                {
                    if( i == 0)
                        System.out.println(Lalist.get(i).get(a).getNom() + " "+ Lalist.get(i).get(a).getPrenom() + " à " + Lalist.get(i).get(a).getSite() );
                    else
                        System.out.println("est présent pas tout le temps : " +Lalist.get(i).get(a).getNom() + " "+ Lalist.get(i).get(a).getPrenom() + " à " + Lalist.get(i).get(a).getSite());
                }
            }

        }
      
      }*/
      
      //AFFICHER LES EDT : 
      /*for(int a = 0; a<ls.get_list().size(); a++)
      {
          le.attribuer_edt(ls.get_list().get(a));
          System.out.println("\t" + ls.get_list().get(a).getNom().toUpperCase() + " " + ls.get_list().get(a).getPrenom().toUpperCase());
          
          if(ls.get_list().get(a).getEdt().isEmpty())
          {
              System.out.println("\t rien de prévu");
          }else{
              for(int i =0; i<ls.get_list().get(a).getEdt().size(); i++)
              {
                System.out.println("\n" + ls.get_list().get(a).getEdt().get(i).afficher_EDT());
                System.out.println("");
              }
          }
           
           System.out.println("_____________________________________________________________________________________________________________________________");
           System.out.println("");
          
      }
      */
      
        
        //ls.afficherListeSuperviseur();
       /*
        System.out.println("__________________________________");
        for(int i =0; i<ls.get_list().get(0).getEdt().size(); i++)
        {
            System.out.println("\n" + ls.get_list().get(0).getEdt().get(i).afficher_EDT());
        }
        */
 
        /* POUR METTRE LE BON CSV DEDANS*/
        /*ListeActivités la = new ListeActivités();
        la.Ecrire_FichierDeBase();
        //la.lireBonFichier();
        
        la.init_list();
        la.Create_File_Absences();
        la.Create_File_Activités();*/
        
        //la.Find_BySecteur("Lyon");
        //la.Find_ByDateMois("04", "2021");
        //la.Find_ByDateJour("15", "04", "2021");
        //la.Find_ByActivité("A");
        //la.afficherList();
        
        
       /*Test t = new Test();
       t.lire();
        */
        
        /*ListeActivités la = new ListeActivités();
        la.init_list();
        System.out.println(la.get_list_Absences().size());
        System.out.println(la.Lecture_ArrayListAbsence());
        System.out.println("______________________________________");
        Activités a = new Activités("[ANOO] Absence", "dedf", 3, "d", "GSR", "d");
        a.init_HorairesParAbsence("[ANOO] Absence80120");*/
        
        
        
    }
}
