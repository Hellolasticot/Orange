/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

import java.awt.Dimension;
import javafx.scene.text.Font;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import javafx.geometry.Side;
import javafx.scene.Node;
import javafx.scene.chart.LineChart;
import javafx.scene.layout.StackPane;
 
 
public class GraphiqueMoisJour extends Application {
    
    private int mois;
    //Il s'agit des dimensions de chaque écran  ==  ecran adapté
        Dimension dimension = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        int height = (int)dimension.getHeight();
        int width  = (int)dimension.getWidth();
        

        private static double mouseY;
        private static double sourceY;
        
        //Subdivision de l'écran :
        int totalh = height/54;
        int totalw = width/64;
        
        Font police = new Font("Arial", 20);
        
        private Cloud c = new Cloud();
        
    public void init_C(Cloud C)
    {
        this.c = C;
    }

    public GraphiqueMoisJour(int mois) {
        this.mois = mois;
    }

    public int getMois() {
        return mois;
    }
    
    public Cloud get_C()
    {
        return this.c;
    }
     
    
    private  ArrayList<Integer> donnéeJour = new ArrayList<Integer>();

    public ArrayList<Integer> getDonnéeJour() {
        return donnéeJour;
    }
        
    
    
    //Méthode permettant de trier par ordre numérique, les clés de la HashMap
    public static HashMap<Jour, ArrayList<Integer>> trierHashMap(Map<Jour, ArrayList<Integer>> hmap){
        List<Map.Entry<Jour, ArrayList<Integer>>> list =
           new LinkedList<Map.Entry<Jour, ArrayList<Integer>>>( hmap.entrySet() );
        Collections.sort( list, new Comparator<Map.Entry<Jour, ArrayList<Integer>>>(){
           public int compare
           (Map.Entry<Jour, ArrayList<Integer>>o1, Map.Entry<Jour, ArrayList<Integer>> o2 )
           {
              //comparer deux clés
              return (o1.getKey().getD()).compareTo( o2.getKey().getD() );
           }
        });
        
        //créer une nouvelle HashMap à partir de LinkedList
        HashMap<Jour, ArrayList<Integer>> hmapTriee = new LinkedHashMap<Jour, ArrayList<Integer>>();
        for (Map.Entry<Jour, ArrayList<Integer>> entry : list)
        {
            hmapTriee.put( entry.getKey(), entry.getValue() );
        }
        return hmapTriee;
    }
    
    
    @Override 
    public void start(Stage stage) {
        StackPane root = new StackPane();
        
        Group g = new Group();
        ToolBar toolBar = new ToolBar();
        HBox v2 = new HBox(toolBar);
        Menu menu = new Menu("Menu des Semaines");
        menu.setStyle("fx-background-color: blue;");
        
        Iterator i3 = c.get_le().get_ListeDesJoursRassemblésSemaine().entrySet().iterator();
        ArrayList<MenuItem> listButton = new ArrayList<MenuItem>();
        while(i3.hasNext())
        {
             Map.Entry mapentry = (Map.Entry) i3.next();
             MenuItem choice = new MenuItem(String.valueOf((int) mapentry.getKey()));
             listButton.add(choice);
        }
        
        SeparatorMenuItem s = new SeparatorMenuItem();
        
        for(int i = 0; i<listButton.size(); i++)
        {
            menu.getItems().add(listButton.get(i));
            menu.getItems().add(s);
        }
        
        MenuBar menuBar = new MenuBar();
        menuBar.getMenus().add(menu);

        
        Menu menu2 = new Menu("Stats par jour");
        
        MenuItem mi = new MenuItem("Quel jour ?");
       
           mi.setOnAction(new EventHandler<ActionEvent>() {
                                            
                 @Override 
                 public void handle(ActionEvent e) {
                     
                     DatePicker2INTERFACE dt = new DatePicker2INTERFACE();
                     Stage s = new Stage();
                     dt.init_c(c);
                     dt.start(s);
                     stage.close();
                 }
            });
           
        menu2.getItems().add(mi);
        menuBar.getMenus().add(menu2);
        
        
        for(int i = 0; i<listButton.size(); i++)
        {
           int num = Integer.parseInt(listButton.get(i).getText());
           
            //ACTION QUAND ON CLIQUE SUR UNE SEMAINE
           listButton.get(i).setOnAction(new EventHandler<ActionEvent>() {

               @Override 
                public void handle(ActionEvent e) {
                    
                    GraphiqueSemaine gs = new GraphiqueSemaine(num);
                    try{
                        Stage s = new Stage();
                        gs.init_C(c);
                        gs.start(s);
                        
                        stage.close();
                        
                    }catch(Exception ex){
                        ex.printStackTrace();
                    }
                }
           });
        }
        
        // menu des mois
        Menu menu3 = new Menu("Liste des Mois disponible");
        menuBar.getMenus().add(menu3);
        Iterator i5 = c.get_le().getMapJourParMoisSemaine().entrySet().iterator();
        ArrayList<MenuItem> listButton2 = new ArrayList<MenuItem>();
        while(i5.hasNext())
        {
             Map.Entry mapentry = (Map.Entry) i5.next();
             MenuItem choice = new MenuItem(String.valueOf((int) mapentry.getKey()));
             listButton2.add(choice);
        }
        
        
        for(int i = 0; i<listButton2.size(); i++)
        {
            menu3.getItems().add(listButton2.get(i));
            menu3.getItems().add(s);
        }
        
        for(int i = 0; i<listButton2.size(); i++)
        {
           int num = Integer.parseInt(listButton2.get(i).getText());
           
            //ACTION QUAND ON CLIQUE SUR UNE SEMAINE
           listButton2.get(i).setOnAction(new EventHandler<ActionEvent>() {

               @Override 
                public void handle(ActionEvent e) {
                    
                    GraphiqueMoisJour gmj = new GraphiqueMoisJour(num);
                    try{
                        Stage s = new Stage();
                        gmj.init_C(c);
                        gmj.start(s);
                        
                        stage.close();
                        
                    }catch(Exception ex){
                        ex.printStackTrace();
                    }
                }
           });
        }
        
        //Recupération des données
        HashMap<Jour, ArrayList<Integer>> liste = new HashMap<Jour, ArrayList<Integer>>();
        
        Iterator ite = c.get_le().getMapJourParMoisSemaine().entrySet().iterator();
        
        boolean Atrouvé = false;
        ArrayList<Jour> listJour = new ArrayList<Jour>();
        
        while(ite.hasNext() && !Atrouvé)
        {
            
             Map.Entry mapentry = (Map.Entry) ite.next();
             Atrouvé = (this.mois == (int) mapentry.getKey());
             if(Atrouvé)
             {
                 Iterator i = c.get_le().getMapJourParMoisSemaine().get((int) this.mois).entrySet().iterator();
                 while(i.hasNext())
                 {
                     Map.Entry m = (Map.Entry) i.next();
                     Collections.sort(c.get_le().getMapJourParMoisSemaine().get((int) this.mois).get((int) m.getKey()));
                     Iterator ite2 = c.get_le().getMapJourParMoisSemaine().get((int) this.mois).get((int) m.getKey()).iterator();
                     
                     while(ite2.hasNext())
                     {
                         Jour j = (Jour) ite2.next();
                         
                         Iterator i2 = j.getMap().entrySet().iterator();
                         listJour.add(j);
                         ArrayList<Integer> l = new ArrayList<Integer>();
                         while(i2.hasNext())
                         {
                             Map.Entry mapentry2 = (Map.Entry) i2.next();
                             l.add((int) mapentry2.getValue());
                         }
                         liste.put(j, l);
                         // Ici nous avons dans la liste les disponibilités dans les jours du bon mois
                     }
                 }
             }
        }
        // Fin de la récupération de données
        
        int max = 0;
        max = this.TrouverLeMax(liste);
        
        
        liste = trierHashMap(liste);

        
        if(!liste.isEmpty())
        {
            
            stage.setTitle("Bar Chart des Disponibilités du Mois");
            final CategoryAxis xAxis = new CategoryAxis();
            final NumberAxis yAxis = new NumberAxis(0, max+5, 5);
            xAxis.setLabel("Tous les Jours du Mois");       

            final BarChart<String,Number> lineChart = 
                    new BarChart<String,Number>(xAxis,yAxis);
            
    
                    // second chart (overlaid):
            final LineChart<String, Number> lineChart2 = new LineChart<>(xAxis, yAxis);
            lineChart2.setLegendVisible(false);
            lineChart2.setAnimated(false);
            lineChart2.setCreateSymbols(true);
            lineChart2.setAlternativeRowFillVisible(false);
            lineChart2.setAlternativeColumnFillVisible(false);
            lineChart2.setHorizontalGridLinesVisible(false);
            lineChart2.setVerticalGridLinesVisible(false);
            lineChart2.getXAxis().setVisible(false);
            lineChart2.getYAxis().setVisible(false);
            lineChart2.getStylesheets().addAll(getClass().getResource("/CSS/YOORZCSS.css").toExternalForm());
            int seuilbas = 19;

            lineChart.setTitle("Dispos du mois : "+this.mois);
            
            
            HashMap<Integer, XYChart.Data<String, Number>> mapXY = new HashMap<Integer, XYChart.Data<String, Number>>();
            ArrayList<XYChart.Data<String, Number>> listxy = new ArrayList<XYChart.Data<String, Number>>();
            XYChart.Series series = new XYChart.Series();
            XYChart.Series series2 = new XYChart.Series();
            Calendar c = Calendar.getInstance();
            
            /*
                Parmis toutes les données récupérées : je réupere une à une la liste
                des disponibilités par tranches horaires
            */

            Iterator iterator2 = liste.entrySet().iterator();
            XYChart.Data<String, Number> xy;
            int compteur = 0;
            while(iterator2.hasNext())
            {
                
                Map.Entry m = (Map.Entry) iterator2.next();
               
                int size = ((ArrayList<Integer>) m.getValue()).size();
                for(int i = 0; i<((ArrayList<Integer>) m.getValue()).size(); i++)
                {
                    c.setTime(((Jour) m.getKey()).getD());
                    int nbweek =  c.get(Calendar.WEEK_OF_YEAR);
                    int nbJour = c.get(Calendar.DAY_OF_WEEK);
                    String nom;
                    switch(nbJour-2)
                    {
                        case 0:
                            nom =  nbweek + "-Lun";
                        break;
                        case 1:
                            nom =  nbweek + "-Ma";
                        break;
                        case 2:
                            nom =  nbweek + "-Me";
                        break;
                        case 3:
                            nom = nbweek + "-Je"; 
                        break;
                        case 4:
                            nom =  nbweek + " -Ve";
                        break;
                        case 5:
                            nom =  nbweek + "-Sa";
                        break;
                        default: 
                            nom =  nbweek + "-Di";
                        break;
                    }
                    
                    xy = new XYChart.Data(nom, ((ArrayList<Integer>) m.getValue()).get(i));
                    series.getData().add(xy);
                    listxy.add(xy); 
                    lineChart.getData().add(series);


                    xy = new XYChart.Data(nom, seuilbas);
                    series2.getData().add(xy);

                    series = new XYChart.Series();
                    
                } // fin de la boucle pour la liste des données d'un jour
                compteur ++;
  
            } // fin de l'itération de toutes les journées
            
            lineChart2.getData().add(series2);


              Label lv = new Label("\n\n\n\n\t\t\t 1ere barre : 7h - 8h\t\t 2eme barre : 8h - 12h30\t\t 3eme barre : 12h30 - 15h30 \t\t 4eme barre : 15h30 - 17h30\t\t"
                    + "5eme barre : 17h30 - 18h30\t\t 6eme barre : 18h30 - 20h\n_____\n");
              
              //now you can get the nodes.
            for (XYChart.Series<String,Number> serie: lineChart2.getData()){
                
                
                serie.getNode().setOnMousePressed(e ->
                {
                    serie.getNode().setStyle("-fx-background-color: black;");
                    mouseY = e.getSceneY();
                    sourceY = ((Node) (e.getSource())).getTranslateY();
                   
                });

                serie.getNode().setOnMouseDragged(e ->
                {
                    serie.getNode().setStyle("-fx-background-color: red;");
                    double newY = sourceY + e.getSceneY() - mouseY;
                    ((Node) (e.getSource())).setTranslateY(newY);
                    for(int i = 0; i<serie.getData().size(); i++)
                    {
                        serie.getData().get(i).getNode().setVisible(false);
                    }
                });
            }
            
            
                
              

            lineChart.setMinSize(width-20, height-200);
            lineChart.setLegendVisible(false);
            lineChart.setLegendSide(Side.BOTTOM);
            VBox v = new VBox();
            v.setPrefWidth(width);
            root.getChildren().addAll(lineChart, lineChart2);
            v.getChildren().addAll(menuBar, root, lv, v2);
            g.getChildren().add(v);
            Scene scene  = new Scene(g, width, height-75);
            stage.setScene(scene);
            stage.show();
            
        }else{
            
            Label l = new Label("Il n'y a aucune donnée à cette date");
            
            Scene scene  = new Scene(l,200, 100);

            stage.setScene(scene);
            stage.show();
            
        }
            
        
    }// fin methode de lancement
    
    //Methode permettant d'avoir le maximum du mois pour adapter le graphique
    public int TrouverLeMax(HashMap<Jour, ArrayList<Integer>> map)
    {
        Iterator i = map.entrySet().iterator();
        int max = 0;
        while(i.hasNext())
        {
            Map.Entry mapentry = (Map.Entry) i.next();
            for(int ii = 0; ii<((ArrayList<Integer>) mapentry.getValue()).size(); ii++)
            {
                if(max <= ((ArrayList<Integer>) mapentry.getValue()).get(ii) )
                {
                    max = ((ArrayList<Integer>) mapentry.getValue()).get(ii);
                }
            }
        }
        
        return max;
    }
 
}// fin classe