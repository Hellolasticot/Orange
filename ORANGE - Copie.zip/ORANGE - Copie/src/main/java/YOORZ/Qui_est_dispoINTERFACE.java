/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

import java.awt.Dimension;
import java.io.File;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Callback;

/**
 *
 * @author HugoBarboule
 */
public class Qui_est_dispoINTERFACE extends Application {
    
    private static double mouseX;
    private static double mouseY;
    private static double sourceX;
    private static double sourceY;
    private static Cloud c;
    
    // Factory to create Cell of DatePicker
    private Callback<DatePicker, DateCell> getDayCellFactory() {
 
        final Callback<DatePicker, DateCell> dayCellFactory = new Callback<DatePicker, DateCell>() {
 
            @Override
            public DateCell call(final DatePicker datePicker) {
                return new DateCell() {
                    @Override
                    public void updateItem(LocalDate item, boolean empty) {
                        super.updateItem(item, empty);
 
                        // Disable Monday, Tueday, Wednesday.
                        if (item.getDayOfWeek() == DayOfWeek.SATURDAY //
                                || item.getDayOfWeek() == DayOfWeek.SUNDAY ) {
                            setDisable(true);
                            setStyle("-fx-background-color: #ffc0cb;");
                        }
                    }
                };
            }
        };
        return dayCellFactory;
    }
    
    public void init_c(Cloud c)
    {
        this.c = c;
    }
    
    
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        
        //Il s'agit des dimensions de chaque écran  ==  ecran adapté
        Dimension dimension = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        int height = (int)dimension.getHeight();
        int width  = (int)dimension.getWidth();
        
        //Subdivision de l'écran :
        int totalh = height/54;
        int totalw = width/64;
        

        Image image = new Image("/images/logoOrange.png");
        ImageView imageView = new ImageView(image); 
        imageView.setFitWidth(width*1.5/totalw); 
        imageView.setFitHeight(height*1.5/totalh);
        imageView.setX(18*width/totalw);
        imageView.setY(height*0.25/totalh);
        
        Rectangle r1 = new Rectangle();
        r1.setX(0);
        r1.setY(0);
        r1.setWidth(width);
        r1.setHeight(2*height/totalh);
        r1.setFill(Color.WHITE);
        
        Text Titre = new Text("Orange_YOORZ");
        FontPosture fontPosture2 = FontPosture.ITALIC;
        Font font2 = Font.font("Calibri", fontPosture2, 50);
        Titre.setFont(font2);
        Titre.setX(width*0.5/totalw);
        Titre.setY(height*1.25/totalh);
        Titre.setFill(Color.DARKORANGE);
        
         //Création d'un Rectangle au milieu, de couleur orange
        Rectangle r = new Rectangle();
        r.setX(width*3/totalw);
        r.setY(height*3/totalh);
        r.setWidth(15.4*width/totalw);
        r.setHeight(8.5*height/totalh);
        r.setFill(Color.KHAKI);
        
      
        
        Group g = new Group();

        
        //ListeSuperviseurs ls = new ListeSuperviseurs();
        //ls.init_list();
        
        ArrayList<String> lsite = this.c.get_ls().get_listSite();
        
 
        DatePicker datePicker = new DatePicker();
        datePicker.setValue(LocalDate.now());
        datePicker.setShowWeekNumbers(true);
  
        // Factory to create Cell of DatePicker
        Callback<DatePicker, DateCell> dayCellFactory= this.getDayCellFactory();
        datePicker.setDayCellFactory(dayCellFactory);
 
        FlowPane root = new FlowPane();
        root.getChildren().add(datePicker);
        root.setPadding(new Insets(10));
        datePicker.setPromptText("dd/MM/yyyy");
        datePicker.setPrefSize(150, 100);
        root.setLayoutX(width*7/totalw);
        root.setLayoutY(height*4/totalh);
        
         //Police (Style) dans les boutons
         FontWeight  fontWeight  = FontWeight.BOLD;
         FontPosture fontPosture = FontPosture.ITALIC;
         Font font = Font.font("Arial", fontWeight, fontPosture, 18);
         
        Label l = new Label("Veuillez choisir une date");
        l.setLayoutX(width*8.5/totalw);
        l.setLayoutY(height*2.5/totalh);
        l.setFont(font);
        l.setTextFill(Color.ORANGE);
        l.setPrefHeight(50);
        l.setStyle("-fx-background-color: black;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" + "-fx-border-color: black;" + 
                                "-fx-border-width: 5px;" + "-fx-border-radius: 4.5em;");
        
        Button bAcceptDate = new Button("Valider Date");
        bAcceptDate.setLayoutX(width*10/totalw);
        bAcceptDate.setLayoutY(height*5/totalh);
        
       
            bAcceptDate.setOnAction(new EventHandler<ActionEvent>() {
                                            
                 @Override 
                 public void handle(ActionEvent e) {
                            
                            String dateV = datePicker.getValue().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                            
                            g.getChildren().remove(r);
                            g.getChildren().remove(l);
                            g.getChildren().remove(root);
                            g.getChildren().remove(bAcceptDate);
                     
                            Label label = new Label("Choisissez le Site dont vous travaillez actuellement:\t ");
                            label.setStyle("-fx-font-size: 20px;");
                            Label labelInfo = new Label();
                            labelInfo.setTextFill(Color.BLUE);
                            labelInfo.setStyle("-fx-font-size: 20px;");
                            
                            Label labelHB = new Label("Choisissez l'heure de début :\t ");
                            labelHB.setStyle("-fx-font-size: 20px;");
                            Label labelInfoHB = new Label();
                            labelInfoHB.setTextFill(Color.BLUE);
                            labelInfoHB.setStyle("-fx-font-size: 20px;");
                            
                            Label labelD = new Label("Choisissez le temps que celà va durer :\t ");
                            labelD.setStyle("-fx-font-size: 20px;");
                            Label labelInfoD = new Label();
                            labelInfoD.setTextFill(Color.BLUE);
                            labelInfoD.setStyle("-fx-font-size: 20px;");
 
                            // Group
                            ToggleGroup group = new ToggleGroup();
                            ToggleGroup groupHeureDeb = new ToggleGroup();
                            
                            ToggleGroup groupDuree = new ToggleGroup();
 
                            group.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
                                @Override
                                public void changed(ObservableValue<? extends Toggle> ov, Toggle old_toggle, Toggle new_toggle) {
                                    // Has selection.
                                    if (group.getSelectedToggle() != null) {
                                        RadioButton button = (RadioButton) group.getSelectedToggle();
                                        labelInfo.setText("\nVous avez choisi : " + button.getText());
                                    }
                                }
                            });
                            
                            groupHeureDeb.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
                                @Override
                                public void changed(ObservableValue<? extends Toggle> ov, Toggle old_toggle, Toggle new_toggle) {
                                    // Has selection.
                                    if (groupHeureDeb.getSelectedToggle() != null) {
                                        RadioButton button = (RadioButton) groupHeureDeb.getSelectedToggle();
                                        labelInfoHB.setText("\nVous avez choisi : " + button.getText() +" pour le début");
                                    }
                                }
                            });
                            
                            
                            groupDuree.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
                                @Override
                                public void changed(ObservableValue<? extends Toggle> ov, Toggle old_toggle, Toggle new_toggle) {
                                    // Has selection.
                                    if (groupDuree.getSelectedToggle() != null) {
                                        RadioButton button = (RadioButton) groupDuree.getSelectedToggle();
                                        String[] sp = button.getText().split("demi");
                                        labelInfoD.setText("\nVous avez choisi : " + Double.parseDouble(sp[0])/2 +" heure(s) de durée");
                                    }
                                }
                            });
                            
                            ArrayList<RadioButton> listSite = new ArrayList<RadioButton>();
                            ArrayList<RadioButton> listHB = new ArrayList<RadioButton>();
                            ArrayList<RadioButton> listDu = new ArrayList<RadioButton>();
                            
                            ArrayList<RadioButton> lrb = new ArrayList<RadioButton>();
                            // POUR LE SITE
                            HBox rootS = new HBox();
                            rootS.getChildren().add(label);
                            
                            listSite.clear();
                            
                            for(int i = 0; i< lsite.size(); i++ )
                            {
                                RadioButton b = new RadioButton(lsite.get(i));
                                lrb.add(b);
                                listSite.add(b);
                                b.setToggleGroup(group);
                                
                                if(i == 0)
                                {
                                    b.setSelected(true);
                                }
                                
                                rootS.getChildren().add(b);
                                
                            }
                            rootS.setPadding(new Insets(30));
                            rootS.setSpacing(8);
                            rootS.getChildren().add(labelInfo);
                            rootS.setLayoutX(80);
                            rootS.setLayoutY(80);

                            g.getChildren().add(rootS);
                            
                            // FIN POUR LE SITE
                            
                            
                            ////////////////////////////////////////////////////////
                            
                            
                            // POUR L'HEURE DE DEBUT
                            ArrayList<Float> listHBPossible = new ArrayList<Float>();
                            float heure = 0f;
                            for(int i = 0; i<48; i++)
                            {
                                listHBPossible.add(heure);
                                heure += 0.5f;
                            }
                            
                            HBox rootHB = new HBox();
                            HBox rootHB2 = new HBox();
                            HBox rootHB3 = new HBox();

                            rootHB.getChildren().add(labelHB);
                            listHB.clear();
                            
                            for(int i = 0; i< listHBPossible.size(); i++)
                            {
                                RadioButton b = new RadioButton(String.valueOf(listHBPossible.get(i)) + "h");
                                lrb.add(b);
                                listHB.add(b);
                                b.setToggleGroup(groupHeureDeb);
                                
                                if(i == 0)
                                {
                                    b.setSelected(true);
                                }
                                
                                if(i<listHBPossible.size()/3)
                                    rootHB.getChildren().add(b);
                                if(i<listHBPossible.size()*2/3 && i>= listHBPossible.size()/3)
                                    rootHB2.getChildren().add(b);
                                if(i<listHBPossible.size() && i>+ listHBPossible.size()*2/3)
                                    rootHB3.getChildren().add(b);
                            }
                            
                           
                            rootHB.setPadding(new Insets(30));
                            rootHB.setSpacing(8);
                            rootHB.setLayoutX(80);
                            rootHB.setLayoutY(180);
                            
                            rootHB2.setPadding(new Insets(30));
                            rootHB2.setSpacing(8);
                            rootHB2.setLayoutX(80);
                            rootHB2.setLayoutY(230);
                            
                            rootHB3.setPadding(new Insets(30));
                            rootHB3.setSpacing(8);
                            rootHB3.setLayoutX(80);
                            rootHB3.setLayoutY(280);
                            
                            rootHB3.getChildren().add(labelInfoHB);

                            
                            Button bEtape = new Button("Continuer");
                            bEtape.setLayoutX(200);
                            bEtape.setLayoutY(400);
                            
                            Button ra2 = new Button("Retour en arriere");
                            ra2.setLayoutX(100);
                            ra2.setLayoutY(600);
                            
                            
                                                        
                                    
                                    ra2.setOnMouseClicked(new EventHandler<MouseEvent>() {
                                    
                                        @Override
                                        public void handle(MouseEvent event) {
                        
                                            if(event.getClickCount() >= 1){
                                                
                                                g.getChildren().removeAll(rootS, rootHB, rootHB2, rootHB3, bEtape, ra2);
                                                g.getChildren().addAll(root, bAcceptDate, l);
                                                
                                            }
                                        }
                                    }); // FIN DU RA2 CLIQUAGE
                                    
                            
                            g.getChildren().addAll(rootHB, rootHB2, rootHB3, bEtape, ra2);
                            // FIN POUR L'HEURE DE DEBUT
                           
                            ////////////////////////////////////////////////////////////////////////
                            
                            bEtape.setOnMouseClicked(new EventHandler<MouseEvent>() {
            
                                 @Override
                                public void handle(MouseEvent event) {
                        
                                        for(int i = 0; i<lrb.size(); i++)
                                        {
                                            lrb.get(i).setVisible(false);
                                        }
                                                                    
                                        g.getChildren().removeAll(bEtape, ra2);
                                        int i =0;
                                        while(i<groupHeureDeb.getToggles().size() && !groupHeureDeb.getToggles().get(i).isSelected())
                                        {
                                            i++;
                                        }
                            
                                        // je fais la partie entiere
                                        int nbRestant = groupHeureDeb.getToggles().size()-i;
                                        
                            
                                        //POUR LE NOMBRE DE MINUTE QUE CELA VA DURER
                                        ArrayList<Integer> listDPossible = new ArrayList<Integer>();
                                        
                                        for(int heure2 = 1; heure2 <= nbRestant; heure2++)
                                        {
                                            listDPossible.add(heure2);
                                        }   
                            
                                        HBox rootD = new HBox();
                                        HBox rootD2 = new HBox();
                                        HBox rootD3 = new HBox();
                                        HBox rootD4 = new HBox();
                                        HBox rootD5 = new HBox();
                                        HBox rootLabelInfoD = new HBox();

                                        rootD.getChildren().add(labelD);
                                        listDu.clear();
                                        for(int a = 0; a< listDPossible.size(); a++)
                                        {
                                            
                                            RadioButton b = new RadioButton(String.valueOf(listDPossible.get(a)) + "demi-heures");
                                            listDu.add(b);
                                            b.setToggleGroup(groupDuree);
                                
                                            if(a == 0)
                                            {
                                                b.setSelected(true);
                                            }
                                            
                                            Label l1 = labelInfoD;

                                
                                            if(listDPossible.size() <= 6)
                                            {
                                                if(a<listDPossible.size()/2)
                                                    rootD.getChildren().add(b);
                                                if(a<listDPossible.size() && a>= listDPossible.size()/2)
                                                    rootD.getChildren().add(b);
                                                rootLabelInfoD.setLayoutY(380);
                                                rootLabelInfoD.setLayoutX(600);
                                                
                                            }else if(listDPossible.size() > 6 && listDPossible.size()<= 20)
                                            {
                                                if(a<listDPossible.size()/3)
                                                    rootD.getChildren().add(b);
                                                if(a<listDPossible.size()*2/3 && a>= listDPossible.size()/3)
                                                    rootD2.getChildren().add(b);
                                                if(a<listDPossible.size() && a>= listDPossible.size()*2/3)
                                                    rootD3.getChildren().add(b);
                                                rootLabelInfoD.setLayoutY(450);
                                                rootLabelInfoD.setLayoutX(600);
                                                
                                            }else if(listDPossible.size() > 20 && listDPossible.size() <= 30)
                                            {
                                                if(a<listDPossible.size()/4)
                                                    rootD.getChildren().add(b);
                                                if(a<listDPossible.size()*2/4 && a>= listDPossible.size()/4)
                                                    rootD2.getChildren().add(b);
                                                if(a<listDPossible.size()*3/4 && a>= listDPossible.size()*2/4)
                                                    rootD3.getChildren().add(b);
                                                if(a<listDPossible.size() && a>= listDPossible.size()*3/4)
                                                    rootD4.getChildren().add(b);
                                                rootLabelInfoD.setLayoutY(500);
                                                rootLabelInfoD.setLayoutX(600);
                                                
                                            }else if(listDPossible.size() > 30 && listDPossible.size() <= 50)
                                            {
                                                if(a<listDPossible.size()/5-1)
                                                    rootD.getChildren().add(b);
                                                if(a<listDPossible.size()*2/5 && a>= listDPossible.size()/5-1)
                                                    rootD2.getChildren().add(b);
                                                if(a<listDPossible.size()*3/5 && a>= listDPossible.size()*2/5)
                                                    rootD3.getChildren().add(b);
                                                if(a<listDPossible.size()*4/5 && a>= listDPossible.size()*3/5)
                                                    rootD4.getChildren().add(b);
                                                if(a<listDPossible.size() && a>= listDPossible.size()*4/5)
                                                    rootD5.getChildren().add(b);
                                                rootLabelInfoD.setLayoutY(550);
                                                rootLabelInfoD.setLayoutX(600);
                                                
                                            }else{
                                                
                                            }
                                            
                                           
                                        }
                            
                           
                                        rootLabelInfoD.setPadding(new Insets(30));
                                        rootLabelInfoD.setSpacing(8);
                                        rootLabelInfoD.getChildren().add(labelInfoD);
                                        
                                        rootD.setPadding(new Insets(30));
                                        rootD.setSpacing(8);
                                        rootD.setLayoutX(80);
                                        rootD.setLayoutY(340);
                                        rootD.setPrefSize(width, 100);
                            
                                        rootD2.setPadding(new Insets(30));
                                        rootD2.setSpacing(8);
                                        rootD2.setLayoutX(80);
                                        rootD2.setLayoutY(390);                  
                            
                                        rootD3.setPadding(new Insets(30));
                                        rootD3.setSpacing(8);
                                        rootD3.setLayoutX(80);
                                        rootD3.setLayoutY(440);  
                                        
                                        
                                        rootD4.setPadding(new Insets(30));
                                        rootD4.setSpacing(8);
                                        rootD4.setLayoutX(80);
                                        rootD4.setLayoutY(490); 
                                        
                                        rootD5.setPadding(new Insets(30));
                                        rootD5.setSpacing(8);
                                        rootD5.setLayoutX(80);
                                        rootD5.setLayoutY(540);  

                                        
                                        
                                        Button ra3 = new Button("Retour en arriere");
                                        ra3.setLayoutX(100);
                                        ra3.setLayoutY(650);
                                        
                                        Button bEtape2 = new Button("Continuer");
                                        bEtape2.setLayoutX(500);
                                        bEtape2.setLayoutY(650);
                                        
                                        ra3.setOnMouseClicked(new EventHandler<MouseEvent>() {
                                    
                                        @Override
                                        public void handle(MouseEvent event) {
                        
                                            if(event.getClickCount() >= 1){
                                                
                                                for(int i = 0; i<lrb.size(); i++)
                                                {
                                                    lrb.get(i).setVisible(true);
                                                }
                                                g.getChildren().addAll(bEtape, ra2);
                                                g.getChildren().removeAll(rootD, rootD2, rootD3, rootD4, rootD5, rootLabelInfoD, ra3, bEtape2);
                                                
                                            }
                                        }
                                    }); // FIN DU RA3 CLIQUAGE
                                        
                                        bEtape2.setOnMouseClicked(new EventHandler<MouseEvent>() {
                                    
                                        @Override
                                        public void handle(MouseEvent event) {
                        
                                            if(event.getClickCount() >= 1){
                                                
                                               g.getChildren().clear();
                                               
                                               int a = 0; 
                                               while(a<listSite.size() && !listSite.get(a).isSelected())
                                               {
                                                   a++;
                                               }
                                               String Site = listSite.get(a).getText();
                                               
                                               
                                               a=0;
                                               while(a<listHB.size() && !listHB.get(a).isSelected())
                                               {
                                                   a++;
                                               }
                                               String[] split = listHB.get(a).getText().split("h");
                                               float heuredeb;
                                               heuredeb = Float.parseFloat(split[0]);
                                               
                                               
                                               a=0;
                                               while(a<listDu.size() && !listDu.get(a).isSelected())
                                               {
                                                   a++;
                                               }
                                               String[] split2 = listDu.get(a).getText().split("demi-heures");
                                               int duree;
                                               duree = Integer.parseInt(split2[0]);
                                               
                                               
                                               ArrayList<ArrayList<Superviseur>> list = c.get_ls().QuiEstDispoParDemieHeure(dateV, heuredeb, duree, Site, 0);
                                               if(!(list.get(0).isEmpty() && list.get(1).isEmpty() && list.get(2).isEmpty() && list.get(3).isEmpty()))
                                               {
                                                   int compteur = 0;
                                                    for(int i = 0; i<list.size(); i++)
                                                    {
                                                        if(!list.get(i).isEmpty())
                                                        {
                                                            compteur ++;
                                                        }
                                                    }
                                                    switch(compteur)
                                                    {
                                                        case 1: case 2: case 3: case 4:
                                                            affichageDispo(list, g);
                                                            break;
                                                       
                                                       
                                                        default: System.out.println("impossible");
                                                            break;
                                                       
                                                    }

                                                    Button ra4 = new Button("Retour au menu");
                                                    ra4.setLayoutX(100);
                                                    ra4.setLayoutY(650);
                                               
                                                    g.getChildren().addAll(r1, imageView, Titre, ra4);
                                               
                                                    ra4.setOnMouseClicked(new EventHandler<MouseEvent>() {
                                    
                                                            @Override
                                                            public void handle(MouseEvent event) {
                        
                                                                if(event.getClickCount() >= 1){
                                                
                                                                    primaryStage.close();
                                                
                                                                }
                                                            }
                                                    }); // FIN DU RA4 CLIQUAGE
                                               }else{
                                                   
                                                   VBox dialogVbox = new VBox(20);
                                                   Text t = new Text("Il n'y a personne de disponible");
                                                   t.setUnderline(false);
                                                   t.setFill(Color.RED);
                                                   t.setFont(font);
                                                   dialogVbox.getChildren().add(t);
                                                   Scene dialogScene = new Scene(dialogVbox);
                                                   primaryStage.setTitle("Pop-up");
                                                   primaryStage.setScene(dialogScene);
                                                   primaryStage.setResizable(true);
                                                   primaryStage.setMaxHeight(300);
                                                   primaryStage.setMaxWidth(500);
                                                   primaryStage.setX(500);
                                                   primaryStage.setY(200);
                                                   primaryStage.show();
                                               }

                                               
                                                
                                            }
                                        }
                                    }); // FIN DU bEtape2 CLIQUAGE
                                        
                                        
                                        g.getChildren().addAll(rootD, rootD2, rootD3, rootD4, rootD5, rootLabelInfoD, ra3, bEtape2);
                                        // FIN POUR LE NOMBRE DE MINUTE QUE CELA VA DURER

                                }
                            }); // FIN DU BOUTON ETAPE CLIQUAGE
                            

                                               
                }
            }); // FIN DE L'ETAPE POUR LA DATE

        
       
        
     g.getChildren().addAll(r, r1, imageView, Titre, root, bAcceptDate, l);
        
        
     //Création de la Page
        Scene scene = new Scene(g, width, height/(width-2*height), Color.KHAKI);
        
        
        //Paramètres de la Page
        primaryStage.setTitle("YOORZ - Qui est Disponible quand ?");
        primaryStage.setScene(scene);
        primaryStage.show();
        primaryStage.setMaximized(true);
        primaryStage.setResizable(false);
        
    }
    
    public static void affichageDispo(ArrayList<ArrayList<Superviseur>> list, Group g)
    {
        //Il s'agit des dimensions de chaque écran  ==  ecran adapté
        Dimension dimension = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        int height = (int)dimension.getHeight();
        int width  = (int)dimension.getWidth();
        
        //Subdivision de l'écran :
        int totalh = height/54;
        int totalw = width/64;
                       
        //Police (Style) dans les boutons
            FontWeight  fontWeight  = FontWeight.BOLD;
            FontPosture fontPosture = FontPosture.ITALIC;
            Font font = Font.font("Courier New", fontWeight, fontPosture, 15);
                   
                        int compteurVert = 0;
                        int compteurRed = 0;
                        for(int i = 0; i<list.size(); i++)
                        {
                            if((!list.get(i).isEmpty() && i ==0) || (!list.get(i).isEmpty() && i==2))
                            {
                                compteurVert++;
                            }
                            
                            if((!list.get(i).isEmpty() && i ==1) || (!list.get(i).isEmpty() && i==3))
                            {
                                compteurRed++;
                            }
                        }
                        
                        
                        ArrayList<Button> listB = new ArrayList<Button>();
                        
                     int nb = 10;
                     if(compteurVert > 0) // CAS OU IL Y A AU MOINS UN VERT ( ON AFFICHE QUE CELUI LA) == CEUX DISPONIBLE
                     {
                         if(compteurVert == 2) // SI Y A LES 2
                         {
                             for(int a = 0; a<=1; a++)
                             {
                                ListView<String> lv = new ListView<>();
                                VBox vBox = new VBox();
                        
                                if(a == 0)
                                {
                                    Label l = new Label("SUR SITE et DISPONIBLE \ntout le temps");
                                    l.setTextFill(Color.WHITE);
                                    l.setFont(font);
                                    l.setStyle("-fx-alignment: CENTER;");
                                    
                                     int ROW_HEIGHT = 24;
                                     ObservableList items = FXCollections.observableArrayList();

                                     if(list.get(0).size() < nb)
                                     {
                                         for (int i=0;i<list.get(0).size(); i++)
                                         {  
                                            items.add(" " + list.get(0).get(i).getNom() + " "+ list.get(0).get(i).getPrenom());
                                         }
                                        ListView listV = new ListView(items);
                                        //This sets the initial height of the ListView:
                                        listV.setPrefHeight(items.size() * ROW_HEIGHT + 2);
                                    
                                        vBox.getChildren().addAll(listV, l);
                                        vBox.setPrefHeight((items.size() * ROW_HEIGHT + 50));
                                        vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: green;");
                                     }
                                     
                                     else{
                                         for (int i=0;i<list.get(0).size(); i++)
                                         {  
                                            lv.getItems().add(" " + list.get(0).get(i).getNom() + " "+ list.get(0).get(i).getPrenom());
                                         }
                                          vBox.getChildren().addAll(lv, l);
                                          
                                          vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: green;");
                                     }
                                     
                                    BackgroundFill myBF = new BackgroundFill(Color.GREEN, new CornerRadii(1), new Insets(10,0,0,0));
                                Background b = new Background(myBF);
                                vBox.setBackground(b);
                        
                                vBox.setOnMousePressed(e ->
                                {
                                    mouseX = e.getSceneX();
                                    mouseY = e.getSceneY();
                                    sourceX = ((Node) (e.getSource())).getTranslateX();
                                    sourceY = ((Node) (e.getSource())).getTranslateY();
                                });

                                vBox.setOnMouseDragged(e ->
                                {
                                    double newX = sourceX + e.getSceneX() - mouseX;
                                    double newY = sourceY + e.getSceneY() - mouseY;
                                    ((Node) (e.getSource())).setTranslateX(newX);
                                    ((Node) (e.getSource())).setTranslateY(newY);
                                });
          
                                vBox.setLayoutX(0/totalw);
                                vBox.setLayoutY(height*2/totalh);
                                //vBox.setPrefSize(300, 500);
                                vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: green;");
                        
                                g.getChildren().add(vBox);

                                }
                                if(a == 1)
                                {
                                    Label l = new Label("PAS SUR SITE mais \nDISPONIBLE tout le temps");
                                    l.setTextFill(Color.WHITE); 
                                    l.setFont(font);
                                    l.setStyle("-fx-alignment: CENTER;");
                                    
                                    int ROW_HEIGHT = 24;
                                     ObservableList items = FXCollections.observableArrayList();

                                     if(list.get(2).size() < nb)
                                     {
                                         for (int i=0;i<list.get(2).size(); i++)
                                         {  
                                            items.add(" " + list.get(2).get(i).getNom() + " "+ list.get(2).get(i).getPrenom());
                                         }
                                        ListView listV = new ListView(items);
                                        //This sets the initial height of the ListView:
                                        listV.setPrefHeight(items.size() * ROW_HEIGHT + 2);
                                    
                                        vBox.getChildren().addAll(listV, l);
                                        vBox.setPrefHeight((items.size() * ROW_HEIGHT + 50));
                                        vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: green;");
                                     }
                                     
                                     else{
                                         for (int i=0;i<list.get(2).size(); i++)
                                         {  
                                            lv.getItems().add(" " + list.get(2).get(i).getNom() + " "+ list.get(2).get(i).getPrenom());
                                         }
                                          vBox.getChildren().addAll(lv, l);
                                         
                                          vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: green;");
                                     }
                                     
                                     BackgroundFill myBF = new BackgroundFill(Color.GREEN, new CornerRadii(1), new Insets(10,0,0,0));
                                Background b = new Background(myBF);
                                vBox.setBackground(b);
                        
                                vBox.setOnMousePressed(e ->
                                {
                                    mouseX = e.getSceneX();
                                    mouseY = e.getSceneY();
                                    sourceX = ((Node) (e.getSource())).getTranslateX();
                                    sourceY = ((Node) (e.getSource())).getTranslateY();
                                });

                                vBox.setOnMouseDragged(e ->
                                {
                                    double newX = sourceX + e.getSceneX() - mouseX;
                                    double newY = sourceY + e.getSceneY() - mouseY;
                                    ((Node) (e.getSource())).setTranslateX(newX);
                                    ((Node) (e.getSource())).setTranslateY(newY);
                                });
          
                                vBox.setLayoutX(width*3/totalw);
                                vBox.setLayoutY(height*2/totalh);
                                //vBox.setPrefSize(300, 500);
                                vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: green;");
                        
                                g.getChildren().add(vBox);
                                }
     
                                
                            
                                
                             }
                             
                             
                             
                         }else // SI Y EN A QU'UN 
                         {
                             if(!list.get(0).isEmpty())
                             {
                                 ListView<String> lv = new ListView<>();
                                VBox vBox = new VBox();

                                    Label l = new Label("SUR SITE et DISPONIBLE \ntout le temps");
                                    l.setTextFill(Color.WHITE);
                                    l.setFont(font);
                                    l.setStyle("-fx-alignment: CENTER;");
                                    
                                    int ROW_HEIGHT = 24;
                                     ObservableList items = FXCollections.observableArrayList();

                                     if(list.get(0).size() < nb)
                                     {
                                         for (int i=0;i<list.get(0).size(); i++)
                                         {  
                                            items.add(" " + list.get(0).get(i).getNom() + " "+ list.get(0).get(i).getPrenom());
                                         }
                                        ListView listV = new ListView(items);
                                        //This sets the initial height of the ListView:
                                        listV.setPrefHeight(items.size() * ROW_HEIGHT + 2);
                                    
                                        vBox.getChildren().addAll(listV, l);
                                        vBox.setPrefHeight((items.size() * ROW_HEIGHT + 50));
                                        vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: green;");
                                     }
                                     
                                     else{
                                         for (int i=0;i<list.get(0).size(); i++)
                                         {  
                                            lv.getItems().add(" " + list.get(0).get(i).getNom() + " "+ list.get(0).get(i).getPrenom());
                                         }
                                          vBox.getChildren().addAll(lv, l);
                                          
                                          vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: green;");
                                     }
    
                            
                                BackgroundFill myBF = new BackgroundFill(Color.GREEN, new CornerRadii(1), new Insets(10,0,0,0));
                                Background b = new Background(myBF);
                                vBox.setBackground(b);
                        
                                vBox.setOnMousePressed(e ->
                                {
                                    mouseX = e.getSceneX();
                                    mouseY = e.getSceneY();
                                    sourceX = ((Node) (e.getSource())).getTranslateX();
                                    sourceY = ((Node) (e.getSource())).getTranslateY();
                                });

                                vBox.setOnMouseDragged(e ->
                                {
                                    double newX = sourceX + e.getSceneX() - mouseX;
                                    double newY = sourceY + e.getSceneY() - mouseY;
                                    ((Node) (e.getSource())).setTranslateX(newX);
                                    ((Node) (e.getSource())).setTranslateY(newY);
                                });
          
                                vBox.setLayoutX(width*6/totalw);
                                vBox.setLayoutY(height*2/totalh);
                                //vBox.setPrefSize(300, 500);
                                vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: green;");
                                g.getChildren().add(vBox);
                             }
                             
                             if(!list.get(2).isEmpty())
                             {
                                  ListView<String> lv = new ListView<>();
                                  VBox vBox = new VBox();

                                    Label l = new Label("PAS SUR SITE mais \nDISPONIBLE  tout le temps");
                                    l.setTextFill(Color.WHITE);
                                    l.setFont(font);
                                    l.setStyle("-fx-alignment: CENTER;");
                                    
                                    int ROW_HEIGHT = 24;
                                     ObservableList items = FXCollections.observableArrayList();

                                     if(list.get(2).size() < nb)
                                     {
                                         for (int i=0;i<list.get(2).size(); i++)
                                         {  
                                            items.add(" " + list.get(2).get(i).getNom() + " "+ list.get(2).get(i).getPrenom());
                                         }
                                        ListView listV = new ListView(items);
                                        //This sets the initial height of the ListView:
                                        listV.setPrefHeight(items.size() * ROW_HEIGHT + 2);
                                    
                                        vBox.getChildren().addAll(listV, l);
                                        vBox.setPrefHeight((items.size() * ROW_HEIGHT + 50));
                                        vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: green;");
                                     }
                                     
                                     else{
                                         for (int i=0;i<list.get(2).size(); i++)
                                         {  
                                            lv.getItems().add(" " + list.get(2).get(i).getNom() + " "+ list.get(2).get(i).getPrenom());
                                         }
                                          vBox.getChildren().addAll(lv, l);
                                         
                                          vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: green;");
                                     }
    
                            
                                BackgroundFill myBF = new BackgroundFill(Color.GREEN, new CornerRadii(1), new Insets(10,0,0,0));
                                Background b = new Background(myBF);
                                vBox.setBackground(b);
                        
                                vBox.setOnMousePressed(e ->
                                {
                                    mouseX = e.getSceneX();
                                    mouseY = e.getSceneY();
                                    sourceX = ((Node) (e.getSource())).getTranslateX();
                                    sourceY = ((Node) (e.getSource())).getTranslateY();
                                });

                                vBox.setOnMouseDragged(e ->
                                {
                                    double newX = sourceX + e.getSceneX() - mouseX;
                                    double newY = sourceY + e.getSceneY() - mouseY;
                                    ((Node) (e.getSource())).setTranslateX(newX);
                                    ((Node) (e.getSource())).setTranslateY(newY);
                                });
          
                                vBox.setLayoutX(width*9/totalw);
                                vBox.setLayoutY(height*2/totalh);
                                //vBox.setPrefSize(300, 500);
                        
                                g.getChildren().add(vBox);
                                vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: green;");
                             }
                         }
                     }// FIN POUR LES COMPTEURS VERTS
                     
                     if(compteurRed > 0) // CAS OU IL Y A AU MOINS UN VERT ( ON AFFICHE QUE CELUI LA)
                     {
                         if(compteurRed == 2) // SI Y A LES 2
                         {
                             for(int a = 0; a<=1; a++)
                             {
                                ListView<Object> lv = new ListView<>();
                                VBox vBox = new VBox();
                        
                                if(a == 0)
                                {
                                    Label l = new Label("SUR SITE mais PAS \nDISPONIBLE tout le temps");
                                    l.setTextFill(Color.WHITE);
                                    l.setFont(font);
                                    int ROW_HEIGHT = 24;
                                     ObservableList items = FXCollections.observableArrayList();

                                     if(list.get(1).size() < nb)
                                     {
                                         for (int i=0;i<list.get(1).size(); i++)
                                         {  
                                            String nom  = list.get(1).get(i).getNom();
                                            Button b = new Button(" > EDT");
                                            listB.add(b);
                                            items.add(" " + list.get(1).get(i).getNom() +  " "+ list.get(1).get(i).getPrenom());
                                            items.add(b); 
                                            
                                            b.setOnMouseClicked(new EventHandler<MouseEvent>() {
            
                                                @Override
                                                public void handle(MouseEvent event) {
                                                    
     
                                                   DonnéeSuperviseurINTERFACE d = new DonnéeSuperviseurINTERFACE(c.get_ls().Search_Superviseur(nom));
                                                   d.init_c(c);
                                                   Stage s = new Stage();
                                                   d.start(s);
                                                }
                                             });
                                            
                                         }
                                        ListView listV = new ListView(items);
                                        //This sets the initial height of the ListView:
                                        listV.setPrefHeight(items.size() * ROW_HEIGHT + 2);
                                    
                                        vBox.getChildren().addAll(listV, l);
                                        vBox.setPrefHeight((items.size() * ROW_HEIGHT + 50));
                                        vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: red;");
                                     }
                                     
                                     else{
                                         listB.clear();
                                         for (int i=0;i<list.get(1).size(); i++)
                                         {  
                                            String n = list.get(1).get(i).getNom();
                                            Button b = new Button(" > EDT");
                                            lv.getItems().add(" " + list.get(1).get(i).getNom() + " "+ list.get(1).get(i).getPrenom());
                                            lv.getItems().add(b);

                                             b.setOnMouseClicked(new EventHandler<MouseEvent>() {
            
                                                @Override
                                                public void handle(MouseEvent event) {
                                                    

                                                   DonnéeSuperviseurINTERFACE d = new DonnéeSuperviseurINTERFACE(c.get_ls().Search_Superviseur(n));
                                                   d.init_c(c);
                                                   Stage s = new Stage();
                                                   d.start(s);
                                                }
                                             });
                                         }
                                          vBox.getChildren().addAll(lv, l);
                                          
                                          vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: red;");
                                     }
                                     
                                     BackgroundFill myBF = new BackgroundFill(Color.RED, new CornerRadii(1), new Insets(10,0,0,0));
                                Background b = new Background(myBF);
                                vBox.setBackground(b);
                        
                                vBox.setOnMousePressed(e ->
                                {
                                    mouseX = e.getSceneX();
                                    mouseY = e.getSceneY();
                                    sourceX = ((Node) (e.getSource())).getTranslateX();
                                    sourceY = ((Node) (e.getSource())).getTranslateY();
                                });

                                vBox.setOnMouseDragged(e ->
                                {
                                    double newX = sourceX + e.getSceneX() - mouseX;
                                    double newY = sourceY + e.getSceneY() - mouseY;
                                    ((Node) (e.getSource())).setTranslateX(newX);
                                    ((Node) (e.getSource())).setTranslateY(newY);
                                });
          
                                vBox.setLayoutX(width*12/totalw);
                                vBox.setLayoutY(height*2/totalh);
                                //vBox.setPrefSize(300, 500);
                                vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: red;");
                        
                                g.getChildren().add(vBox);
                                }
                                if(a == 1)
                                {
                                    Label l = new Label("PAS SUR SITE et \nPAS DISPONIBLE tout le temps");
                                    l.setTextFill(Color.WHITE);    
                                    l.setFont(font);
                                    l.setStyle("-fx-alignment: CENTER;");
                                    int ROW_HEIGHT = 24;
                                     ObservableList items = FXCollections.observableArrayList();

                                     if(list.get(3).size() < nb)
                                     {
                                         for (int i=0;i<list.get(3).size(); i++)
                                         {  
                                            String nom  = list.get(3).get(i).getNom();
                                            Button b = new Button(" > EDT");
                                            listB.add(b);
                                            items.add(" " + list.get(3).get(i).getNom() +  " "+ list.get(3).get(i).getPrenom());
                                            items.add(b);
                                            
                                             b.setOnMouseClicked(new EventHandler<MouseEvent>() {
            
                                                @Override
                                                public void handle(MouseEvent event) {
                                                    
     
                                                   DonnéeSuperviseurINTERFACE d = new DonnéeSuperviseurINTERFACE(c.get_ls().Search_Superviseur(nom));
                                                   d.init_c(c);
                                                   Stage s = new Stage();
                                                   d.start(s);
                                                }
                                             });
                                         }
                                        ListView listV = new ListView(items);
                                        //This sets the initial height of the ListView:
                                        listV.setPrefHeight(items.size() * ROW_HEIGHT + 2);
                                    
                                        vBox.getChildren().addAll(listV, l);
                                        vBox.setPrefHeight((items.size() * ROW_HEIGHT + 50));
                                        vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: red;");
                                     }
                                     
                                     else{
                                         listB.clear();
                                         for (int i=0;i<list.get(3).size(); i++)
                                         {  
                                            String n = list.get(3).get(i).getNom();
                                            Button b = new Button(" > EDT");
                                            lv.getItems().add(" " + list.get(3).get(i).getNom() + " "+ list.get(3).get(i).getPrenom());
                                            lv.getItems().add(b);

                                             b.setOnMouseClicked(new EventHandler<MouseEvent>() {
            
                                                @Override
                                                public void handle(MouseEvent event) {
                                                    

                                                   DonnéeSuperviseurINTERFACE d = new DonnéeSuperviseurINTERFACE(c.get_ls().Search_Superviseur(n));
                                                   d.init_c(c);
                                                   Stage s = new Stage();
                                                   d.start(s);
                                                }
                                             });
                                         }
                                
                                         
                                         
                                          vBox.getChildren().addAll(lv, l);
                                        
                                          vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: red;");
                                     }
                                     
                                     BackgroundFill myBF = new BackgroundFill(Color.RED, new CornerRadii(1), new Insets(10,0,0,0));
                                Background b = new Background(myBF);
                                vBox.setBackground(b);
                        
                                vBox.setOnMousePressed(e ->
                                {
                                    mouseX = e.getSceneX();
                                    mouseY = e.getSceneY();
                                    sourceX = ((Node) (e.getSource())).getTranslateX();
                                    sourceY = ((Node) (e.getSource())).getTranslateY();
                                });

                                vBox.setOnMouseDragged(e ->
                                {
                                    double newX = sourceX + e.getSceneX() - mouseX;
                                    double newY = sourceY + e.getSceneY() - mouseY;
                                    ((Node) (e.getSource())).setTranslateX(newX);
                                    ((Node) (e.getSource())).setTranslateY(newY);
                                });
          
                                vBox.setLayoutX(width*14/totalw);
                                vBox.setLayoutY(height*2/totalh);
                                //vBox.setPrefSize(300, 500);
                                vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: red;");
                        
                                g.getChildren().add(vBox);
                                }
     
                                
                            
                                
                             }
                             
                             
                             
                         }else // SI Y EN A QU'UN 
                         {
                             if(!list.get(1).isEmpty())
                             {
                                 ListView<Object> lv = new ListView<>();
                                VBox vBox = new VBox();

                                    Label l = new Label("PAS SUR SITE mais \nPAS DISPONIBLE tout le temps");
                                    l.setTextFill(Color.WHITE);
                                    l.setFont(font);
                                    l.setStyle("-fx-alignment: CENTER;");
                                    
                                    int ROW_HEIGHT = 24;
                                     ObservableList items = FXCollections.observableArrayList();

                                     if(list.get(1).size() < nb)
                                     {
                                         for (int i=0;i<list.get(1).size(); i++)
                                         {  
         
                                            String nom  = list.get(1).get(i).getNom();
                                            Button b = new Button(" > EDT");
                                            listB.add(b);
                                            items.add(" " + list.get(1).get(i).getNom() +  " "+ list.get(1).get(i).getPrenom());
                                            items.add(b); 
                                            
                                            b.setOnMouseClicked(new EventHandler<MouseEvent>() {
            
                                                @Override
                                                public void handle(MouseEvent event) {
                                                    
     
                                                   DonnéeSuperviseurINTERFACE d = new DonnéeSuperviseurINTERFACE(c.get_ls().Search_Superviseur(nom));
                                                   d.init_c(c);
                                                   Stage s = new Stage();
                                                   d.start(s);
                                                }
                                             });
                                            
                                            
                                         }
                                        ListView listV = new ListView(items);
                                        //This sets the initial height of the ListView:
                                        listV.setPrefHeight(items.size() * ROW_HEIGHT + 2);
                                    
                                        vBox.getChildren().addAll(listV, l);
                                        vBox.setPrefHeight((items.size() * ROW_HEIGHT + 50));
                                        vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: red;");
                                     }
                                     
                                     else{
                                         listB.clear();
                                         for (int i=0;i<list.get(1).size(); i++)
                                         {  
                                            String n = list.get(1).get(i).getNom();
                                            Button b = new Button(" > EDT");
                                            lv.getItems().add(" " + list.get(1).get(i).getNom() + " "+ list.get(1).get(i).getPrenom());
                                            lv.getItems().add(b);

                                             b.setOnMouseClicked(new EventHandler<MouseEvent>() {
            
                                                @Override
                                                public void handle(MouseEvent event) {
                                                    

                                                   DonnéeSuperviseurINTERFACE d = new DonnéeSuperviseurINTERFACE(c.get_ls().Search_Superviseur(n));
                                                   d.init_c(c);
                                                   Stage s = new Stage();
                                                   d.start(s);
                                                }
                                             });
                                         }
                                         
                                          vBox.getChildren().addAll(lv, l);
                                       
                                          vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: red;");
                                     }
                            
                                BackgroundFill myBF = new BackgroundFill(Color.RED, new CornerRadii(1), new Insets(10,0,0,0));
                                Background b = new Background(myBF);
                                vBox.setBackground(b);
                        
                                vBox.setOnMousePressed(e ->
                                {
                                    mouseX = e.getSceneX();
                                    mouseY = e.getSceneY();
                                    sourceX = ((Node) (e.getSource())).getTranslateX();
                                    sourceY = ((Node) (e.getSource())).getTranslateY();
                                });

                                vBox.setOnMouseDragged(e ->
                                {
                                    double newX = sourceX + e.getSceneX() - mouseX;
                                    double newY = sourceY + e.getSceneY() - mouseY;
                                    ((Node) (e.getSource())).setTranslateX(newX);
                                    ((Node) (e.getSource())).setTranslateY(newY);
                                });
          
                                vBox.setLayoutX(width*16/totalw);
                                vBox.setLayoutY(height*2/totalh);
                                //vBox.setPrefSize(300, 500);
                                vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: red;");
                        
                                g.getChildren().add(vBox);
                             }
                             
                             if(!list.get(3).isEmpty())
                             {
                                  ListView<Object> lv = new ListView<>();
                                VBox vBox = new VBox();

                                    Label l = new Label("PAS SUR SITE et \nPAS DISPONIBLE tout le temps");
                                    l.setTextFill(Color.WHITE);
                                    l.setFont(font);
                                    l.setStyle("-fx-alignment: CENTER;");
                                    
                                    int ROW_HEIGHT = 24;
                                     ObservableList items = FXCollections.observableArrayList();

                                     if(list.get(3).size() < nb)
                                     {
                                         for (int i=0;i<list.get(3).size(); i++)
                                         {  
                                            String nom = list.get(3).get(i).getNom();
                                            Button b = new Button(" > EDT");
                                            items.add(" " + list.get(3).get(i).getNom() + " "+ list.get(3).get(i).getPrenom());
                                            items.add(b);
                                            
                                             b.setOnMouseClicked(new EventHandler<MouseEvent>() {
            
                                                @Override
                                                public void handle(MouseEvent event) {

                                                   System.out.println(nom);
                                                   DonnéeSuperviseurINTERFACE d = new DonnéeSuperviseurINTERFACE(c.get_ls().Search_Superviseur(nom));
                                                   d.init_c(c);
                                                   Stage s = new Stage();
                                                   d.start(s);
                                                }
                                             });
                                         }
                                        ListView listV = new ListView(items);
                                        //This sets the initial height of the ListView:
                                        listV.setPrefHeight(items.size() * ROW_HEIGHT + 2);
                                    
                                        vBox.getChildren().addAll(listV, l);
                                        vBox.setPrefHeight((items.size() * ROW_HEIGHT + 50));
                                        vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: red;");
                                     }
                                     
                                     else{
                                         for (int i=0;i<list.get(3).size(); i++)
                                         {  
                                            String nom = list.get(3).get(i).getNom();
                                            Button b = new Button(" > EDT");
                                            lv.getItems().add(" " + list.get(3).get(i).getNom() + " "+ list.get(3).get(i).getPrenom());
                                            lv.getItems().add(b);
                                            
                                             b.setOnMouseClicked(new EventHandler<MouseEvent>() {
            
                                                @Override
                                                public void handle(MouseEvent event) {
                                                    
                                                   System.out.println(nom);
                                                   DonnéeSuperviseurINTERFACE d = new DonnéeSuperviseurINTERFACE(c.get_ls().Search_Superviseur(nom));
                                                   d.init_c(c);
                                                   Stage s = new Stage();
                                                   d.start(s);
                                                }
                                             });
                                         }
                                          vBox.getChildren().addAll(lv, l);
                              
                                          vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: red;");
                                     }
                            
                                BackgroundFill myBF = new BackgroundFill(Color.RED, new CornerRadii(1), new Insets(10,0,0,0));
                                Background b = new Background(myBF);
                                vBox.setBackground(b);
                        
                                vBox.setOnMousePressed(e ->
                                {
                                    mouseX = e.getSceneX();
                                    mouseY = e.getSceneY();
                                    sourceX = ((Node) (e.getSource())).getTranslateX();
                                    sourceY = ((Node) (e.getSource())).getTranslateY();
                                });

                                vBox.setOnMouseDragged(e ->
                                {
                                    double newX = sourceX + e.getSceneX() - mouseX;
                                    double newY = sourceY + e.getSceneY() - mouseY;
                                    ((Node) (e.getSource())).setTranslateX(newX);
                                    ((Node) (e.getSource())).setTranslateY(newY);
                                });
          
                                vBox.setLayoutX(width/totalw);
                                vBox.setLayoutY(height*18/totalh);
                                //vBox.setPrefSize(300, 500);
                                vBox.setStyle("-fx-border-width: 5;"+ "-fx-border-color: red;");
                        
                                g.getChildren().add(vBox);
                             }
                         }
                     }// FIN POUR LES COMPTEURS ROUGE
                    
                     
                     
                        
    }
}
