/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

/**
 *
 * @author HugoBarboule
 */


import javafx.scene.Group;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.Text;
import javafx.scene.image.ImageView;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Date;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.FontWeight;

import javafx.application.Application;
import javafx.concurrent.Task;
import javafx.geometry.Orientation;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.Separator;
import javafx.scene.control.ToolBar;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/**
 *
 * @author HugoBarboule
 */


public class InitialisationINTERFACE extends Application {
    
    private Cloud c = new Cloud();
    private boolean verifclick = false;
    
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        
        //Il s'agit des dimensions de chaque écran  ==  ecran adapté
        Dimension dimension = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        int height = (int)dimension.getHeight();
        int width  = (int)dimension.getWidth();
        
        //Subdivision de l'écran :
        int totalh = height/54;
        int totalw = width/64;
        
       
        //Création du Group permettant d'avoir les 3 boutons sur le Page
        Group g = new Group();
        
        //Création de la Page
        Scene scene = new Scene(g, width, height/(width-2*height), Color.GRAY);
        
        //Création du titre de la page qui va être affiché en gros comme pour un autre site
        Text Titre = new Text("Initialisation_vers_YOORZ");
        FontPosture fontPosture2 = FontPosture.ITALIC;
        Font font2 = Font.font("Calibri", fontPosture2, 50);
        Titre.setFont(font2);
        Titre.setX(width*0.5/totalw);
        Titre.setY(height*1.25/totalh);
        Titre.setFill(Color.DARKORANGE);
        
        //Création d'un bandeau blanc en haut
        Rectangle r1 = new Rectangle();
        r1.setX(0);
        r1.setY(0);
        r1.setWidth(width);
        r1.setHeight(2*height/totalh);
        r1.setFill(Color.LIGHTGRAY);
        
        //Police (Style) dans les boutons
         FontWeight  fontWeight  = FontWeight.BOLD;
         FontPosture fontPosture = FontPosture.ITALIC;
         Font font = Font.font("Arial", fontWeight, fontPosture, 15);
         
         ArrayList compteur = new ArrayList<>();
         
         Button bNotice = new Button("Accéder à \nla Notice");
         Button bRegles = new Button("Accéder aux \nRègles\n d'utilisations");
         
        Button bMP = new Button("Acceder au Menu Principal");
        bMP.setLayoutX(width-200);
        bMP.setLayoutY(height-100);
        
        // Instanciation du bouton de la liste des EDT
        Button binitE = new Button("Initialisation des Données");
        
        bMP.setOnMouseClicked(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        if(event.getClickCount() >= 1)
                        {
                            InterfacePrincipale ip = new InterfacePrincipale();
                            ip.init_c(c);
                            Stage s2 = new Stage();
                            try{
                                 ip.start(s2); 
                            }catch(Exception e)
                            {
                                e.printStackTrace();
                            }
    
                        }
                    }
        });
         
         
        
        Button bIm = new Button("Importation des documents");
        
        //activation du changement de style pour le Bouton init Activité   
        bIm.setStyle("-fx-background-color: red;" + "-fx-background-radius: 5em;" + "-fx-alignment: CENTER;");
        bIm.setFont(font);
        bIm.setTextFill(Color.WHITE);
                
        //Changement de taille et de position pour le bouton Bureau Examens 
        bIm.setPrefSize(width*4/totalw, height*4/totalh);
        bIm.setLayoutX(width*8.5/totalw);
        bIm.setLayoutY(height*5/totalh);
        
        bIm.setOnMouseEntered(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bIm.setStyle("-fx-background-color: black;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" );
                    }
        });
        
        bIm.setOnMouseExited(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bIm.setStyle("-fx-background-color: red;" + "-fx-background-radius: 5em;" + "-fx-alignment: CENTER;");
                        bIm.setFont(font);
                        bIm.setTextFill(Color.WHITE);
                    }
        });
        
        bIm.setOnMousePressed(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        
                        if(event.getClickCount() >= 1){
                              bIm.setStyle("-fx-background-color: black;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" + "-fx-border-color: Darkblue;" + 
                                "-fx-border-width: 5px;" + "-fx-border-radius: 4.5em;" );
                              
                              try{
                               
                                 ImportationFichierINTERFACE im = new ImportationFichierINTERFACE();
                                 Stage s = new Stage();
                                 im.start(s);

                                        binitE.setDisable(false);
                                        verifclick = false;

                                 

                           
                                bIm.setStyle("-fx-background-color: grey;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" + 
                                "-fx-border-width: 5px;" + "-fx-border-radius: 4.5em;" );
                                
                               
                                
                              }catch(Exception e)
                              {
                                  e.printStackTrace();
                              }

                              
                              
                        }

                    }
        });
        
        bIm.setOnMouseReleased(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bIm.setStyle("-fx-background-color: grey;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" );
                    }
        });
        
        
        // Instanciation du bouton de la liste des Superviseurs
        Button bco = new Button("Se connecter à YOORZ");

        //activation du changement de style pour le Bouton Bureau des Examens    
        bco.setTextFill(Color.WHITE);
        bco.setStyle("-fx-background-color: red;" + "-fx-background-radius: 5em;" + "-fx-alignment: CENTER;");
        bco.setFont(font);
                
        //Changement de taille et de position pour le bouton Bureau Examens 
        bco.setPrefSize(width*4/totalw, height*4/totalh);
        bco.setLayoutX(width*3.5/totalw);
        bco.setLayoutY(height*5/totalh);
        
        bco.setOnMouseEntered(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bco.setStyle("-fx-background-color: black;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" );
                    }
        });
        
        bco.setOnMouseExited(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bco.setStyle("-fx-background-color: red;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" );
                    }
        });
        
        bco.setOnMousePressed(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        if(event.getClickCount() >= 1)
                        {
                            bco.setStyle("-fx-background-color: black;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" + "-fx-border-color: Darkblue;" + 
                                "-fx-border-width: 5px;" + "-fx-border-radius: 4.5em;" );
                            
                            // GERER L'IMPORTATION DU FICHIER "Compétences.txt"
                            
                            PageInternetINTERFACE p = new PageInternetINTERFACE();
                            Stage s = new Stage();
                            
                            p.start(s);

                            
                            bco.setStyle("-fx-background-color: grey;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" + 
                                "-fx-border-width: 5px;" + "-fx-border-radius: 4.5em;" );

                        
                        }
                        
                    }
        });
        
        
        
        bco.setOnMouseReleased(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bco.setStyle("-fx-background-color: grey;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" );
                    }
        });
        
        
        
        //Bouton initialisation des EDT
        

        //activation du changement de style pour le Bouton Bureau des Examens    
        binitE.setTextFill(Color.WHITE);
        binitE.setStyle("-fx-background-color: red;" + "-fx-background-radius: 5em;" + "-fx-alignment: CENTER;");
        binitE.setFont(font);
                
        //Changement de taille et de position pour le bouton Bureau Examens 
        binitE.setPrefSize(width*4/totalw, height*4/totalh);
        binitE.setLayoutX(width*13.5/totalw);
        binitE.setLayoutY(height*5/totalh);
        
        binitE.setOnMouseEntered(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        
                        if(verifclick)
                            binitE.setDisable(true);
                        else
                            binitE.setStyle("-fx-background-color: black;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" );
                       
                    }
        });
        
        
        
        binitE.setOnMouseExited(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        
                        if(verifclick)
                            binitE.setDisable(true);
                        else
                            binitE.setStyle("-fx-background-color: red;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" );
                    }
        });
        
        binitE.setOnMousePressed(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        if(event.getClickCount() >= 1)
                        {
                            binitE.setStyle("-fx-background-color: black;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" + "-fx-border-color: Darkblue;" + 
                                "-fx-border-width: 5px;" + "-fx-border-radius: 4.5em;" );
                            
                            // GERER L'IMPORTATION DU FICHIER "Compétences.txt"

                            Task task = new Task() {
                                @Override
                                protected Integer call() throws Exception {
                                    int iterations;
                                    scene.setCursor(Cursor.WAIT); //Change cursor to wait style
                                    bco.setDisable(true);
                                    bIm.setDisable(true);
                                    bMP.setDisable(true);
                                    bRegles.setDisable(true);
                                    bNotice.setDisable(true);
                                    binitE.setDisable(true);
                                    
                                    for (iterations = 0; iterations <4; iterations++) {
                                        if(iterations == 0)
                                        {
 
                                                c.init_ls();
                                                System.out.println(1);
                                                c.init_la();
                                                System.out.println(2);
                                                c.get_le().init_c(c);
                                                c.init_le();
                                                System.out.println(3);
                                                c.get_le().tout_attribuer();
                                                System.out.println(4);
                                                c.get_le().init_MapListNbDispo();
                                                System.out.println(5);
                                                System.out.println(c.get_le().getMapDesSuperviseurs());

                                                
                                                
                                        }
                                        
                                    }
                                    
                                    
                                    
                                scene.setCursor(Cursor.DEFAULT); //Change cursor to default style
                                bco.setDisable(false);
                                bIm.setDisable(false);
                                bMP.setDisable(false);
                                bRegles.setDisable(false);
                                bNotice.setDisable(false);
                                binitE.setDisable(false);
                                
                                return iterations;
                                }
                            };
                            Thread th = new Thread(task);
                            th.setDaemon(true);
                            th.start();
                
                            if(!g.getChildren().contains(bMP))
                                g.getChildren().add(bMP);

                            binitE.setStyle("-fx-background-color: grey;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" + 
                                "-fx-border-width: 5px;" + "-fx-border-radius: 4.5em;" );
                            binitE.setDisable(true);
                            
                            verifclick = true;
                            
                        
                        }
                        
                    }
        });
        
        
        
        binitE.setOnMouseReleased(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                       
                        if(verifclick)
                            binitE.setDisable(true);
                        else
                             binitE.setStyle("-fx-background-color: grey;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" );
                    }
        });

                
        //Création d'un Rectangle au milieu, de couleur noir
        Rectangle r = new Rectangle();
        r.setX(width*3/totalw);
        r.setY(height*3/totalh);
        r.setWidth(15.4*width/totalw);
        r.setHeight(8.5*height/totalh);
        r.setFill(Color.DARKGRAY);
        
              
        //On met le logo
        Image image = new Image("/images/logoOrange.png");
        ImageView imageView = new ImageView(image); 
        imageView.setFitWidth(width*1.5/totalw); 
        imageView.setFitHeight(height*1.5/totalh);
        imageView.setX(18*width/totalw);
        imageView.setY(height*0.25/totalh);
        
        ToolBar toolBar = new ToolBar();

        
        bNotice.setStyle("-fx-background-color: lightpink;" + "-fx-font-color: black;");
        bNotice.setPrefSize(100, 200);
        bNotice.setOnMouseEntered(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bNotice.setStyle("-fx-background-color: lightgray;" + "-fx-alignment: CENTER;" );
                        bNotice.setTextFill(Color.WHITE);
                    }
        });
        
        bNotice.setOnMouseExited(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bNotice.setStyle("-fx-background-color: lightpink;");
                    }
        });
        
        
        //Action en cliquant sur le Bouton retour arriere
                bNotice.setOnMouseClicked(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                      
                       if(event.getClickCount() >= 1)
                       {
                            NoticeINTERFACE n = new NoticeINTERFACE();
                            Stage s2 = new Stage();
                            n.start(s2);
                       }

                    }
                 }); 
        toolBar.getItems().add(bNotice);

        toolBar.getItems().add(new Separator());
        
        
        bRegles.setStyle("-fx-background-color: lightgreen;");
        bRegles.setPrefSize(100, 200);
        bRegles.setOnMouseEntered(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bRegles.setStyle("-fx-background-color: lightgray;" + "-fx-alignment: CENTER;" );
                        bRegles.setTextFill(Color.WHITE);
                    }
        });
        
        bRegles.setOnMouseExited(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bRegles.setStyle("-fx-background-color: lightgreen;");
                    }
        });
        
        //Action en cliquant sur le Bouton retour arriere
                bRegles.setOnMouseClicked(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                      
                        if(event.getClickCount() >= 1)
                        {
                            ReglesINTERFACE n = new ReglesINTERFACE();
                            Stage s2 = new Stage();
                            n.start(s2);
                        }

                    }
                 }); 
        
        toolBar.getItems().add(bRegles);
        
        toolBar.setOrientation(Orientation.VERTICAL);
        toolBar.setStyle("-fx-background-color: transparent;");
        
        VBox v = new VBox(toolBar);
        v.setLayoutX(0);
        v.setLayoutY(175);
        
        
               
        
        
        //On les mets dans le Group
        
        if(!g.getChildren().contains(r)){
            if(!g.getChildren().contains(r1)){
                if(!g.getChildren().contains(imageView)){
                     if(!g.getChildren().contains(Titre)){
                         if(!g.getChildren().contains(bco)){
                            if(!g.getChildren().contains(bIm)){
                               if(!g.getChildren().contains(binitE)){
                                    if(!g.getChildren().contains(v)){
                                            
                                        
                                        g.getChildren().addAll(r, r1, imageView, Titre, bco, bIm, binitE, v);
                                        
                                    }
                                }else{
                                   g.getChildren().add(v);
                               }
                            }else{
                                g.getChildren().add(v);
                                g.getChildren().add( binitE);
                            }
                         }else{
                                g.getChildren().add(v);
                                g.getChildren().add( binitE);
                                g.getChildren().add(bIm);
                         }
                     }else{
                         g.getChildren().add(v);
                                g.getChildren().add( binitE);
                                g.getChildren().add(bIm);
                                g.getChildren().add(bco);
                     }
                }else{
                    g.getChildren().add(v);
                                g.getChildren().add( binitE);
                                g.getChildren().add(bIm);
                                g.getChildren().add(bco);
                                g.getChildren().add(Titre);
                }
            }else{
                g.getChildren().add(v);
                                g.getChildren().add( binitE);
                                g.getChildren().add(bIm);
                                g.getChildren().add(bco);
                                g.getChildren().add(Titre);
                                g.getChildren().add(imageView);
   
            }
        }else{
            g.getChildren().add(v);
                                g.getChildren().add( binitE);
                                g.getChildren().add(bIm);
                                g.getChildren().add(bco);
                                g.getChildren().add(Titre);
                                g.getChildren().add(imageView);
                                g.getChildren().add(r1);
        }
        


        
        
        //Paramètres de la Page
        primaryStage.setTitle("YOORZ");
        primaryStage.setScene(scene);
        primaryStage.show();
        primaryStage.setMaximized(true);
        primaryStage.setResizable(true);
        
    }
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Application.launch(args);
    }
   
    
    
}

