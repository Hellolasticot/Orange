/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

import java.awt.Dimension;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author HugoBarboule
 */
public class LesSuperviseursHorairePreciseSemaine extends Application{
    
    private String clé = "";
    private Cloud c = new Cloud();
    
    public LesSuperviseursHorairePreciseSemaine(String clé, Cloud c)
    {
        this.clé = clé;
        this.c = c;
    }
    
    
    public void start(final Stage primaryStage) {
        
        //Il s'agit des dimensions de chaque écran  ==  ecran adapté
        Dimension dimension = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        int height = (int)dimension.getHeight();
        int width  = (int)dimension.getWidth();
        
        //Subdivision de l'écran :
        int totalh = height/54;
        int totalw = width/64;

        ListView lv = new ListView();
        

        for(int i = 0; i<c.get_le().getMapDesSuperviseurs().get(this.clé).size(); i++)
        {
            String ligne = " " +c.get_le().getMapDesSuperviseurs().get(this.clé).get(i).getNom() + " "+
                    c.get_le().getMapDesSuperviseurs().get(this.clé).get(i).getPrenom() + " "+
                    c.get_le().getMapDesSuperviseurs().get(this.clé).get(i).getSite() + "   /  "+
                    c.get_le().getMapDesSuperviseurs().get(this.clé).get(i).getCUID();
            
            if(!c.get_ls().get_listSite().contains(c.get_le().getMapDesSuperviseurs().get(this.clé).get(i).getNom()) 
                    && !lv.getItems().contains(ligne))
            {
                 lv.getItems().add(ligne);
            }
               
        }
        
        
        VBox dialogVbox = new VBox();
        dialogVbox.getChildren().add(lv);
       // dialogVbox.getChildren().add(new Text(texte));
        Scene dialogScene = new Scene(dialogVbox, width*9/totalw, height*9/totalh);
        primaryStage.setTitle("Les Superviseurs disponible à : "+this.clé);
        primaryStage.setScene(dialogScene);
        primaryStage.show();
    }

}
