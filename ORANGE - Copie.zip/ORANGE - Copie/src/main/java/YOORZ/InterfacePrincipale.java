/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

import javafx.scene.Group;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.Text;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.awt.Dimension;
import java.util.Calendar;
import javafx.geometry.Insets;
import java.util.Date;
import java.util.Locale;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.FontWeight;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.geometry.Orientation;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Separator;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/**
 *
 * @author HugoBarboule
 */
public class InterfacePrincipale extends Application {
    
    private double mouseX;
    private double mouseY;
    private double sourceX;
    private double sourceY;
    private Cloud c;
    
    public void init_c(Cloud c)
    {
        this.c = c;
    }
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        
        //Il s'agit des dimensions de chaque écran  ==  ecran adapté
        Dimension dimension = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        int height = (int)dimension.getHeight();
        int width  = (int)dimension.getWidth();
        
        //Subdivision de l'écran :
        int totalh = height/54;
        int totalw = width/64;
        
       
        //Création du Group permettant d'avoir les 3 boutons sur le Page
        Group g = new Group();
        
        //Création du titre de la page qui va être affiché en gros comme pour un autre site
        Text Titre = new Text("Orange_YOORZ");
        FontPosture fontPosture2 = FontPosture.ITALIC;
        Font font2 = Font.font("Calibri", fontPosture2, 50);
        Titre.setFont(font2);
        Titre.setX(width*0.5/totalw);
        Titre.setY(height*1.25/totalh);
        Titre.setFill(Color.DARKORANGE);
        
        //Création d'un bandeau blanc en haut
        Rectangle r1 = new Rectangle();
        r1.setX(0);
        r1.setY(0);
        r1.setWidth(width);
        r1.setHeight(2*height/totalh);
        r1.setFill(Color.WHITE);
        
        //Police (Style) dans les boutons
         FontWeight  fontWeight  = FontWeight.BOLD;
         FontPosture fontPosture = FontPosture.ITALIC;
         Font font = Font.font("Arial", fontWeight, fontPosture, 15);
        
        Button bQuiEstDispo = new Button("Savoir Qui est Disponible Quand");
        
        //activation du changement de style pour le Bouton Bureau des Examens    
        bQuiEstDispo.setTextFill(Color.ORANGE);
        bQuiEstDispo.setStyle("-fx-background-color: red;" + "-fx-background-radius: 5em;" + "-fx-alignment: CENTER;");
        bQuiEstDispo.setFont(font);
        bQuiEstDispo.setTextFill(Color.WHITE);
                
        //Changement de taille et de position pour le bouton Bureau Examens 
        bQuiEstDispo.setPrefSize(width*4/totalw, height*4/totalh);
        bQuiEstDispo.setLayoutX(width*8.5/totalw);
        bQuiEstDispo.setLayoutY(height*5/totalh);
        
        bQuiEstDispo.setOnMouseEntered(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bQuiEstDispo.setStyle("-fx-background-color: black;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" );
                    }
        });
        
        bQuiEstDispo.setOnMouseExited(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bQuiEstDispo.setStyle("-fx-background-color: red;" + "-fx-background-radius: 5em;" + "-fx-alignment: CENTER;");
                        bQuiEstDispo.setFont(font);
                        bQuiEstDispo.setTextFill(Color.WHITE);
                    }
        });
        
        bQuiEstDispo.setOnMousePressed(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        
                        if(event.getClickCount() >= 1){
                              bQuiEstDispo.setStyle("-fx-background-color: black;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" + "-fx-border-color: Darkblue;" + 
                                "-fx-border-width: 5px;" + "-fx-border-radius: 4.5em;" );
                              
                              //Action en cliquant sur le Bouton retour arriere
                              bQuiEstDispo.setOnAction(new EventHandler<ActionEvent>() {
            
                              @Override
                                public void handle(ActionEvent event) {
                      
                                try{
                                    Qui_est_dispoINTERFACE q = new Qui_est_dispoINTERFACE();
                                    q.init_c(c);
                                    Stage sQ = new Stage();
                                    q.start(sQ);
                                }catch(Exception e){
                                    e.printStackTrace();
                                }
                            }
                        });
                        }

                    }
        });
        
        bQuiEstDispo.setOnMouseReleased(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bQuiEstDispo.setStyle("-fx-background-color: grey;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" );
                    }
        });
        
        
        // Instanciation du bouton de la liste des Superviseurs
        Button bListeSuperv = new Button("Liste des \nSuperviseurs");

        //activation du changement de style pour le Bouton Bureau des Examens    
        bListeSuperv.setTextFill(Color.ORANGE);
        bListeSuperv.setStyle("-fx-background-color: #fffacd;" + "-fx-background-radius: 5em;" + "-fx-alignment: CENTER;");
        bListeSuperv.setFont(font);
                
        //Changement de taille et de position pour le bouton Bureau Examens 
        bListeSuperv.setPrefSize(width*3.5/totalw, height*3/totalh);
        bListeSuperv.setLayoutX(width*4/totalw);
        bListeSuperv.setLayoutY(height*4/totalh);
        
        bListeSuperv.setOnMouseEntered(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bListeSuperv.setStyle("-fx-background-color: black;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" );
                    }
        });
        
        bListeSuperv.setOnMouseExited(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bListeSuperv.setStyle("-fx-background-color: #fffacd;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" );
                    }
        });
        
        bListeSuperv.setOnMousePressed(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        if(event.getClickCount() >= 1)
                        {
                            bListeSuperv.setStyle("-fx-background-color: black;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" + "-fx-border-color: Darkblue;" + 
                                "-fx-border-width: 5px;" + "-fx-border-radius: 4.5em;" );
                        
                        
                        
                        
                        ListView<String> lv = new ListView<>();
                        
                        for (int i=0;i<c.get_ls().get_list().size();i++){
                            lv.getItems().add(" " + c.get_ls().get_list().get(i).getNom() + " "+ c.get_ls().get_list().get(i).getPrenom());       
                        }
                        
                        
                        ObservableList selectedIndices = lv.getSelectionModel().getSelectedIndices();
        
                        EventHandler<MouseEvent> eventHandler = new EventHandler<MouseEvent>() { 
                            
                            @Override 
                            public void handle(MouseEvent e) { 
                                        if(e.getClickCount()>=1)
                                        {
                                            // FAIRE UN CHARGEMENT VIA UN TIMER
                                            //ListeSuperviseurs ls = new ListeSuperviseurs();
                                            //ls.init_list();
                                            
                                            //On active ce qu'il y a dans l'autre classe BE
                                            String nom = selectedIndices.toString();
                                            //On fait un toCharArray car l'indice du superviseur est entre crochet
                                            char[] tab=nom.toCharArray();
                                            String n=new String();
                                            for (int k=1;k<tab.length-1;k++){
                                                n+=tab[k];
                                            }
                                            int a=Integer.parseInt(n);
                                            
                                            DonnéeSuperviseurINTERFACE dsi = new DonnéeSuperviseurINTERFACE(c.get_ls().get_list().get(a));
                                            dsi.init_c(c);
                                            Stage s = new Stage();
                                            dsi.start(s);
                                            
                                        }
                           }
                        };
                        lv.addEventFilter(MouseEvent.MOUSE_CLICKED, eventHandler);
                        
                        

                        Image croix = new Image("/images/CROIX.png");
                        ImageView imageView3 = new ImageView(croix); 
                        imageView3.setFitWidth(20); 
                        imageView3.setFitHeight(20);
                        Button ra2 = new Button("",imageView3);
                        ra2.setPrefSize(20, 20); 
                        ra2.setFont(font);
                        ra2.setStyle("-fx-background-color: red;" + "-fx-background-radius: 5em;");

                        
                        VBox vBox = new VBox(ra2, lv);
                        BackgroundFill myBF = new BackgroundFill(Color.LIGHTGRAY, new CornerRadii(1), new Insets(10,0,0,0));
                        Background b = new Background(myBF);
                        vBox.setBackground(b);
                        
                        vBox.setOnMousePressed(e ->
                        {
                            mouseX = e.getSceneX();
                            mouseY = e.getSceneY();
                            sourceX = ((Node) (e.getSource())).getTranslateX();
                            sourceY = ((Node) (e.getSource())).getTranslateY();
                        });

                        vBox.setOnMouseDragged(e ->
                        {
                            double newX = sourceX + e.getSceneX() - mouseX;
                            double newY = sourceY + e.getSceneY() - mouseY;
                            ((Node) (e.getSource())).setTranslateX(newX);
                            ((Node) (e.getSource())).setTranslateY(newY);
                        });
          
                        vBox.setLayoutX(width*5.5/totalw);
                        vBox.setLayoutY(height*2/totalh);
                        vBox.setPrefSize(300, 450);
                        g.getChildren().add(vBox);
                        
                        //Action en cliquant sur le Bouton retour arriere
                        ra2.setOnAction(new EventHandler<ActionEvent>() {
            
                            @Override
                            public void handle(ActionEvent event) {
                      
                                try{
                                    g.getChildren().remove(vBox);
                                }catch(Exception e){
                                    e.printStackTrace();
                                }
                            }
                        });
                        
                        ra2.setOnMouseEntered(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        ra2.setStyle("-fx-background-color: darkred;" + "-fx-alignment: CENTER;" + "-fx-background-radius: 5em;" );
                        ra2.setTextFill(Color.WHITE);
                    }
        });
        
        ra2.setOnMouseExited(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        ra2.setStyle("-fx-background-color: red;" + "-fx-background-radius: 5em;");
                    }
        });
        
        ra2.setOnMouseReleased(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        ra2.setStyle("-fx-background-color: red;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" );
                    }
        });
        
                        
                        
                        
                        }
                        
                    }
        });
        
        
        
        bListeSuperv.setOnMouseReleased(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bListeSuperv.setStyle("-fx-background-color: grey;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" );
                    }
        });
        
        
        
        
        ToolBar toolBar = new ToolBar();

        Button bNotice = new Button("Accéder à \nla Notice");
        bNotice.setStyle("-fx-background-color: lightpink;" + "-fx-font-color: black;");
        bNotice.setPrefSize(100, 200);
        bNotice.setOnMouseEntered(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bNotice.setStyle("-fx-background-color: lightgray;" + "-fx-alignment: CENTER;" );
                        bNotice.setTextFill(Color.WHITE);
                    }
        });
        
        bNotice.setOnMouseExited(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bNotice.setStyle("-fx-background-color: lightpink;");
                    }
        });
        
        
        //Action en cliquant sur le Bouton retour arriere
                bNotice.setOnMouseClicked(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                      
                       if(event.getClickCount() >= 1)
                       {
                            NoticeINTERFACE n = new NoticeINTERFACE();
                            Stage s2 = new Stage();
                            n.start(s2);
                       }

                    }
                 }); 
        
        
        
        toolBar.getItems().add(bNotice);

        toolBar.getItems().add(new Separator());
        
        Button bRegles = new Button("Accéder aux \nRègles\n d'utilisations");
        bRegles.setStyle("-fx-background-color: lightgreen;");
        bRegles.setPrefSize(100, 200);
        bRegles.setOnMouseEntered(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bRegles.setStyle("-fx-background-color: lightgray;" + "-fx-alignment: CENTER;" );
                        bRegles.setTextFill(Color.WHITE);
                    }
        });
        
        bRegles.setOnMouseExited(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bRegles.setStyle("-fx-background-color: lightgreen;");
                    }
        });
        
        //Action en cliquant sur le Bouton retour arriere
                bRegles.setOnMouseClicked(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                      
                        if(event.getClickCount() >= 1)
                        {
                            ReglesINTERFACE n = new ReglesINTERFACE();
                            Stage s2 = new Stage();
                            n.start(s2);
                        }

                    }
                 }); 
        
        toolBar.getItems().add(bRegles);
        
        toolBar.setOrientation(Orientation.VERTICAL);
        toolBar.setStyle("-fx-background-color: transparent;");
        
        VBox v = new VBox(toolBar);
        v.setLayoutX(0);
        v.setLayoutY(175);
        
        
        // Instanciation du bouton de la liste des Superviseurs
        Button bI = new Button("Qui fait quoi \nAujourd'hui ?");

        //activation du changement de style pour le Bouton Bureau des Examens    
        bI.setTextFill(Color.ORANGE);
        bI.setStyle("-fx-background-color: #fffacd;" + "-fx-background-radius: 5em;" + "-fx-alignment: CENTER;");
        bI.setFont(font);
                
        //Changement de taille et de position pour le bouton Bureau Examens 
        bI.setPrefSize(width*3.5/totalw, height*3/totalh);
        bI.setLayoutX(width*14/totalw);
        bI.setLayoutY(height*4/totalh);
        
        bI.setOnMouseEntered(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bI.setStyle("-fx-background-color: black;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" );
                    }
        });
        
        bI.setOnMouseExited(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bI.setStyle("-fx-background-color: #fffacd;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" );
                    }
        });
        
        bI.setOnMousePressed(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        if(event.getClickCount() >= 1)
                        {
                            bI.setStyle("-fx-background-color: black;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" + "-fx-border-color: Darkblue;" + 
                                "-fx-border-width: 5px;" + "-fx-border-radius: 4.5em;" );

                            DatePickerINTERFACE d = new DatePickerINTERFACE();
                            d.init_c(c);
                            Stage s = new Stage();
                            d.start(s);
                            

                        }
                        
                    }
        });
        
        
        
        bI.setOnMouseReleased(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bI.setStyle("-fx-background-color: grey;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" );
                    }
        });
        
        
        
        // Instanciation du bouton de la liste des Superviseurs
        Button bSJ = new Button("Les Statistiques");

        //activation du changement de style pour le Bouton Bureau des Examens    
        bSJ.setTextFill(Color.ORANGE);
        bSJ.setStyle("-fx-background-color: #fffacd;" + "-fx-background-radius: 5em;" + "-fx-alignment: CENTER;");
        bSJ.setFont(font);
                
        //Changement de taille et de position pour le bouton Bureau Examens 
        bSJ.setPrefSize(width*3.5/totalw, height*3/totalh);
        bSJ.setLayoutX(width*14/totalw);
        bSJ.setLayoutY(height*8/totalh);
        
        bSJ.setOnMouseEntered(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bSJ.setStyle("-fx-background-color: black;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" );
                    }
        });
        
        bSJ.setOnMouseExited(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bSJ.setStyle("-fx-background-color: #fffacd;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" );
                    }
        });
        
        bSJ.setOnMousePressed(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        if(event.getClickCount() >= 1)
                        {
                            bSJ.setStyle("-fx-background-color: black;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" + "-fx-border-color: Darkblue;" + 
                                "-fx-border-width: 5px;" + "-fx-border-radius: 4.5em;" );

                            StatsInterface sti = new StatsInterface();
                            sti.init_c(c);
                            Stage s = new Stage();
                            sti.start(s);
                            

                        }
                        
                    }
        });
        
        
        
        bSJ.setOnMouseReleased(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bSJ.setStyle("-fx-background-color: grey;" + "-fx-background-radius: 5em;"+ "-fx-alignment: CENTER;" );
                    }
        });
        
        
        
        
        
                
        //Création d'un Rectangle au milieu, de couleur noir
        Rectangle r = new Rectangle();
        r.setX(width*3/totalw);
        r.setY(height*3/totalh);
        r.setWidth(15.4*width/totalw);
        r.setHeight(8.5*height/totalh);
        r.setFill(Color.DARKORANGE);
        
              
        //On met le logo
        

        Image image = new Image("/images/logoOrange.png");
        ImageView imageView = new ImageView(image); 
        imageView.setFitWidth(width*1.5/totalw); 
        imageView.setFitHeight(height*1.5/totalh);
        imageView.setX(18*width/totalw);
        imageView.setY(height*0.25/totalh);
        
        Button raInit = new Button("Retour à l'Initialisation");
        raInit.setLayoutX(50);
        raInit.setLayoutY(height-100);
        
        //Action en cliquant sur le Bouton retour arriere
                raInit.setOnMouseClicked(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                      
                        if(event.getClickCount() >= 1)
                        {
                            primaryStage.close();
                        }

                    }
                 }); 
        
        //On les mets dans le Group
        g.getChildren().addAll(r, r1, imageView, Titre, bListeSuperv, bQuiEstDispo, bI, bSJ, v, raInit);

        
        //Création de la Page
        Scene scene = new Scene(g, width, height/(width-2*height), Color.KHAKI);
        
        
        //Paramètres de la Page
        primaryStage.setTitle("YOORZ");
        primaryStage.setScene(scene);
        primaryStage.show();
        primaryStage.setMaximized(true);
        primaryStage.setResizable(true);
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Application.launch(args);
    }
   
}
