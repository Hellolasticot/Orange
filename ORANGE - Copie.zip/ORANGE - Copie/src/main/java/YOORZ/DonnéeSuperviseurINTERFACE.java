/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

import java.awt.Dimension;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.util.Callback;

/**
 *
 * @author HugoBarboule
 */
public class DonnéeSuperviseurINTERFACE {
    private final Superviseur s;
    private Cloud c;
    
    public void init_c(Cloud c)
    {
        this.c = c;
    }
        
    public DonnéeSuperviseurINTERFACE(Superviseur s)
    {
        this.s = s;
    }

    public void start(Stage primaryStage){
        
        
        //Il s'agit des dimensions de chaque écran  ==  ecran adapté
        Dimension dimension = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        int height = (int)dimension.getHeight();
        int width  = (int)dimension.getWidth();
        
        //Subdivision de l'écran :
        int totalh = height/54;
        int totalw = width/64;
        
 
        String nom ="";
        
  
        ObservableList<EDTSuperv> data2 = FXCollections.observableArrayList();
        int i = 0;
        boolean atrouvé = false;
        while(i<c.get_ls().get_list().size() && !atrouvé)
        {
             atrouvé = (c.get_ls().get_list().get(i).getNom().toUpperCase().equals(this.s.getNom().toUpperCase()));
             if(atrouvé)
             {
                 nom = c.get_ls().get_list().get(i).getNom() + " " + c.get_ls().get_list().get(i).getPrenom();
                 for(int a = 0; a<c.get_ls().get_list().get(i).getEdt().size(); a++)
                 {
                    data2.add(c.get_ls().get_list().get(i).getEdt().get(a));  
                 }

             }
             else{
                 i++;
             }
         
        }
        
        
        //CREATION DES TABLES VIEW           
        TableView<EDTSuperv> tableView = new TableView<>(data2);
        tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        tableView.setStyle("-fx-background-color: blue;");
        tableView.setEditable(true);
                     
       
        //TableColumn<EDTSuperv, String> base = new TableColumn<>("Liste des Emploi du temps");
    
        
        TableColumn<EDTSuperv, String> Date = new TableColumn<>("Date");
        
        
        TableColumn<EDTSuperv, String> Activité = new TableColumn<>("Activité");
        TableColumn<EDTSuperv, String> clé = new TableColumn<>("Clé");
        
    
        
        TableColumn<EDTSuperv, HBox> EDT = new TableColumn<>("Emploi du temps");
        //EDT.setStyle("-fx-alignment: LEFT;" + "-fx-text-align: left;");
        EDT.setStyle( "-fx-alignment: LEFT;");
        
        TableColumn<EDTSuperv, HBox> minuit = new TableColumn<>("00h-00h30");
        TableColumn<EDTSuperv, HBox> minuit30 = new TableColumn<>("00h30-01h");
        TableColumn<EDTSuperv, HBox> uh = new TableColumn<>("01h-01h30");
        TableColumn<EDTSuperv, HBox> uh30 = new TableColumn<>("01h30-02h");
        TableColumn<EDTSuperv, HBox> deh = new TableColumn<>("02h-02h30");
        TableColumn<EDTSuperv, HBox> deh30 = new TableColumn<>("02h30-03h");
        TableColumn<EDTSuperv, HBox> trh = new TableColumn<>("03h-03h30");
        TableColumn<EDTSuperv, HBox> trh30 = new TableColumn<>("03h30-04h");
        TableColumn<EDTSuperv, HBox> qh = new TableColumn<>("04h-04h30");
        TableColumn<EDTSuperv, HBox> qh30 = new TableColumn<>("04h30-05h");
        TableColumn<EDTSuperv, HBox> ch = new TableColumn<>("05h-05h30");
        TableColumn<EDTSuperv, HBox> ch30 = new TableColumn<>("05h30-06h");
        TableColumn<EDTSuperv, HBox> sh = new TableColumn<>("06h-06h30");
        TableColumn<EDTSuperv, HBox> sh30 = new TableColumn<>("06h30-07h");
        TableColumn<EDTSuperv, HBox> seph = new TableColumn<>("07h-07h30");
        TableColumn<EDTSuperv, HBox> seph30 = new TableColumn<>("07h30-08h");
        TableColumn<EDTSuperv, HBox> hh = new TableColumn<>("08h-08h30");
        TableColumn<EDTSuperv, HBox> hh30 = new TableColumn<>("08h30-09h");
        TableColumn<EDTSuperv, HBox> nh = new TableColumn<>("09h-09h30");
        TableColumn<EDTSuperv, HBox> nh30 = new TableColumn<>("09h30-10h");
        TableColumn<EDTSuperv, HBox> dh = new TableColumn<>("10h-10h30");
        TableColumn<EDTSuperv, HBox> dh30 = new TableColumn<>("10h30-11h");
        TableColumn<EDTSuperv, HBox> oh = new TableColumn<>("11h-11h30");
        TableColumn<EDTSuperv, HBox> oh30 = new TableColumn<>("11h30-12h");
        TableColumn<EDTSuperv, HBox> doh = new TableColumn<>("12h-12h30");
        TableColumn<EDTSuperv, HBox> doh30 = new TableColumn<>("12h30-13h");
        TableColumn<EDTSuperv, HBox> th = new TableColumn<>("13h-13h30");
        TableColumn<EDTSuperv, HBox> th30 = new TableColumn<>("13h30-14h");
        TableColumn<EDTSuperv, HBox> quatoh = new TableColumn<>("14h-14h30");
        TableColumn<EDTSuperv, HBox> quatoh30 = new TableColumn<>("14h30-15h");
        TableColumn<EDTSuperv, HBox> quinh = new TableColumn<>("15h-15h30");
        TableColumn<EDTSuperv, HBox> quinh30 = new TableColumn<>("15h30-16h");
        TableColumn<EDTSuperv, HBox> seih = new TableColumn<>("16h-16h30");
        TableColumn<EDTSuperv, HBox> seih30 = new TableColumn<>("16h30-17h");
        TableColumn<EDTSuperv, HBox> dixsh = new TableColumn<>("17h-17h30");
        TableColumn<EDTSuperv, HBox> dixsh30 = new TableColumn<>("17h30-18h");
        TableColumn<EDTSuperv, HBox> dixhh = new TableColumn<>("18h-18h30");
        TableColumn<EDTSuperv, HBox> dixhh30 = new TableColumn<>("18h30-19h");
        TableColumn<EDTSuperv, HBox> dixnh = new TableColumn<>("19h-19h30");
        TableColumn<EDTSuperv, HBox> dixnh30 = new TableColumn<>("19h30-20h");
        TableColumn<EDTSuperv, HBox> vh = new TableColumn<>("20h-20h30");
        TableColumn<EDTSuperv, HBox> vh30 = new TableColumn<>("20h30-21h");
        TableColumn<EDTSuperv, HBox> vunh = new TableColumn<>("21h-21h30");
        TableColumn<EDTSuperv, HBox> vunh30 = new TableColumn<>("21h30-22h");
        TableColumn<EDTSuperv, HBox> vdeuxh = new TableColumn<>("22h-22h30");
        TableColumn<EDTSuperv, HBox> vdeuxh30 = new TableColumn<>("22h30-23h");
        TableColumn<EDTSuperv, HBox> vtroish = new TableColumn<>("23h-23h30");
        TableColumn<EDTSuperv, HBox> vtroish30 = new TableColumn<>("23h30-24h");
        
        
      
        
          
        
        //PARTIE AFFICHAGE DE DONNEE
        
       //DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        
        Date.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<EDTSuperv, String> column){
                return column.getValue().getVDate();
            }
 
        });
        
        clé.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<EDTSuperv, String> column){
                return new SimpleStringProperty(column.getValue().getNom());
            }
 
        });
        
        Activité.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<EDTSuperv, String> column){
                return column.getValue().getVNomActivité();
            }
 
        });
        
        
        
        minuit.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                    HBox h = new HBox();
                if(!(column.getValue().getMap().get(0f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setAlignment(Pos.CENTER);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setAlignment(Pos.CENTER);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
        });
        
        
       minuit30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                  HBox h = new HBox();
                if(!(column.getValue().getMap().get(0.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.setAlignment(Pos.CENTER);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    h.setAlignment(Pos.CENTER);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        uh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(1f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        uh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(1.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        deh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(2f) == 0))
                {
                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        deh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(2.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        trh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(3f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        trh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(3.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        qh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(4f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        qh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(4.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        ch.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        ch30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(5.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        sh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(6f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        sh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(6.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        seph.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(7f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        seph30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(7.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        hh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(8f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        hh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(8.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        nh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(9f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        nh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(9.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        dh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(10f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        dh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(10.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        oh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(11f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
         oh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(11.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
         
          doh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(12f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
          
           doh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(12.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
           
            th.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(13f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
            
             th30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(13.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
             
             quatoh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(14f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
             
              quatoh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(14.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
              
               quinh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(15f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
               
                quinh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(15.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                
                 seih.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(16f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                 
                  seih30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(16.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                  
                   dixsh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(17f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                   
                    dixsh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(17.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                    
                     dixhh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(18f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                     
                      dixhh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(18.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                      
                       dixnh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(19f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                       
                        dixnh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(19.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                        
                         vh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(20f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                          vh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(20.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
                          
                           vunh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(21f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                           
                            vunh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(21.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                            
                             vdeuxh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(22f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                             
                              vdeuxh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(22.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                              
                               vtroish.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(23f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                                vtroish30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(23.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                                
        EDT.getColumns().addAll(minuit, minuit30, uh, uh30, deh, deh30, trh, trh30, qh, qh30, ch, ch30, sh, sh30,
                                    seph, seph30, hh, hh30, nh, nh30, dh, dh30, oh, oh30, doh, doh30, th, th30,
                                    quatoh, quatoh30, quinh, quinh30, seih, seih30, dixsh, dixsh30, dixhh, dixhh30,
                                    dixnh, dixnh30, vh, vh30, vunh, vunh30, vdeuxh, vdeuxh30, vtroish, vtroish30);
        

        EDT.setStyle("fx-text-alignment: left;");
      

        tableView.getColumns().addAll(Date, Activité,clé, EDT);
        tableView.setPrefHeight(height);

        
        ScrollPane sp = new ScrollPane();
        sp.setStyle("-fx-font-size: 14px;");
        sp.setContent(tableView);
        sp.setHbarPolicy(ScrollBarPolicy.ALWAYS);
   
        
        StackPane root = new StackPane();
        root.setStyle("-fx-background-color: orange");
        root.getChildren().addAll(sp, tableView);
        //root.setMargin(tableView, new Insets(10, 10, 10, 10));


        Scene scene = new Scene(root, Color.DARKORANGE);
        
        
                         
         //Paramètres de la Page
          primaryStage.setTitle("les Emploi du Temps de "+nom.toUpperCase());
          primaryStage.setScene(scene);
          primaryStage.show();
          primaryStage.setMaximized(true); 
          primaryStage.setResizable(false);
         
        
    }
    
    
}
