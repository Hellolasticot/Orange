/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

import java.util.ArrayList;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class PieChartSemaineJour extends Application {

    private Cloud c = new Cloud();
    private ArrayList<Integer> list;

    public PieChartSemaineJour(Cloud c, ArrayList<Integer> list) {
        this.list = list;
        this.c = c;
    }
    
    
    
    
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("PieChart de la semaine");

        PieChart pieChart = new PieChart();

        int somme = 0;
        for(int i = 0; i<this.list.size(); i++)
        {
            somme += this.list.get(i);
        }
        PieChart.Data slice1 = new PieChart.Data("Lundi", (list.get(0)*360)/somme);
        PieChart.Data slice2 = new PieChart.Data("Mardi", (list.get(1)*360)/somme);
        PieChart.Data slice3 = new PieChart.Data("Mercredi", (list.get(2)*360)/somme);
        PieChart.Data slice4 = new PieChart.Data("Jeudi", (list.get(3)*360)/somme);
        PieChart.Data slice5 = new PieChart.Data("Vendredi", (list.get(4)*360)/somme);
        PieChart.Data slice6 = new PieChart.Data("Samedi", (list.get(5)*360)/somme);
        PieChart.Data slice7 = new PieChart.Data("Dimanche", (list.get(6)*360)/somme);

        pieChart.getData().add(slice1);
        pieChart.getData().add(slice2);
        pieChart.getData().add(slice3);
        pieChart.getData().add(slice4);
        pieChart.getData().add(slice5);
        pieChart.getData().add(slice6);
        pieChart.getData().add(slice7);
        
        
        double poucentage1 = ((pieChart.getData().get(0).getPieValue())/360)*100;
        pieChart.getData().get(0).setName(slice1.getName()+ "   -   "+(int) poucentage1+"%");
        double poucentage2 = ((pieChart.getData().get(1).getPieValue())/360)*100;
        pieChart.getData().get(1).setName(slice2.getName()+ "   -   "+(int) poucentage2+"%");
        double poucentage3 = ((pieChart.getData().get(2).getPieValue())/360)*100;
        pieChart.getData().get(2).setName(slice3.getName()+ "   -   "+(int) poucentage3+"%");
        double poucentage4 = ((pieChart.getData().get(3).getPieValue())/360)*100;
        pieChart.getData().get(3).setName(slice4.getName()+ "   -   "+(int) poucentage4+"%");
        double poucentage5 = ((pieChart.getData().get(4).getPieValue())/360)*100;
        pieChart.getData().get(4).setName(slice5.getName()+ "   -   "+(int) poucentage5+"%");
        double poucentage6 = ((pieChart.getData().get(5).getPieValue())/360)*100;
        pieChart.getData().get(5).setName(slice6.getName()+ "   -   "+(int) poucentage6+"%");
        
        
        VBox vbox = new VBox(pieChart);

        Scene scene = new Scene(vbox, 400, 200);

        primaryStage.setScene(scene);
        primaryStage.setHeight(300);
        primaryStage.setWidth(1200);

        primaryStage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}