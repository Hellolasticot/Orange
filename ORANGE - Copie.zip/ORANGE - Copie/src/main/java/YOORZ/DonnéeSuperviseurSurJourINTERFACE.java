/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

import java.awt.Dimension;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.util.Callback;

/**
 *
 * @author HugoBarboule
 */
public class DonnéeSuperviseurSurJourINTERFACE {
    private Superviseur s;
    private Cloud c;
    private String date;
    
    public void init_c(Cloud c)
    {
        this.c = c;
    }
        
    public DonnéeSuperviseurSurJourINTERFACE(String date)
    {
        this.date = date;
    }

    public void start(Stage primaryStage){
        
        System.out.println("clé : "+this.date);
        
        //Il s'agit des dimensions de chaque écran  ==  ecran adapté
        Dimension dimension = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        int height = (int)dimension.getHeight();
        int width  = (int)dimension.getWidth();
        
        //Subdivision de l'écran :
        int totalh = height/54;
        int totalw = width/64;
        

        
  
        ObservableList<EDTSuperv> data2 = FXCollections.observableArrayList();
        //dans tous les superviseurs dans cette map
        Iterator it = c.get_le().getMapDesSuperviseurs().entrySet().iterator();
        boolean at = false;
        while(it.hasNext() && !at)
        {
                 Map.Entry mapentry = (Map.Entry) it.next();
                 
                 //si la date correspond (dans le bon format) 
                 if(( (String) mapentry.getKey() ).equals(this.date))
                 {
                     at = true;
                     
                     if(!c.get_le().getMapDesSuperviseurs().get((String) mapentry.getKey()).isEmpty())
                     {
                         System.out.println((String) mapentry.getKey());
                         //System.out.println(c.get_le().getMapDesSuperviseurs().get((String) mapentry.getKey()).get(0).getNom());
                         //On récupere la liste des superviseurs
                         ArrayList<Superviseur> it2 = c.get_le().getMapDesSuperviseurs().get((String) mapentry.getKey());
                         int a = 0;
                         while(a<it2.size())
                         {
                             //System.out.println("it2 : " +it2);
                             //On parcourt tous les EDT de ce superviseur
                             int b = 0;
                             boolean at2 = false;
                             while(b<it2.get(a).getEdt().size() && !at2)
                             {
                                 //System.out.println("it3 : "+it2.get(a).getEdt().get(b).afficher_EDT());
                                 DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
                                 String dateAsString = df.format(it2.get(a).getEdt().get(b).getDate());
                                 
                                 String[] tab = this.date.split(" - ");
                                 //si c'est la bonne date d'edt alors on met l'edt dans les datas
                                 if(tab[0].equals(dateAsString))
                                 {
                                     if(!data2.contains(it2.get(a).getEdt().get(b)))
                                        data2.add(it2.get(a).getEdt().get(b));
                                     
                                     at2 = true;
                                 }
                                 b++;
                             }
                             
                             a++;
                             
                         }// fin it2
                         
                     }// fin verif si la liste est vide
                     
                 }// fin de la verif si c'est la meme date
                 
         
        }
        
        //CREATION DES TABLES VIEW           
        TableView<EDTSuperv> tableView = new TableView<>(data2);
        tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        tableView.setStyle("-fx-background-color: blue;");
        tableView.setEditable(true);
                     
       
        //TableColumn<EDTSuperv, String> base = new TableColumn<>("Liste des Emploi du temps");
    
        
        TableColumn<EDTSuperv, String> Superviseur = new TableColumn<>("Superviseur");
        TableColumn<EDTSuperv, String> SuperviseurN = new TableColumn<>("Nom");
        TableColumn<EDTSuperv, String> SuperviseurP = new TableColumn<>("Prenom");
        
        TableColumn<EDTSuperv, String> Activité = new TableColumn<>("Activité");
        //TableColumn<EDTSuperv, String> Activité = new TableColumn<>("Activité");
        
        
    
        
        TableColumn<EDTSuperv, HBox> EDT = new TableColumn<>("Emploi du temps");
        //EDT.setStyle("-fx-alignment: LEFT;" + "-fx-text-align: left;");
        EDT.setStyle( "-fx-alignment: LEFT;");
        

        TableColumn<EDTSuperv, HBox> seph = new TableColumn<>("07h-07h30");
        TableColumn<EDTSuperv, HBox> seph30 = new TableColumn<>("07h30-08h");
        TableColumn<EDTSuperv, HBox> hh = new TableColumn<>("08h-08h30");
        TableColumn<EDTSuperv, HBox> hh30 = new TableColumn<>("08h30-09h");
        TableColumn<EDTSuperv, HBox> nh = new TableColumn<>("09h-09h30");
        TableColumn<EDTSuperv, HBox> nh30 = new TableColumn<>("09h30-10h");
        TableColumn<EDTSuperv, HBox> dh = new TableColumn<>("10h-10h30");
        TableColumn<EDTSuperv, HBox> dh30 = new TableColumn<>("10h30-11h");
        TableColumn<EDTSuperv, HBox> oh = new TableColumn<>("11h-11h30");
        TableColumn<EDTSuperv, HBox> oh30 = new TableColumn<>("11h30-12h");
        TableColumn<EDTSuperv, HBox> doh = new TableColumn<>("12h-12h30");
        TableColumn<EDTSuperv, HBox> doh30 = new TableColumn<>("12h30-13h");
        TableColumn<EDTSuperv, HBox> th = new TableColumn<>("13h-13h30");
        TableColumn<EDTSuperv, HBox> th30 = new TableColumn<>("13h30-14h");
        TableColumn<EDTSuperv, HBox> quatoh = new TableColumn<>("14h-14h30");
        TableColumn<EDTSuperv, HBox> quatoh30 = new TableColumn<>("14h30-15h");
        TableColumn<EDTSuperv, HBox> quinh = new TableColumn<>("15h-15h30");
        TableColumn<EDTSuperv, HBox> quinh30 = new TableColumn<>("15h30-16h");
        TableColumn<EDTSuperv, HBox> seih = new TableColumn<>("16h-16h30");
        TableColumn<EDTSuperv, HBox> seih30 = new TableColumn<>("16h30-17h");
        TableColumn<EDTSuperv, HBox> dixsh = new TableColumn<>("17h-17h30");
        TableColumn<EDTSuperv, HBox> dixsh30 = new TableColumn<>("17h30-18h");
        TableColumn<EDTSuperv, HBox> dixhh = new TableColumn<>("18h-18h30");
        TableColumn<EDTSuperv, HBox> dixhh30 = new TableColumn<>("18h30-19h");
        TableColumn<EDTSuperv, HBox> dixnh = new TableColumn<>("19h-19h30");
        TableColumn<EDTSuperv, HBox> dixnh30 = new TableColumn<>("19h30-20h");

        
        
      
        
          
        
        //PARTIE AFFICHAGE DE DONNEE
        
        
        SuperviseurN.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<EDTSuperv, String> column){
                return column.getValue().getS().getVNom();
            }
 
        });
        
         SuperviseurP.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<EDTSuperv, String> column){
                return new SimpleStringProperty(column.getValue().getS().getPrenom());
            }
 
        });
        
        
        Activité.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<EDTSuperv, String> column){
                return column.getValue().getVNomActivité();
            }
 
        });
        
        
        
       
        
        seph.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(7f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        seph30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(7.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        hh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(8f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        hh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(8.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        nh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(9f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        nh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(9.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        dh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(10f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        dh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(10.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
        oh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(11f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
        
         oh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(11.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
         
          doh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(12f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
          
           doh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(12.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
           
            th.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(13f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
            
             th30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(13.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
             
             quatoh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(14f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
             
              quatoh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(14.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
              
               quinh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(15f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
               
                quinh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(15.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                
                 seih.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(16f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                 
                  seih30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(16.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                  
                   dixsh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(17f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                   
                    dixsh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(17.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                    
                     dixhh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(18f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                     
                      dixhh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(18.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                      
                       dixnh.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(19f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
                       
                        dixnh30.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EDTSuperv, HBox>, ObservableValue<HBox>>() {
            @Override
            public ObservableValue<HBox> call(TableColumn.CellDataFeatures<EDTSuperv, HBox> column){
                HBox h = new HBox();
                h.setAlignment(Pos.CENTER);
                if(!(column.getValue().getMap().get(19.5f) == 0))
                {

                    Text t = new Text("1");
                    t.setFill(Color.WHITE);
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                    
                }
                else{

                    Text t = new Text("0");
                    t.setFill(Color.WHITE);
                    t.setStyle("-fx-alignment: center ;");
                    h.getChildren().addAll(t);
                    h.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                return new SimpleObjectProperty<>(h);
            }
 
        });
          
        String[] tab = this.date.split(" - ");
        if(tab[1].equals("7.0"))
        {
             EDT.getColumns().addAll(seph, seph30);
        }else if(tab[1].equals("8.0"))
        {
           EDT.getColumns().addAll(hh, hh30, nh, nh30, dh, dh30, oh, oh30, doh);
        }else if(tab[1].equals("12.5"))
        {
           EDT.getColumns().addAll(doh30, th, th30,quatoh, quatoh30, quinh);
        }else if(tab[1].equals("15.5"))
        {
            EDT.getColumns().addAll( quinh30, seih, seih30, dixsh );
        }else if(tab[1].equals("17.5"))
        {
            EDT.getColumns().addAll(dixsh30, dixhh);
        }else if(tab[1].equals("18.5"))
        {
            EDT.getColumns().addAll(dixhh30, dixnh, dixnh30);
        }
        
       /* EDT.getColumns().addAll(seph, seph30, hh, hh30, nh, nh30, dh, dh30, oh, oh30, doh, doh30, th, th30,
                                    quatoh, quatoh30, quinh, quinh30, seih, seih30, dixsh, dixsh30, dixhh, dixhh30,
                                    dixnh, dixnh30);
        
                                    */
        EDT.setStyle("fx-text-alignment: left;");
      
        Superviseur.getColumns().addAll(SuperviseurN, SuperviseurP);
        
        tableView.getColumns().addAll(Superviseur, Activité, EDT);
        tableView.setPrefHeight(height/2);
        tableView.setPrefWidth(width);

        
        ScrollPane sp = new ScrollPane();
        sp.setStyle("-fx-font-size: 14px;");
        sp.setContent(tableView);
        sp.setHbarPolicy(ScrollBarPolicy.ALWAYS);
   
        
        StackPane root = new StackPane();
        root.setStyle("-fx-background-color: orange");
        root.getChildren().addAll(sp, tableView);
        //root.setMargin(tableView, new Insets(10, 10, 10, 10));


        Scene scene = new Scene(root, Color.DARKORANGE);
        
        
                         
         //Paramètres de la Page
          primaryStage.setTitle("Ceux qui sont disponible le :  "+this.date);
          primaryStage.setScene(scene);
          primaryStage.show();
          primaryStage.setResizable(false);
         
        
    }
    
    
}
