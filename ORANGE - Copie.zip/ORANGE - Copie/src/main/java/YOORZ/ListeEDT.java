/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Collections;
/**
 *
 * @author HugoBarboule
 */
public class ListeEDT {
    private ArrayList<EDTSuperv> list;
    private Cloud c;
    private ArrayList<Boolean> verif = new ArrayList<Boolean>();
    private ArrayList<Date> listJours = new ArrayList<Date>();


    public ListeEDT() {
        this.list = new ArrayList<EDTSuperv>();
    }
    
    public void init_c(Cloud c)
    {
        this.c = c;
    }
    
    public String LectureList()
    {
        String texte ="";
        for(int i =0; i<list.size(); i++)
        {
            texte += list.get(i).getActivite() + " " +list.get(i).getS().getPrenom() +"\n";
        }
        return texte;
    }
    
    
    public void attribuer_edt(Superviseur s)
    {
        ArrayList<EDTSuperv> list2 = new ArrayList<EDTSuperv>();
        //System.out.println(s.getNom() + " " + s.getPrenom());
        for(int i = 0; i<this.list.size(); i++)
        {
            if(this.list.get(i).getS().getNom().toUpperCase().equals(s.getNom().toUpperCase()))
            {
                  list2.add(this.list.get(i));
            }
        }

        /*if(!list2.equals(s.getEdt()))
        {
             s.MixerLesEDT();
        }*/
     
        if(!list2.equals(s.getEdt()))
        {
            s.Set_EDT(list2);
            if(!s.trouver_tableaux_edt_doublons().isEmpty())
            {
                //s.correler_doublons(s.trouver_tableaux_edt_doublons());
                s.correler_doublons_BIS(s.trouver_tableaux_edt_doublons());
            }
        }
        
        /*
        //On supprime les doublons qui persistent    A VERIFIER QUE CA MARCHE BIEN EN HAUT
        for(int i  = 0; i<s.getEdt().size(); i++)
        {
            Date d = s.getEdt().get(i).getDate();
            for(int ii = i; ii<s.getEdt().size(); ii++)
            {
                if(s.getEdt().get(ii).getDate().equals(d))
                {
                    HashMap<Float, Integer> map = s.MixHashMap2(s.getEdt().get(i).getMap(), s.getEdt().get(ii).getMap());
                    int p1 = s.getEdt().get(i).getActivite().getPoids();
                    int p2 = s.getEdt().get(ii).getActivite().getPoids();
                    if(p1<p2)
                    {
                        s.getEdt().get(i).setMap(map);
                        s.getEdt().remove(ii);
                    }else{
                         s.getEdt().get(ii).setMap(map);
                         s.getEdt().remove(i);
                    }
                    
                } // fin condition meme date
            }// fin seconde boucle
            
        } // fin de la boucle
        */

    }// fin methode
    
      //Méthode permettant de trier par ordre numérique, les clés de la HashMap
    public static HashMap<Float, Integer> trierHashMap3(Map<Float, Integer> hmap){
        List<Map.Entry<Float, Integer>> list =
           new LinkedList<Map.Entry<Float, Integer>>( hmap.entrySet() );
        Collections.sort( list, new Comparator<Map.Entry<Float, Integer>>(){
           public int compare
           (Map.Entry<Float, Integer>o1, Map.Entry<Float, Integer> o2 )
           {
              //comparer deux clés
              return (o1.getKey()).compareTo( o2.getKey() );
           }
        });
        
        //créer une nouvelle HashMap à partir de LinkedList
        HashMap<Float, Integer> hmapTriee = new LinkedHashMap<Float, Integer>();
        for (Map.Entry<Float, Integer> entry : list)
        {
            hmapTriee.put( entry.getKey(), entry.getValue() );
        }
        return hmapTriee;
    }
    
    public ArrayList<EDTSuperv> get_list(){
        return this.list;
    }
    
    
         
    public void init_EDT()
    {
        Superviseur s;
        Date date;
        Activités activité;
        HashMap<Float, Integer> map;
        ArrayList<HashMap<Float, Integer>> l;
        int numéro = 0;
        //StringBuilder str = new StringBuilder();
        try{
                                
            //On récupère le CSV dans les dossiers.

            this.list.clear();
            InputStream input = getClass().getResource("/données/JOURNEES_SUPERVISEURS_TEST.txt").openStream(); 
            Scanner scan = new Scanner(input, "ISO-8859-1");

            
            
            int i = 0;
            String ligne = "";
            //Tant qu'il y a une ligne d'écrite sur le fichier 
            while(scan.hasNextLine())
            {
                numéro++;
                ligne = scan.nextLine();
                // Dans la variable txt il y a une ligne entière du fichier .txt
                    String txt = ligne;
                    i++;

                    /*Pour récupérer les bonnes informations, on découpe chaque 
                    ligne du csv en fonction du découpage (en point virgules) du fichier*/
                    String[] v= txt.split(";");
                    
                    try{
                        int test;
                        String[] preNom = v[0].split(" ");
                        if(preNom.length == 1)
                        {
                            s = c.get_ls().Search_Superviseur(v[0].toUpperCase());
                            if(s != null)
                                test = 1;
                            else
                                test = 0;
                        }
                        else if(preNom.length == 2)
                        {
                            s = c.get_ls().Search_Superviseur(preNom[1].toUpperCase());
                            if(s != null)
                            {
                                 test = 1; 
                            }else{
                                 test = 0; 
                            }

                        }
                        else if(preNom.length > 2)
                        {
                            
                            s = c.get_ls().Search_Superviseur(preNom[preNom.length-1].toUpperCase());
                            if(s != null)
                            {
                                 test = 1; 
                            }else{
                                test = 0; 
                            }
                        }
                        else{
                            s = null;
                            test = 0;
                        }

                        switch(test){
                            case 0:
                                break;
                            case 1:
                                
                                date = new SimpleDateFormat("dd/MM/yyyy").parse(v[3]);
                                if(!this.listJours.contains(date))
                                {
                                    this.listJours.add(date);
                                }
                                
                                if((activité = c.get_la().Search_Activité(v[1])) == null){
                                    
                                    if((activité = c.get_la().Search_Absence(v[1])) != null){
                                        
                                        
                                        
                                        activité = c.get_la().Search_Absence(v[1]);
                                        
                                        l = activité.init_HorairesParAbsenceBIS(v[4]);

                                        
                                        String dt = v[3];
                                        Calendar c = Calendar.getInstance();
                                        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy"); 
                                        
                                        int nbJour;
                                        if(v[5].chars().allMatch( Character::isDigit ))
                                        {
                                            if(l.size() == 1)
                                            {
                                                if(Integer.parseInt(v[5]) <= 30 && Integer.parseInt(v[5])>0)
                                                {
                                                    nbJour = Integer.parseInt(v[5]);
                                                    for(int a = 0; a<=nbJour; a++)
                                                    {
                                                        EDTSuperv edt = new EDTSuperv(s, date, activité);
                                                        edt.setNom(v[4]);
                                                        edt.setNuméro(numéro);
                                                        
                                                        
                                                        if(a > 0 && a < nbJour)
                                                        {
                                                            HashMap<Float, Integer> maptest = new HashMap<Float, Integer>();
                                                            for(float b = 0f; b<=24f; b+=0.5f)
                                                            {
                                                                maptest.put(b, 0);
                                                            }
                                                            edt.setMap(maptest);  
                                                            edt.setNom(v[4]);
                                                            this.list.add(edt);
                                                             
                                                            this.listJours.add(date);
                                                            c.setTime(sdf.parse(dt));
                                                            c.add(Calendar.DATE, 1);  // number of days to add
                                                            dt = sdf.format(c.getTime());  // dt is now the new date
                                                            date = new SimpleDateFormat("dd/MM/yyyy").parse(dt);


                                                        }else{
                                                            float debtest = 0f;
                                                            HashMap<Float, Integer> maptest = new HashMap<Float, Integer>();
                                                            maptest = l.get(0);
                                                            
                                                            // si c'est le premier à ajouter
                                                            if(a == 0)
                                                            {
                                                                HashMap<Float, Integer> map1 = new HashMap<Float, Integer>();
                                                                boolean atrouve = false;
                                                                float b = 0f;
                                                                debtest = 0f;
                                                                while(!atrouve && b<=24f)
                                                                {
                                                                    if(maptest.get(b) == 0)
                                                                    {
                                                                        debtest = b;
                                                                        atrouve = true;

                                                                    }else{

                                                                        b+= 0.5f;
                                                                    }
                                                                }
                                                               
                                                                for(float bb = 0f; bb<=24f; bb+=0.5f)
                                                                {
                                                                    map1.put(bb, 1);
                                                                }
                                                                map1 = trierHashMap3(map1); 
                                                               
                                                                
                                                                //on crée une nouvelle map avec les memes valeurs mais pas égales pour ne pas
                                                                // changer les valeurs de l.get(0)
                                                                for(float bb = 0f; bb<=24f; bb+=0.5f)
                                                                {
                                                                    map1.replace(bb, maptest.get(bb));
                                                                }
                                                                for(float bb = debtest; bb<=24f; bb+=0.5f)
                                                                {
                                                                    map1.replace(bb, 0);
                                                                }
                                                                
                                                                //Je mets des 0 partout du debut jusqu'à 24h 
                                                                edt.setMap(map1);
                                                                edt.setNom(v[4]);
                                                                 this.list.add(edt);
                                                                
                                                                
                                                                this.listJours.add(date);
                                                                c.setTime(sdf.parse(dt));
                                                                c.add(Calendar.DATE, 1);  // number of days to add
                                                                dt = sdf.format(c.getTime());  // dt is now the new date
                                                                date = new SimpleDateFormat("dd/MM/yyyy").parse(dt);
                                                                

                                                            }
                                                            if(a==nbJour){ // SI C'est le dernier à ajouter
                                                                HashMap<Float, Integer> map1 = new HashMap<Float, Integer>();
                                                                float fintest = 0f;
                                                                boolean atrouve = false;
                                                                float b = 0.5f;
                                                                while(!atrouve && b<=24f)
                                                                {
                                                                    if(l.get(0).get(b) == 1 && l.get(0).get(b-0.5f) == 0)
                                                                    {
                                                                        fintest = b;
                                                                        atrouve = true;
                                                                    }else{

                                                                        b+= 0.5f;
                                                                    }
                                                                }
                                                                for(float bb = 0; bb<fintest; bb+=0.5f)
                                                                {
                                                                    map1.put(bb, 0);
                                                                }
                                                                for(float bb = fintest; bb<=24f; bb+=0.5f)
                                                                {
                                                                    map1.put(bb, 1);
                                                                }
                                                                map1 = trierHashMap3(map1);
                                                                edt.setMap(map1);
                                                                edt.setNom(v[4]);
                                                                this.list.add(edt);

                                                                this.listJours.add(date);
                                                                c.setTime(sdf.parse(dt));
                                                                c.add(Calendar.DATE, 1);  // number of days to add
                                                                dt = sdf.format(c.getTime());  // dt is now the new date
                                                                date = new SimpleDateFormat("dd/MM/yyyy").parse(dt);
                                                                
                                                            } // fin cas si c'est le dernier à ajouter

                                                        }// fin cas si c'est le premier ou le dernier à ajouter
                                                        
                                                        
                                                        
                                                    }// fin de la boucle
                                                }//fin condition du v[5] entre 30 et 1 
                                                else{
                                                    
                                                     EDTSuperv edt = new EDTSuperv(s, date, activité);
                                                      edt.setNom(v[4]);
                                                      edt.setMap(l.get(0));
                                                      edt.setNuméro(numéro);
                                                       this.list.add(edt);

                                                } // fin cas si v[5]+1 == 1
                                                
                                        
                                               
                                            }
                                            else{
                                                //CAS SI C'EST DE NUIT
                                                
                                                if(Integer.parseInt(v[5]) <= 30)
                                                {
                                                    nbJour = Integer.parseInt(v[5]);
                                                    for(int a = 0; a<=nbJour; a++)
                                                    {
                                                        EDTSuperv edt = new EDTSuperv(s, date, activité);
                                                        edt.setMap(l.get(a));
                                                        edt.setNom(v[4]);
                                                        edt.setNuméro(numéro);


                                                        if(!this.list.contains(edt))
                                                        {
                                                            this.list.add(edt);
                                                            this.listJours.add(date);


                                                            c.setTime(sdf.parse(dt));
                                                            c.add(Calendar.DATE, 1);  // number of days to add
                                                            dt = sdf.format(c.getTime());  // dt is now the new date
                                                            date = new SimpleDateFormat("dd/MM/yyyy").parse(dt);



                                                        }// fin si la liste contient pas l'edt
                                                        else{

                                                            int numSemaine = c.get(Calendar.WEEK_OF_YEAR);
                                                            int numJour = c.get(Calendar.DAY_OF_WEEK);
                                                            //this.ListeDesJours.add(new Jour(numJour, numSemaine, date));
                                                            this.listJours.add(date);


                                                            c.setTime(sdf.parse(dt));
                                                            c.add(Calendar.DATE, 1);  // number of days to add
                                                            dt = sdf.format(c.getTime());  // dt is now the new date
                                                            date = new SimpleDateFormat("dd/MM/yyyy").parse(dt);


                                                            if(a>=1 && a<=nbJour-1)
                                                            {
                                                                HashMap<Float, Integer> m = new HashMap<Float, Integer>();
                                                                m = MixHashMap(l.get(a), l.get(a+1));
                                                                edt.setMap(m);
                                                                edt.setNom(v[4]);
                                                                //this.list.get(this.list.size()-1).setMap(m);
                                                            }
                                                            this.list.add(edt);
                                                        }//fin du else

                                                    }//fin de la boucle   
                                                }// fin cas si c'est inférieur à 30 jours 
                                                
                                        
                                                
                                                
                                            }// FIN DU CAS D'UNE ABSENCE DE NUIT
                                                
                                        }// FIN VERIF SI QUE DES CHIFFRES EN V[5]
    
                                    } // FIN CAS SI C'EST UNE ABSENCE
                                   
                                } // FIN CAS SI L'ACTIVITE EST NULLE
                                
                                else{

                                    // Cas si c'est une activité
                                
                                        activité = c.get_la().Search_Activité(v[1]);
                                        l = activité.init_HorairesParActivitéBIS(v[4]);
                                       

                                        
                                        String dt=v[3];
                                        Calendar c = Calendar.getInstance();
                                        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy"); 
                                        
                                        int nbJour;
                                        if(v[5].chars().allMatch( Character::isDigit ))
                                        {
                                           if(l.size() == 1)
                                            {
                                                if(Integer.parseInt(v[5]) <= 30)
                                                {
                                                    nbJour = Integer.parseInt(v[5]);
                                                    for(int a = 0; a<=nbJour; a++)
                                                    {
                                                        EDTSuperv edt = new EDTSuperv(s, date, activité);
                                                        edt.setMap(l.get(0));
                                                        edt.setNom(v[4]);
                                                        edt.setNuméro(numéro);
                                                 
                                                      
                                                            
                                                            this.list.add(edt);
                                                        

                                                            this.listJours.add(c.getTime());
                                                        c.setTime(sdf.parse(dt));
                                                        c.add(Calendar.DATE, 1);  // number of days to add
                                                        dt = sdf.format(c.getTime());  // dt is now the new date
                                                        date = new SimpleDateFormat("dd/MM/yyyy").parse(dt);


                                                    }
                                                }// fin condition du nomrbre en v[5]
                                                
                                        
                                                
                                                   
                                            } // FIN CAS SI PAS DE SOIR POUR UNE ACTIVITE
                                            else{
                                                
                                                if(Integer.parseInt(v[5]) <= 30)
                                                {
                                                    nbJour = Integer.parseInt(v[5]);
                                                    for(int a = 0; a<=nbJour; a++)
                                                    {

                                                        EDTSuperv edt = new EDTSuperv(s, date, activité);
                                                        edt.setMap(l.get(a));
                                                        edt.setNom(v[4]);
                                                        edt.setNuméro(numéro);
   
                                                       
                                                        

                                                        if(!this.list.contains(edt))
                                                        {
                                                            this.list.add(edt);
                                                        }
                                                        

                                                           
                                                            this.listJours.add(date);

                                                            c.setTime(sdf.parse(dt));
                                                            c.add(Calendar.DATE, 1);  // number of days to add
                                                            dt = sdf.format(c.getTime());  // dt is now the new date
                                                            date = new SimpleDateFormat("dd/MM/yyyy").parse(dt);


                                                            if(a>=1 && a<=nbJour-1)
                                                            {
                                                                HashMap<Float, Integer> m = new HashMap<Float, Integer>();
                                                                m = MixHashMap(l.get(a), l.get(a+1));
                                                                this.list.get(this.list.size()-1).setMap(m);
                                                            }

                                                    } // fin de la boucle pour les mixages  
                                                }// fin de la condition du nombre de jour pour une activité 
                                               
                                        
                                                 
                                           }// FIN DE CAS ACTIVITE DANS LA NUIT
                                        }// FIN VERIF SI QUE DES CHIFFRES DANS v[5]
                                } // FIN CAS SI L'ACTIVTE N'EST PAS NULLE
                                
                                
                                break;
                        }
                        
                    }catch(Exception e)
                    {
                         e.printStackTrace();      
                    }
                      
                  }

            input.close();
            
            //Permet de ranger les EDT en focntion des dates dans l'ordre croissant
            Collections.sort(this.list, new Comparator<EDTSuperv>()
            {
                @Override
                public int compare(EDTSuperv e1, EDTSuperv e2)
                {
                    return e1.getDate().compareTo(e2.getDate());
                }
            });
            
         }

                    
        
        catch(Exception e){
            System.out.println("Une erreur est survenue lors de la lecture du bon CSV");
            e.printStackTrace();
        }
    }
    
    public void tout_attribuer()
    {
        for(int i = 0; i<c.get_ls().get_list().size(); i++)
        {
           this.verif.add(false);
           c.get_le().attribuer_edt(c.get_ls().get_list().get(i));
           //c.get_ls().get_list().get(i).AfficherTousLesEDT();
        }
        this.verif.add(true);
    }
    
    public ArrayList<Boolean> get_verif()
    {
        return this.verif;
    }
    
    /*
    Permet de mixer les map quand quelqu'un travaille de nuit
    */
    public HashMap<Float, Integer> MixHashMap(HashMap<Float, Integer> map1, HashMap<Float, Integer> map2)
    {
        HashMap<Float, Integer> MapFinale = new HashMap<Float, Integer>();
        for(float i = 0f; i<=24f; i = i+0.5f)
        {
            MapFinale.put(i,map1.get(i)*map2.get(i));
        }
        return MapFinale;
    }
    

    private HashMap<Date, HashMap<String, Integer>> MapNbParJour = new HashMap<Date, HashMap<String, Integer>>();
    private HashMap<Date , ArrayList<EDTSuperv>> MapListEDTParJour = new HashMap<Date , ArrayList<EDTSuperv>>();
    private HashMap<Date , ArrayList<EDTSuperv>> MapListEDTParJourVRAIE = new HashMap<Date , ArrayList<EDTSuperv>>();
    private HashMap<Date, Integer> mapJour = new HashMap<Date, Integer>();
    private HashMap<Date, Integer> mapSemaine = new HashMap<Date, Integer>();
    
    
    private ArrayList<Jour> ListeDesJours = new ArrayList<Jour>();
    private HashMap<Integer, ArrayList<Jour>> ListeDesJoursRassemblésSemaine = new HashMap<Integer, ArrayList<Jour>>();

    public ArrayList<Jour> getListeDesJours() {
        return ListeDesJours;
    }

    public HashMap<Date, ArrayList<EDTSuperv>> getMapListEDTParJourVRAIE() {
        return MapListEDTParJourVRAIE;
    }
    
    private HashMap<Integer, HashMap<Integer, HashMap<Integer, ArrayList<EDTSuperv>>>> MapMois = new HashMap<Integer, HashMap<Integer, HashMap<Integer, ArrayList<EDTSuperv>>>>();
    
    public void init_MapListEDT()
    {
            for(int i = 0; i<this.listJours.size(); i++)
            {
                this.MapListEDTParJour.put(this.listJours.get(i), null);
                this.MapNbParJour.put(this.listJours.get(i), null);
            }
            
            
            Date dRef = this.list.get(0).getDate();
           
            
            
            ArrayList<EDTSuperv> l = new ArrayList<EDTSuperv>();
            for(int i = 0; i<this.list.size(); i++)
            {
                
                if(!dRef.equals(this.list.get(i).getDate()))
                {
                    dRef = this.list.get(i).getDate();
                    l = new ArrayList<EDTSuperv>();
                    l.add(this.list.get(i));
                    this.MapListEDTParJour.replace(dRef, l);
                    this.MapListEDTParJourVRAIE.put(dRef, l);
                    
                }else{
                    
                     l.add(this.list.get(i));
                     this.MapListEDTParJour.replace(dRef, l);
 
                }
            }
           
                       
            
            Calendar calendar = Calendar.getInstance();
            int nmJour;
            int nmSemaine;
            Iterator i3 = this.MapListEDTParJour.entrySet().iterator();
            
            while(i3.hasNext())
            {
                Map.Entry mapentry = (Map.Entry) i3.next();
                Date d = (Date) mapentry.getKey();
                calendar.setTime(d);
                nmJour = calendar.get(Calendar.DAY_OF_WEEK)-1;
                nmSemaine = calendar.get(Calendar.WEEK_OF_YEAR); 
                if((ArrayList<EDTSuperv>) mapentry.getValue() != null)
                { 
                    this.mapJour.put(d, nmJour);
                    this.mapSemaine.put(d, nmSemaine);
                }
            }
            
            
            Iterator i = this.mapJour.entrySet().iterator();
            int a = 0;
            while(i.hasNext())
            {
                Map.Entry mapentry = (Map.Entry) i.next();
                Iterator i2 = this.mapSemaine.entrySet().iterator();
                boolean aTrouvé = false;
                while(i2.hasNext() && !aTrouvé)
                {
                    
                    Map.Entry mapentry2 = (Map.Entry) i2.next();
                    aTrouvé = ((Date) mapentry2.getKey()).equals((Date) mapentry.getKey());
                    
                    if(aTrouvé)
                    {
                        Jour j = new Jour( (int) mapentry.getValue(), (int) mapentry2.getValue(), (Date) mapentry2.getKey() );
                        j.init_MonthYear();
                        if(!this.ListeDesJours.contains(j))
                        {
                           this.ListeDesJours.add(j); 
                        }
                        a++;
                    }

                }// fin du second while
                
            } // fin du premier
            
            this.MapListEDTParJour = trierHashMap2(this.MapListEDTParJour);
            this.MapListEDTParJourVRAIE = trierHashMap2(this.MapListEDTParJourVRAIE);

             
    }
    
    private HashMap<String, ArrayList<Superviseur>> MapDesSuperviseurs = new HashMap<String, ArrayList<Superviseur>>();
    
    public int CombienParTranchesHoraires(Date d, float deb, int duree)
    {
        ArrayList<Superviseur> listSuperviseur = new ArrayList<Superviseur>();
        double pourcentage = 0.8;
        int compteurPersonne = 0;
        int compteur = 0;
        boolean Atrouvé = false;
        Iterator i = this.MapListEDTParJourVRAIE.entrySet().iterator();
        int stotal=0;
        while(i.hasNext() && !Atrouvé)
        {
            Map.Entry mapentry = (Map.Entry) i.next();
            Atrouvé = d.equals(mapentry.getKey());
            
            if(!(this.MapListEDTParJourVRAIE.get((Date)mapentry.getKey()).isEmpty()))
            {
                if(Atrouvé)
                {
                    //int debu = (int) deb;
                    int compteurcase = 0;
                    for(int a = 0; a<this.MapListEDTParJourVRAIE.get( (Date) mapentry.getKey()).size(); a++)
                    { 
                        compteur = 0;
                        for(float b = deb; b<deb + (float)(duree/2); b+=0.5f)
                        {
                            if(a==0)
                            {
                                //System.out.println("compteur case : "+ compteurcase);
                                compteurcase++;
                            }
                            
                            if(this.MapListEDTParJourVRAIE.get( (Date) mapentry.getKey() ).get(a).getMap().get(b) == 1 
                                    /*&& c.get_ls().get_list().contains(this.MapListEDTParJourVRAIE.get( 
                                            (Date) mapentry.getKey()).get(a).getS())*/)
                            {
                                //System.out.println(this.MapListEDTParJourVRAIE.get( (Date) mapentry.getKey() ).get(a).afficher_EDT());
                                compteur ++;

                            }// fin du if
                            
                        }//fin du for

                        if(compteur > pourcentage*compteurcase)
                        {
                            compteurPersonne++;
                            
                            listSuperviseur.add(this.MapListEDTParJourVRAIE.get( (Date) mapentry.getKey()).get(a).getS());
                            Superviseur s = this.MapListEDTParJourVRAIE.get( (Date) mapentry.getKey()).get(a).getS();
                            //System.out.println(s.getNom() + " " + s.getPrenom() + " compteur : "+ compteur + " sur : (compteurcase) "+ compteurcase);
                            // la clé est la date + le debut
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            Calendar ca = Calendar.getInstance();
                            ca.setTime((Date) mapentry.getKey());
                            String dayofweek="";
                            int numsemaine = ca.get(Calendar.WEEK_OF_YEAR);
                switch(ca.get(Calendar.DAY_OF_WEEK)-2)
                {
                    case 0:
                        dayofweek = "LUNDI";
                    break;
                    case 1:
                        dayofweek = "MARDI";
                    break;
                    case 2:
                        dayofweek = "MERCREDI";
                    break;
                    case 3:
                        dayofweek = "JEUDI";
                    break;
                    case 4:
                        dayofweek = "VENDREDI";
                    break;
                    case 5:
                        dayofweek = "SAMEDI";
                    break;
                    default:
                        dayofweek="DIMANCHE";
                    break;
                }
                          
                            String clé = numsemaine + " "+dayofweek +" - "+ deb;
                            if(!this.MapDesSuperviseurs.containsKey(clé))
                            {
                                this.MapDesSuperviseurs.put(clé, listSuperviseur);
                                
                            }else
                            {
                                Iterator x = this.MapDesSuperviseurs.entrySet().iterator();
                                boolean find = false;
                                while(x.hasNext() && !find)
                                {
                                    Map.Entry mapentry2 = (Map.Entry) x.next();
                                    find = ((String) mapentry2.getKey()).equals(clé);
                                    if(find)
                                    {
                                        ( (ArrayList<Superviseur>) mapentry2.getValue() ).add(this.MapListEDTParJourVRAIE.get( (Date) mapentry.getKey() ).get(a).getS());
                                    }
                                   
                                }//fin du fait de parcourir toutes les dates et deb                
                            }
                               
                            
                           
                        }// fin de la verif si le complteur est supérieur
                        
                    }// fin de la boucle principale
                    
                    
                }//fin s'il a trouvé
                
                
                

                
            }// fin de s'il existe
        }// fin de l'itération
        
        //System.out.print(d);
        //System.out.print(" ->  "+compteurPersonne);
          //      System.out.print(" sur "+stotal);
            //    System.out.print("     =    "+((double) compteurPersonne/(double) stotal)+"\n");
        return compteurPersonne;
        
        
    }// Fin de la méthode

    public HashMap<String, ArrayList<Superviseur>> getMapDesSuperviseurs() {
        return MapDesSuperviseurs;
    }
    
    //Méthode permettant de trier par ordre numérique, les clés de la HashMap
    public static HashMap<String, Integer> trierHashMap(Map<String, Integer> hmap){
        List<Map.Entry<String, Integer>> list =
           new LinkedList<Map.Entry<String, Integer>>( hmap.entrySet() );
        Collections.sort( list, new Comparator<Map.Entry<String, Integer>>(){
           public int compare
           (Map.Entry<String, Integer>o1, Map.Entry<String, Integer> o2 )
           {
              //comparer deux clés
              return (o1.getKey()).compareTo( o2.getKey() );
           }
        });
        
        //créer une nouvelle HashMap à partir de LinkedList
        HashMap<String, Integer> hmapTriee = new LinkedHashMap<String, Integer>();
        for (Map.Entry<String, Integer> entry : list)
        {
            hmapTriee.put( entry.getKey(), entry.getValue() );
        }
        return hmapTriee;
    }
    
    //Méthode permettant de trier par ordre numérique, les clés de la HashMap
    public static HashMap<Date, ArrayList<EDTSuperv>> trierHashMap2(Map<Date, ArrayList<EDTSuperv>> hmap){
        List<Map.Entry<Date, ArrayList<EDTSuperv>>> list =
           new LinkedList<Map.Entry<Date, ArrayList<EDTSuperv>>>( hmap.entrySet() );
        Collections.sort( list, new Comparator<Map.Entry<Date, ArrayList<EDTSuperv>>>(){
           public int compare
           (Map.Entry<Date, ArrayList<EDTSuperv>>o1, Map.Entry<Date, ArrayList<EDTSuperv>> o2 )
           {
              //comparer deux clés
              return (o1.getKey()).compareTo( o2.getKey() );
           }
        });
        
        //créer une nouvelle HashMap à partir de LinkedList
        HashMap<Date, ArrayList<EDTSuperv>> hmapTriee = new LinkedHashMap<Date, ArrayList<EDTSuperv>>();
        for (Map.Entry<Date, ArrayList<EDTSuperv>> entry : list)
        {
            hmapTriee.put( entry.getKey(), entry.getValue() );
        }
        return hmapTriee;
    }
    
  private HashMap<Integer, HashMap<Integer, ArrayList<Jour>>> MapJourParMoisSemaine = new HashMap<Integer, HashMap<Integer, ArrayList<Jour>>>();
  
    public void init_MapListNbDispo()
    {
        String t1 = "07h-8h";  // 7h à 8h
        String t2= "08h-12h30"; // 8h à 12h30
        String t3= "12h30-15h30";  // 12h30 à 15h30
        String t4="15h30-17h30"; // 15h30 à 17h30
        String t5= "17h30-18h30"; // 17h30 à 18h30
        String t6= "18h30-20h30"; // 18h30 à 20h
        this.init_MapListEDT();
         
        Iterator i = this.MapListEDTParJourVRAIE.entrySet().iterator();
        while(i.hasNext())
        {
            
            HashMap<String, Integer> list = new HashMap<String, Integer>();
            Map.Entry mapentry = (Map.Entry) i.next();
            int c1, c2, c3, c4, c5, c6 = 0;
            c1 = this.CombienParTranchesHoraires((Date) mapentry.getKey(), 7f, 3);
            c2 = this.CombienParTranchesHoraires((Date) mapentry.getKey(), 8f, 10);
            c3 = this.CombienParTranchesHoraires((Date) mapentry.getKey(), 12.5f, 7);
            c4 = this.CombienParTranchesHoraires((Date) mapentry.getKey(), 15.5f, 5);
            c5 = this.CombienParTranchesHoraires((Date) mapentry.getKey(), 17.5f, 3);
            c6 = this.CombienParTranchesHoraires((Date) mapentry.getKey(), 18.5f, 4);
            list.put(t1, c1);
            list.put(t2, c2);
            list.put(t3, c3);
            list.put(t4, c4);
            list.put(t5, c5);
            list.put(t6, c6);
            
            list = trierHashMap(list);
            
            this.MapNbParJour.replace((Date) mapentry.getKey(), list);

        } // fin du while
        for(int a = 0; a<this.ListeDesJours.size(); a++)
        {
           Iterator i2 = this.MapNbParJour.entrySet().iterator();
           boolean aTrouvé = false;
           while(i2.hasNext() && !aTrouvé)
           {
               Map.Entry mapentry2 = (Map.Entry) i2.next();
               if(this.ListeDesJours.get(a).getD().equals((Date) mapentry2.getKey()))
               {
                   aTrouvé = true;
               }
               
               if(aTrouvé)
               {
                   this.ListeDesJours.get(a).init_map((HashMap<String, Integer>) mapentry2.getValue());
               }
           } // fin du while
        } // fin du for
        
        
        //Rangement des Jours par leurs numéro de semaine dans la liste
        Collections.sort(this.ListeDesJours, Jour.ComparatorWeek);
        
        // Rangement dans une HashMap les jours par rapport à leur numéro de semaine, séparé bien distinctement.
        ArrayList<Jour> listtemp = new ArrayList<Jour>();
        for(int a = 1; a<this.ListeDesJours.size(); a++)
        {
            int nbweek = this.ListeDesJours.get(a).getNbWeekYear();
            int nbweekAvant = this.ListeDesJours.get(a-1).getNbWeekYear();
            
            if(nbweek == nbweekAvant)
            {
                    listtemp.add(this.ListeDesJours.get(a-1));
                
            }else{
                listtemp.add(this.ListeDesJours.get(a-1));        
                Collections.sort(listtemp);
                this.ListeDesJoursRassemblésSemaine.put(nbweekAvant, listtemp);
                listtemp = new ArrayList<Jour>();
            }
        }
        
        
        Iterator i4 = this.ListeDesJoursRassemblésSemaine.entrySet().iterator();
        HashMap<Integer, ArrayList<Jour>> maptemp = new  HashMap<Integer, ArrayList<Jour>>();
        while(i4.hasNext())
        {
            Map.Entry m = (Map.Entry) i4.next();
            int nbMonth = (((int) m.getKey())/4)+1;
            
            if(this.MapJourParMoisSemaine.containsKey(nbMonth))
            {
                maptemp.put((int) m.getKey(), (ArrayList<Jour>) m.getValue());
                this.MapJourParMoisSemaine.replace(nbMonth, maptemp);
                
            }else{
                
                 maptemp = new HashMap<Integer, ArrayList<Jour>>();
                 maptemp.put((int) m.getKey(), (ArrayList<Jour>) m.getValue());
                 
                 this.MapJourParMoisSemaine.put(nbMonth, maptemp);
                 
            }
        }
        
        //System.out.println("map des dispos par mois et semaines : \n" + this.MapJourParMoisSemaine);


    }
    
    
    //Méthode permettant de trier par ordre numérique, les clés de la HashMap
    public static HashMap<Date, ArrayList<EDTSuperv>> trierHashMap4(Map<Date, ArrayList<EDTSuperv>> hmap){
        List<Map.Entry<Date, ArrayList<EDTSuperv>>> list =
           new LinkedList<Map.Entry<Date, ArrayList<EDTSuperv>>>( hmap.entrySet() );
        Collections.sort( list, new Comparator<Map.Entry<Date, ArrayList<EDTSuperv>>>(){
           public int compare
           (Map.Entry<Date, ArrayList<EDTSuperv>>o1, Map.Entry<Date, ArrayList<EDTSuperv>> o2 )
           {
              //comparer deux clés
              return (o1.getKey()).compareTo(o2.getKey() );
           }
        });
        
        //créer une nouvelle HashMap à partir de LinkedList
        HashMap<Date, ArrayList<EDTSuperv>> hmapTriee = new LinkedHashMap<Date, ArrayList<EDTSuperv>>();
        for (Map.Entry<Date, ArrayList<EDTSuperv>> entry : list)
        {
            hmapTriee.put( entry.getKey(), entry.getValue() );
        }
        return hmapTriee;
    }
    
    

    //Map des jours classés par mois et par semaine
    public HashMap<Integer, HashMap<Integer, ArrayList<Jour>>> getMapJourParMoisSemaine() {
        return MapJourParMoisSemaine;
    }

       
    
    public HashMap<Integer, ArrayList<Jour>> get_ListeDesJoursRassemblésSemaine() {
        return ListeDesJoursRassemblésSemaine;
    }

    
    public HashMap<Date, HashMap<String, Integer>> get_MapNbJour()
    {
        return this.MapNbParJour;
    }
    
   
    
    public ArrayList<Date> get_listJour()
    {
        return this.listJours;
    }
    
}// Fin de la classe
