/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

import java.awt.Dimension;
import java.awt.MouseInfo;
import java.awt.PointerInfo;
import javafx.scene.text.Font;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.ToolBar;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;
 
 
public class GraphiqueSemaine extends Application {
    
    private int semaine;
    //Il s'agit des dimensions de chaque écran  ==  ecran adapté
        Dimension dimension = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        int height = (int)dimension.getHeight();
        int width  = (int)dimension.getWidth();
        
        //Subdivision de l'écran :
        int totalh = height/54;
        int totalw = width/64;
        
        Font police = new Font("Arial", 20);
        
        private Cloud c = new Cloud();
        
    public void init_C(Cloud C)
    {
        this.c = C;
    }

    public GraphiqueSemaine(int semaine) {
        this.semaine = semaine;
    }

    public int getJour() {
        return semaine;
    }
    
        
    
    @Override 
    public void start(Stage stage) {
        VBox root = new VBox();
        
        Group g = new Group();
        
        Menu menu = new Menu("Menu des Semaines");
        menu.setStyle("fx-background-color: blue;");
        ToolBar toolBar = new ToolBar();
        HBox v2 = new HBox(toolBar);
        Iterator i3 = c.get_le().get_ListeDesJoursRassemblésSemaine().entrySet().iterator();
        ArrayList<MenuItem> listButton = new ArrayList<MenuItem>();
        while(i3.hasNext())
        {
             Map.Entry mapentry = (Map.Entry) i3.next();
             MenuItem choice = new MenuItem(String.valueOf((int) mapentry.getKey()));
             listButton.add(choice);
        }
        
        SeparatorMenuItem s = new SeparatorMenuItem();
        
        for(int i = 0; i<listButton.size(); i++)
        {
            menu.getItems().add(listButton.get(i));
            menu.getItems().add(s);
        }
        
        MenuBar menuBar = new MenuBar();
        menuBar.getMenus().add(menu);

        
        Menu menu2 = new Menu("Stats par jour");
        
        MenuItem mi = new MenuItem("Quel jour ?");
       
           mi.setOnAction(new EventHandler<ActionEvent>() {
                                            
                 @Override 
                 public void handle(ActionEvent e) {
                     
                     DatePicker2INTERFACE dt = new DatePicker2INTERFACE();
                     Stage s = new Stage();
                     dt.init_c(c);
                     dt.start(s);
                     stage.close();
                 }
            });
           
           menu2.getItems().add(mi);
        menuBar.getMenus().add(menu2);
        
        
        for(int i = 0; i<listButton.size(); i++)
        {
           int num = Integer.parseInt(listButton.get(i).getText());
           
            //ACTION QUAND ON CLIQUE SUR UNE SEMAINE
           listButton.get(i).setOnAction(new EventHandler<ActionEvent>() {

               @Override 
                public void handle(ActionEvent e) {
                    
                    GraphiqueSemaine gs = new GraphiqueSemaine(num);
                    try{
                        Stage s = new Stage();
                        gs.init_C(c);
                        gs.start(s);
                        
                        stage.close();
                        
                    }catch(Exception ex){
                        ex.printStackTrace();
                    }
                }
           });
        }
        
        //menu des mois
        Menu menu3 = new Menu("Liste des Mois disponible");
       menuBar.getMenus().add(menu3);
        Iterator i5 = c.get_le().getMapJourParMoisSemaine().entrySet().iterator();
        ArrayList<MenuItem> listButton2 = new ArrayList<MenuItem>();
        while(i5.hasNext())
        {
             Map.Entry mapentry = (Map.Entry) i5.next();
             MenuItem choice = new MenuItem(String.valueOf((int) mapentry.getKey()));
             listButton2.add(choice);
        }
        
        
        for(int i = 0; i<listButton2.size(); i++)
        {
            menu.getItems().add(listButton2.get(i));
            menu.getItems().add(s);
        }
        
        for(int i = 0; i<listButton2.size(); i++)
        {
           int num = Integer.parseInt(listButton2.get(i).getText());
           
            //ACTION QUAND ON CLIQUE SUR UNE SEMAINE
           listButton2.get(i).setOnAction(new EventHandler<ActionEvent>() {

               @Override 
                public void handle(ActionEvent e) {
                    
                    GraphiqueMoisJour gmj= new GraphiqueMoisJour(num);
                    try{
                        Stage s = new Stage();
                        gmj.init_C(c);
                        gmj.start(s);
                        
                        stage.close();
                        
                    }catch(Exception ex){
                        ex.printStackTrace();
                    }
                }
           });
        }
        
        
        //Recupération des données
        ArrayList<Integer> liste = new ArrayList<Integer>();
        
        Iterator ite = c.get_le().get_ListeDesJoursRassemblésSemaine().entrySet().iterator();
        
        boolean Atrouvé = false;
        ArrayList<Jour> listJour = new ArrayList<Jour>();
        
        while(ite.hasNext() && !Atrouvé)
        {
             Map.Entry mapentry = (Map.Entry) ite.next();
             Atrouvé = (this.semaine == (int) mapentry.getKey());
             if(Atrouvé)
             {
                 Iterator i = c.get_le().get_ListeDesJoursRassemblésSemaine().get((int) this.semaine).iterator();
                 while(i.hasNext())
                 {
                     Jour jtemp = (Jour) i.next();
                     Iterator i2 = jtemp.getMap().entrySet().iterator();
                     listJour.add(jtemp);
                     while(i2.hasNext())
                     {
                         Map.Entry mapentry2 = (Map.Entry) i2.next();
                         liste.add((int) mapentry2.getValue());
                     }
                 }
             }
        }
        // Fin de la récupération de données
    
        
        if(!liste.isEmpty())
        {
            stage.setTitle("Bar Chart des Disponibilités de la Semaine");
            final CategoryAxis xAxis = new CategoryAxis();
            final NumberAxis yAxis = new NumberAxis();
            xAxis.setLabel("Tranches Horaires");       

            final BarChart<String,Number> lineChart = 
                    new BarChart<String,Number>(xAxis,yAxis);

            lineChart.setTitle("Dispos de la semaine : "+this.semaine);
            
            Iterator i4 = listJour.iterator();
            
            ArrayList<XYChart.Data<String, Number>> listxy = new ArrayList<XYChart.Data<String, Number>>();
            
            XYChart.Series series = new XYChart.Series();
            for( int i = 0; i<liste.size(); i+=6)
            {
                
                Jour jtemp = (Jour) i4.next();
                
                SimpleDateFormat sdf = new SimpleDateFormat("EEEE");
                String dt = sdf.format(jtemp.getD());
                series.setName(dt);
                
                XYChart.Data<String, Number> xy = new XYChart.Data("07h-08h", liste.get(i));
                series.getData().add(xy);
                listxy.add(xy);
                xy = new XYChart.Data("08h-12h30", liste.get(i+1));
                series.getData().add(xy);
                listxy.add(xy);
                xy = new XYChart.Data("12h30-15h30", liste.get(i+2));
                series.getData().add(xy);
                listxy.add(xy);
                xy = new XYChart.Data("15h30-17h30", liste.get(i+3));
                series.getData().add(xy);
                listxy.add(xy);
                xy = new XYChart.Data("17h30-18h30", liste.get(i+4));
                series.getData().add(xy);
                listxy.add(xy);
                xy = new XYChart.Data("18h30-20h00", liste.get(i+5));
                series.getData().add(xy);
                listxy.add(xy);
                

                lineChart.getData().add(series);
                
                
                
                
                series = new XYChart.Series();
            }

             
            //now you can get the nodes.
            for (XYChart.Series<String,Number> serie: lineChart.getData()){
                for (XYChart.Data<String, Number> item: serie.getData()){
                    item.getNode().setOnMouseEntered((MouseEvent event) -> {
                       item.getNode().setStyle("-fx-border-color: blue;"+"-fx-border-width: 3;");
                        HBox h = new HBox();
                        Paint p2 = Paint.valueOf("#D3D3D3");
                        //h.setBackground(new Background(new BackgroundFill(p2, CornerRadii.EMPTY, Insets.EMPTY)));
                        Label l = new Label();
                        String texte ="";
                        texte += "\n"+" Valeur sur l'axe Y : "+item.getYValue().intValue()+" \n\n";
                        
                        int moyenneH = 0;
                        for(int i = 0; i<listxy.size(); i++)
                        {
                            if(listxy.get(i).getXValue().equals(item.getXValue()))
                            {
                                moyenneH += listxy.get(i).getYValue().intValue();
                            }
                                
                            
                        }
                        moyenneH = moyenneH/7;
                        texte += " Moyenne sur cette horaire: "+ moyenneH + " \n\n";
                        
                        l.setText(texte);
                        Font f = new Font("TimesRoman", 10);
                        l.setFont(f);
                        Paint p = Paint.valueOf("#008000");
                        l.setTextFill(p);
                        l.setBackground(new Background(new BackgroundFill(p2, CornerRadii.EMPTY, Insets.EMPTY)));
                        
                        
                        PointerInfo pointer = MouseInfo.getPointerInfo(); 
                        java.awt.Point location = pointer.getLocation();  
                        
                        
                        h.getChildren().add(l);
                        l.setLayoutY(location.getY());
                        if(location.getX() >= (width*17)/totalw)
                        {
                             l.setLayoutX(location.getX()-100);
                             
                        }else{
                            
                            l.setLayoutX(location.getX());
                        }
                        
                        
                        g.getChildren().add(l);
                        
                    });
                    
                    
                    
                    item.getNode().setOnMouseExited((MouseEvent event) -> {
                        item.getNode().setStyle("-fx-border-color: blue;"+"-fx-border-width: 0;");
                         g.getChildren().clear();
                         VBox v = new VBox();
                         v.setPrefWidth(width);
                         v.getChildren().addAll(menuBar, lineChart, v2);
                         g.getChildren().add(v);
                         
                         lineChart.setMinSize(width-20, height-200);

                    });
                }
            }
            
            
             Button bNotice = new Button("En fonction\ndes Jours");
            bNotice.setStyle("-fx-background-color: lightpink;" + "-fx-font-color: black;");
            //bNotice.setPrefSize(100, 100);
            bNotice.setOnMouseEntered(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bNotice.setStyle("-fx-background-color: lightgray;" + "-fx-alignment: CENTER;" );
                        bNotice.setTextFill(Color.WHITE);
                    }
        });
        
        bNotice.setOnMouseExited(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                        bNotice.setStyle("-fx-background-color: lightpink;");
                    }
        });
        
        
        //Action en cliquant sur le Bouton retour arriere
                bNotice.setOnMouseClicked(new EventHandler<MouseEvent>() {
            
                    @Override
                    public void handle(MouseEvent event) {
                      
                       if(event.getClickCount() >= 1)
                       {
                            GraphiqueSemaineParJour gs = new GraphiqueSemaineParJour(semaine);
                            gs.init_C(c);
                            Stage s = new Stage();
                            gs.start(s);
                            stage.close();
                            
                            
                       }

                    }
                 }); 
        
        
        
            toolBar.getItems().add(bNotice);
            toolBar.setOrientation(Orientation.HORIZONTAL);
            
            v2.setLayoutX(width/totalw);
            v2.setLayoutY(height/totalh);
            
            
            lineChart.setMinSize(width-20, height-200);
            
            VBox v = new VBox();
            v.setPrefWidth(width);
            v.getChildren().addAll(menuBar, lineChart, v2);
            g.getChildren().add(v);
            Scene scene  = new Scene(g, width, height-75);
            stage.setScene(scene);
            stage.show();
            
        }else{
            
            Label l = new Label("Il n'y a aucune donnée à cette date");
            
            Scene scene  = new Scene(l,200, 100);

            stage.setScene(scene);
            stage.show();
            
        }
            
        
    }
 
}