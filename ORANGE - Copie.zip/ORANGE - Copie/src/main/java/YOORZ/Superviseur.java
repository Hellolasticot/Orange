/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package YOORZ;

import static YOORZ.Activités.trierHashMap;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author HugoBarboule
 */
public class Superviseur {
    private String Site;
    private SimpleStringProperty Nom;
    private String Prenom;
    private HashMap<String, Boolean> Competences;
    private String CUID;
    private ArrayList<EDTSuperv> edt;
    private Cloud c;

    public Superviseur(String Site, String Nom, String Prenom, String CUID) {
        this.Site = Site;
        this.Nom = new SimpleStringProperty(this, "Nom du Superviseur", Nom);
        this.Prenom = Prenom;
        this.CUID = CUID;
        this.Competences = new HashMap(3);
        this.Competences.put("SDH", false);
        this.Competences.put("FH", false);
        this.Competences.put("WDM", false);
        this.edt = new ArrayList<EDTSuperv>();
        
    }
    
    public void setCloud(Cloud c)
    {
        this.c = c;
    }

    public ArrayList<EDTSuperv> getEdt() {
        return edt;
    }
    

    
    
    public HashMap<Float, Integer> MixHashMap(ArrayList<HashMap<Float, Integer>> map1)
    {
        HashMap<Float, Integer> MapFinale = new HashMap<Float, Integer>();
        for(float i = 0f; i<=24f; i = i+0.5f)
        {
            int nbdispo = 1;
            for(int ii = 0; ii<map1.size(); ii++)
            {
                nbdispo *= map1.get(ii).get(i);
            }
            
            MapFinale.put(i,nbdispo);
        }
        return MapFinale;
    }
    
    
    public void Set_EDT(ArrayList<EDTSuperv> edt)
    {

        //FAIRE POUR CHAQUE ELEMENTS
        for(int i = 0; i< edt.size(); i++)
        {
           this.edt.add(edt.get(i));
        }

    }
    
    
    public HashMap<Float, Integer> get_EDT_ParDate(String date)
    {
        String texte = "";
        String texte_haut = "";
        String texte_bas = "";
        SimpleDateFormat formater = new SimpleDateFormat("dd/MM/yyyy");
        
        int i = 0;
        boolean Atrouve = false;
        while(i<this.edt.size() && !Atrouve)
        {
            String dTemp = "";
            dTemp = formater.format(this.edt.get(i).getDate());
            Atrouve = (date.equals(dTemp));
            if(!Atrouve)
                i++;
        }
        if(!Atrouve)
        {
            return null;
        }else{
            
            //Affichage du tableau
            for(HashMap.Entry<Float, Integer> entry : this.edt.get(i).getMap().entrySet())
            {
                texte_haut += "| " +entry.getKey() + " \t";
                texte_bas += "| "+entry.getValue()+ " \t";
            }
            texte_haut += "\n";
            texte += texte_haut + texte_bas;
            return this.edt.get(i).getMap();
        }
        
    }
    
    
    public ArrayList<ArrayList<EDTSuperv>> trouver_tableaux_edt_doublons()
    {
        // C'est une liste composée à chaque case de deux EDT pour un même jour
        ArrayList<ArrayList<EDTSuperv>> listDoublons = new ArrayList<ArrayList<EDTSuperv>>();
        for(int i = 0; i<this.edt.size()-1; i++)
        {
            
            //On récupere la date
            Date d = this.edt.get(i).getDate();
            
            int ii = i+1;
            boolean atrouvé = false;
            //System.out.println(this.getNom() + " "+ this.getPrenom()+" le i : "+this.edt.get(i).afficher_EDT()+"\n");
            while(ii<this.edt.size() && atrouvé == false)
            {
                atrouvé = (d.equals(this.edt.get(ii).getDate()));
                // Si une date est similaire dans la liste on les mets dans une liste à part
                
                if(atrouvé)
                {
                    //On crée une liste pour les 2 dans la même journée
                    ArrayList<EDTSuperv> list = new ArrayList<EDTSuperv>();
                    
                    // On les met
                    list.add(this.edt.get(i));
                    list.add(this.edt.get(ii));
                    //System.out.println(this.getNom() + " "+ this.getPrenom()+"le ii : "+this.edt.get(ii).afficher_EDT() +"\n\n");
                    
                    //On rajoute la liste dans la liste des doublons
                    listDoublons.add(list);
                    
                }               
                ii++;

            }
            
        }
        return listDoublons;
    }
    
    public Absence trouverABS(ArrayList<EDTSuperv> list)
    {
        ListeActivités la = new ListeActivités();
        la.init_list();
        la.init_listDesAb();
        la.init_listdesAc();
        int i = 0;
        boolean atrouvé = false;
        while(i<list.size() && !atrouvé)
        {
            atrouvé = la.estDansAbences(list.get(i).getActivite().getNom());
            if(!atrouvé)
                i++;
            else
                return la.Search_Absence(list.get(i).getActivite().getNom());
        }
        return null;
    }
    
     public Activités trouverAC(ArrayList<EDTSuperv> list)
    {
        ListeActivités la = new ListeActivités();
        la.init_list();
        la.init_listDesAb();
        la.init_listdesAc();
        int i = 0;
        boolean atrouvé = false;
        while(i<list.size() && !atrouvé)
        {
            atrouvé = la.estDansActivités(list.get(i).getActivite().getNom());
            if(!atrouvé)
                i++;
            else
                return la.Search_Activité(list.get(i).getActivite().getNom());
        }
        return null;
    }
     
    public EDTSuperv trouverEDTAC(ArrayList<EDTSuperv> list)
    {
        ListeActivités la = new ListeActivités();
        la.init_list();
        la.init_listdesAc();
        int i = 0;
        boolean atrouvé = false;
        while(i<list.size() && !atrouvé)
        {
            atrouvé = la.estDansActivités(list.get(i).getActivite().getNom());
            if(!atrouvé)
                i++;
            else
                return list.get(i);
        }
        return null;
    }
    
    public EDTSuperv trouverEDTAbs(ArrayList<EDTSuperv> list)
    {
        ListeActivités la = new ListeActivités();
        la.init_list();
        la.init_listDesAb();
        int i = 0;
        boolean atrouvé = false;
        while(i<list.size() && !atrouvé)
        {
            atrouvé = la.estDansAbences(list.get(i).getActivite().getNom());
            if(!atrouvé)
                i++;
            else
                return list.get(i);
        }
        return null;
    }
    
    public HashMap<Float, Integer> MixHashMap2(HashMap<Float, Integer> map1, HashMap<Float, Integer> map2)
    {
        HashMap<Float, Integer> MapFinale = new HashMap<Float, Integer>();
        for(float i = 0f; i<=24f; i = i+0.5f)
        {
            int nbdispo;

            nbdispo = map1.get(i)*map2.get(i);
            
            MapFinale.put(i,nbdispo);
        }
        return MapFinale;
    }
    
    
    
      //Méthode permettant de trier par ordre numérique, les clés de la HashMap
    public static HashMap<Float, Integer> trierHashMap3(Map<Float, Integer> hmap){
        List<Map.Entry<Float, Integer>> list =
           new LinkedList<Map.Entry<Float, Integer>>( hmap.entrySet() );
        Collections.sort( list, new Comparator<Map.Entry<Float, Integer>>(){
           public int compare
           (Map.Entry<Float, Integer>o1, Map.Entry<Float, Integer> o2 )
           {
              //comparer deux clés
              return (o1.getKey()).compareTo( o2.getKey() );
           }
        });
        
        //créer une nouvelle HashMap à partir de LinkedList
        HashMap<Float, Integer> hmapTriee = new LinkedHashMap<Float, Integer>();
        for (Map.Entry<Float, Integer> entry : list)
        {
            hmapTriee.put( entry.getKey(), entry.getValue() );
        }
        return hmapTriee;
    }
    
    
    public void correler_doublons_BIS(ArrayList<ArrayList<EDTSuperv>> listDoublons)
    {
        ListeActivités la = new ListeActivités();
        la.init_list();
        la.init_listDesAb();
        la.init_listdesAc();
               
        // On initialise la liste des edt qui va etre rajoutée avec le bon edt 
        ArrayList<EDTSuperv> ListEDT = new ArrayList<EDTSuperv>();
        
        // Pour chaque type de doublons
        for(int i = 0; i<listDoublons.size(); i++)
        {
            // On met des compteurs 
            int compteurAbs = 0; int compteurAc = 0;  EDTSuperv edt = null;
            
            // Pour chaque doublon
            for(int a = 0; a<listDoublons.get(i).size(); a++)
            {
               
                
                // Si un edt est un edt d'activité absence on le compte
                if(la.estDansAbences(listDoublons.get(i).get(a).getActivite().getNom()))
                {
                    compteurAbs ++;
                    //System.out.println("compteurAbs : "+compteurAbs);
                    
                
                // Si un edt est un edt d'activité présence on le compte
                }else if(la.Search_Activité(listDoublons.get(i).get(a).getActivite().getNom()) != null)
                    {
                       compteurAc ++; 
                       //System.out.println("compteurAc : "+compteurAc);
                    }
                // Sinon on le compte pas
            }
            
            // On crée une liste avec des edt
            ArrayList<EDTSuperv> LaList = new ArrayList<EDTSuperv>();
            
            // S'il n'y a qu'une seule absence, on prend le seul edt avec absence
            if(compteurAbs == 1)
            {
                LaList.add(this.trouverEDTAbs(listDoublons.get(i)));
                
            // S'il y en a plsusieurs alors on prend l'edt qui a le poids le plus faible en Absence
            }else if(compteurAbs > 1)
            {
               LaList.add(this.PrendreLeBonEDTdesAbsences(listDoublons.get(i)));
               
            }else if(compteurAbs == 0)
            {
               LaList.add(null);
            }
            
            // IDEM pour les activités de présence
            if(compteurAc == 1)
            {
                LaList.add(this.trouverEDTAC(listDoublons.get(i)));
                
            }else if(compteurAc > 1)
            {
                LaList.add(this.PrendreLeBonEDTdesActivités(listDoublons.get(i)));            

            }
            // On crée une liste avec les dispo de chaque superviseur
            ArrayList<Integer> DispoFinale = new ArrayList<Integer>();
            
            // On teste s'il passe par un endroit (dans le cas où il y a les 2 )
            boolean estPasséparla = false;
            if(LaList.get(0) != null )
            {
                //Si la taille est supérieure à 0
                if(LaList.size() > 1)
                {
                    // si le deuxieme n'est pas nulle (activité présence)
                    if(LaList.get(1) != null)
                    {
                        //On enregistre toutes les données utiles
                        ArrayList<Integer> dispo0 = new ArrayList<Integer>();
                        ArrayList<Integer> dispo1 = new ArrayList<Integer>();
                        
                                      
                        for(HashMap.Entry<Float, Integer> entry : LaList.get(0).getMap().entrySet())
                        {
                            dispo0.add(entry.getValue());
                        }
                        for(HashMap.Entry<Float, Integer> entry : LaList.get(1).getMap().entrySet())
                        {
                            dispo1.add(entry.getValue());
                        }
                    
                        // On fait la bonne donnée
                        for(int a = 0; a<dispo0.size(); a++)
                        {
                            // On met alors la multiplication des deux dans la liste
                            DispoFinale.add(dispo0.get(a) * dispo1.get(a)); 
                        }
                        estPasséparla = true;
                    }
                    
                    
                }else{
                    // dans le  cas où il n'y a que des absences (en 1 il y a null)
                    
                    Date d = LaList.get(0).getDate();
                    Activités ac = LaList.get(0).getActivite();
                    String nom = LaList.get(0).getNom();
                    int compteur = 0;
                    ArrayList<HashMap<Float, Integer>> listMap = new ArrayList<HashMap<Float, Integer>>();
                    listMap.add(LaList.get(0).getMap());
                    for(int a = 0; a<this.edt.size(); a++)
                    {
                        if(this.edt.get(a).getDate().equals(d) && ((la.getListDesAc().contains(this.edt.get(a).getActivite().getNom())) || la.getListDesAb().contains(this.edt.get(a).getActivite().getNom()) ) )
                        {
                            compteur ++;
                            listMap.add(this.edt.get(a).getMap());
                            if(LaList.get(0).getActivite().getPoids() >= this.edt.get(a).getActivite().getPoids() && la.get_list().contains(LaList.get(0).getActivite()))
                            {
                                ac = this.edt.get(a).getActivite();
                                nom = this.edt.get(a).getNom();          
                            } 
                           
                        }      
                    }
                    System.out.println("compteur : "+ compteur);
                    if(compteur > 1)
                    {
                       HashMap<Float, Integer> map= new HashMap<Float, Integer>();
                       map = this.MixHashMap(listMap);
                       System.out.println("le mix1 se fait entre : \n"+listMap);
                       EDTSuperv edt1 = new EDTSuperv(this, d, ac);
                       edt1.setMap(map);
                       edt1.setNom(nom + "_mix1");
                       
                       //on remove tout ceux de la meme dates
                       for(int a = 0; a<this.edt.size(); a++)
                        {
                            if(this.edt.get(a).getDate().equals(d) && this.edt.get(a).getNuméro() != edt1.getNuméro())
                            {
                                this.edt.remove(a);
                            }      
                        }
                       
                       this.edt.add(edt1);
                       
                    }else{
                        System.out.println("le compteur est égal à 1 donc on l'ajoute");
                        this.edt.add(LaList.get(0));
                    }

                        
                }
            }else{
                
                // dans le cas où il n'y a que des activités de type présence (en 0 il y a null)
                ArrayList<HashMap<Float, Integer>> listAMixer = new ArrayList<HashMap<Float, Integer>>();
                Date d = LaList.get(1).getDate();
                int poids = LaList.get(1).getActivite().getPoids();
                Activités activité = null;
                int numerotest = LaList.get(1).getNuméro();
                
                //on verifie si l'acitivité en question a un poids plus petit que d'autres à la même date dans la liste
                for(int a = 0; a<this.edt.size(); a++)
                {
                    //si jamais on change l'activité
                    if(this.edt.get(a).getDate().equals(d) && poids<this.edt.get(a).getActivite().getPoids())
                    {
                        poids = this.edt.get(a).getActivite().getPoids();
                        activité = this.edt.get(a).getActivite(); 
                        numerotest = this.edt.get(a).getNuméro();
                    }
                    if(this.edt.get(a).getDate().equals(d) && this.edt.get(a).getActivite().getPoids() < 20)
                    {
                        listAMixer.add(this.edt.get(a).getMap());
                        System.out.println(this.edt.get(a).getMap());
                    }
                }
                
                HashMap<Float, Integer> map = new HashMap<Float, Integer>();
                System.out.println("avant le mix2 : \n"+listAMixer);
                map = this.MixHashMap(listAMixer);
                
                //on supprime tout ce qui n'est pas de cette activité à cette date précise.
                for(int a = 0; a<this.edt.size(); a++)
                {
                    if(this.edt.get(a).getDate().equals(d) && this.edt.get(a).getNuméro() != numerotest && this.edt.get(a).getActivite().getPoids() > 20 )
                    {
                         this.edt.remove(a);
                    }
                    if(this.edt.get(a).getDate().equals(d) && this.edt.get(a).getNuméro() == numerotest)
                    {
                        if(listAMixer.size() > 1 && this.edt.get(a).getActivite().getPoids() < 20 && la.get_list().contains(this.edt.get(a).getActivite()))
                        {
                           this.edt.get(a).setMap(map);
                           this.edt.get(a).setNom(this.edt.get(a).getNom() + "_mix2");
                           System.out.println(this.edt.get(a).getNom());
                        }
                    }
                }
                
                // si l'activité n'a pas changé alors on l'ajoute dans la liste des edt
                if(LaList.get(1).getActivite().equals(activité))
                {
                    if(!this.edt.contains(LaList.get(1)))
                        this.edt.add(LaList.get(1));
                }
                
                
            }// fin des cas quand il n'y en a qu'un
            
            // S'il y a les 2 alors on crée un tableau qui prend en compte la liste des dispo
            if(estPasséparla)
            {           
                HashMap<Float, Integer> tableau = new HashMap<Float, Integer>();
                float heure = 0f;
                for(int a = 0; a<=48; a++)
                {
                    tableau.put(heure, DispoFinale.get(a));
                    heure += 0.5f;
                }


                int p1 = listDoublons.get(i).get(0).getActivite().getPoids();
                int p2 = listDoublons.get(i).get(1).getActivite().getPoids();
                
                // On crée un edt avec le superviseur en question, la bonne date et l'activité présence en question
                EDTSuperv edt2 = null;
                Date d = null;
                if(p1<=p2 && la.getListDesAb().contains(listDoublons.get(i).get(0).getActivite().getNom()) )
                {
                    edt2 = new EDTSuperv(this, listDoublons.get(i).get(0).getDate() , listDoublons.get(i).get(0).getActivite() );
                    tableau = trierHashMap(tableau);
                    edt2.setMap(tableau);
                    edt2.setNom(edt2.getNom()+"_mix3");
                    System.out.println(edt2.getNom());
                    d = edt2.getDate();
                    
                
                }
                else if(p2<p1 && la.getListDesAc().contains(listDoublons.get(i).get(1).getActivite().getNom())){
                    
                    edt2 = new EDTSuperv(this, listDoublons.get(i).get(0).getDate() , listDoublons.get(i).get(1).getActivite() );
                    tableau = trierHashMap(tableau);
                    edt2.setMap(tableau);
                    edt2.setNom(edt2.getNom()+"_mix4");
                    System.out.println(edt2.getNom());
                    d = edt2.getDate();
                }
               

                
                
                if(d != null)
                {
                    for(int a = 0; a<this.edt.size(); a++)
                    {
                        if(this.edt.get(a).getDate().equals(d))
                        {
                            this.edt.remove(a);
                        }
                    }


                   this.edt.add(edt2);
                }
                
        
                //Permet de ranger les EDT en focntion des dates dans l'ordre croissant
                Collections.sort(this.edt, new Comparator<EDTSuperv>()
                {
                    @Override
                    public int compare(EDTSuperv e1, EDTSuperv e2)
                    {
                        return e1.getDate().compareTo(e2.getDate());
                    }
                });
                
                
            }// Fin du if
            
           

            
        }//Fin de la boucle traverant toute la liste des listes des doublons de même date
        
    }//Fin de la méthode de corrélation BIS
          
    
    public void AfficherTousLesEDT()
    {
        for(int i = 0; i<this.edt.size(); i++)
        {
            System.out.println("is empty ? : "+this.edt.get(i).getNom());
            /*char[] tab = this.edt.get(i).getNom().toCharArray();
            if(tab.length == 0)
                System.out.print("edt n°"+i + " : \n"+ this.edt.get(i).afficher_EDT()+"\n");
            */
        }
    }
    
    
    
    public EDTSuperv PrendreLeBonEDTdesAbsences(ArrayList<EDTSuperv> list)
    {
        ListeActivités la = new ListeActivités();
        la.init_list();
        EDTSuperv EDTSupervTemp = this.trouverEDTAbs(list);
        int poidsMin = list.get(0).getActivite().getPoids();
        for(int i = 1; i<list.size(); i++)
        {
            //System.out.println("poids activité i : "+ list.get(i).getActivite().getPoids());
            //System.out.println("poids activité min : "+ poidsMin);
            //System.out.println("absence : "+la.Search_Absence(list.get(i).getActivite().getNom()).getNom());
           if((list.get(i).getActivite().getPoids() < poidsMin) && (la.get_list_Absences().contains(la.Search_Absence(list.get(i).getActivite().getNom()))))
           {
               EDTSupervTemp = list.get(i);
               poidsMin = list.get(i).getActivite().getPoids();
               //System.out.println(list.get(i).afficher_EDT());
           }
        }
        
        return EDTSupervTemp;
    }
    
    
     public EDTSuperv PrendreLeBonEDTdesActivités(ArrayList<EDTSuperv> list)
    {
        ListeActivités la = new ListeActivités();
        la.init_list();
        EDTSuperv EDTSupervTemp = this.trouverEDTAC(list);
        int poidsMin = list.get(0).getActivite().getPoids();
        for(int i = 1; i<list.size(); i++)
        {
           if((list.get(i).getActivite().getPoids() < poidsMin) && (la.get_list().contains(la.Search_Activité(list.get(i).getActivite().getNom()))))
           {
               EDTSupervTemp = list.get(i);
           }
        }
        
        return EDTSupervTemp;
    }

    @Override
    public String toString() {
        return "Superviseur{" + "Site=" + Site + ", Prenom=" + Prenom + ", CUID=" + CUID + '}';
    }
    
    
   
    

    public String getSite() {
        return Site;
    }

    public SimpleStringProperty getVNom()
    {
        return Nom;
    }
   
    
    public String getNom() {
        return Nom.get();
    }

    public String getPrenom() {
        return Prenom;
    }
    
    public String getCUID()
    {
        return CUID;
    }

    public HashMap<String, Boolean> getCompétences() {
        return Competences;
    }
    
    public boolean Get_CompétenceSDH()
    {
       return this.Competences.get("SDH");
    }
    
    public boolean Get_CompétenceFH()
    {
        return this.Competences.get("FH");
    }
    
    public boolean Get_CompétenceWDM()
    {
        return this.Competences.get("WDM");
    }
    
    public void Set_CompétenceSDH(Boolean cap)
    {
        this.Competences.replace("SDH", cap);
    }
    
    public void Set_CompétenceFH(Boolean cap)
    {
        this.Competences.replace("FH", cap);
    }
    
    public void Set_CompétenceWDM(Boolean cap)
    {
        this.Competences.replace("WDM", cap);
    }
    
}
